import 'jest';

describe('Dummy Test Cases', () => {
  test('Verify Jest is working', () => {
    expect(true).toBeTruthy();
  });
});
