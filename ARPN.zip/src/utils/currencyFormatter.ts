export function currencyConsolidator(curr) {
	const currencyRanges = [];

	for (let i = 0; i < curr.length; i++) {
		// console.log("",curr[i].EXCHANGERATE)
		currencyRanges.push({
			STARTDATE: new Date(curr[i]?.VALIDITYSTARTDATE),
			ENDDATE: curr[i + 1]?.VALIDITYSTARTDATE
				? new Date(
						curr[i + 1]?.VALIDITYSTARTDATE.getTime() -
							24 * 60 * 60 * 1000,
				  )
				: new Date(),
			EXCHANGERATE: parseFloat(curr[i].EXCHANGERATE),
		});
	}
	return currencyRanges;
}

export function interestConsolidator(curr) {
	const currencyRanges = [];

	for (let i = 0; i < curr.length; i++) {
		// console.log("",curr[i].EXCHANGERATE)
		currencyRanges.push({
			STARTDATE: new Date(curr[i]?.STARTDATE),
			ENDDATE: curr[i]?.ENDDATE ? new Date(curr[i]?.ENDDATE) : new Date(),
			INTERESTRATE: parseFloat(curr[i].PRENEGSOFRPERCENTAGE),
		});
	}
	return currencyRanges;
}
