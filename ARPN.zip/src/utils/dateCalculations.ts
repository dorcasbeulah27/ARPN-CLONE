export function getDateDifferenceInDays(date1, date2) {
    // Convert both dates to milliseconds
    const date1MS = date1.getTime();
    const date2MS = date2.getTime();

    // Calculate the difference in milliseconds
    const differenceMS = Math.abs(date1MS - date2MS);

    // Convert the difference to days
    const oneDayMS = 1000 * 60 * 60 * 24;
    const differenceDays = Math.floor(differenceMS / oneDayMS);

    return differenceDays;
}

