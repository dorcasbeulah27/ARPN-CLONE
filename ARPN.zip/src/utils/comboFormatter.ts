const comboFormatter = (
	data: any[],
	KEY: string,
	VALUE: string,
	DATA: string[] = [],
) =>
	data.map((element) => {
		const additionalData = DATA.reduce((acc: string, curr: string) => {
			acc[curr] = element[curr];
			return acc;
		}, {} as any);
		return {
			label: element[KEY] || '',
			value: element[VALUE] || '',
			data: additionalData,
		};
	});

export default comboFormatter;
