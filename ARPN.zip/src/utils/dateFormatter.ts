const moment = require('moment');

/**
 * Format a date using moment.js with various options.
 * @param {Date | string} date - The input date object or date string.
 * @param {string} format - The desired format for the output date.
 * @returns {string} - The formatted date string.
 */
function dateFormatter(date: Date | string, format: string): string {
  let parsedDate: Date;

  if (typeof date === 'string') {
    // If the input is a string, parse it into a Date object
    parsedDate = new Date(date);
  } else if (date instanceof Date) {
    // If the input is already a Date object, use it directly
    parsedDate = date;
  } else {
    throw new Error('Invalid date object provided');
  }

  // Ensure that the parsed date is valid
  if (isNaN(parsedDate.getTime())) {
    throw new Error('Invalid date object provided');
  }

  // Use moment.js to format the date
  return moment(parsedDate).format(format);
}

export default dateFormatter;
