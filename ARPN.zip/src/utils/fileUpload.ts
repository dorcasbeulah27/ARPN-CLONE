import multer from 'multer';
import { v4 as uuidv4 } from 'uuid';
import Environment from '../environments/environment';

const storage = multer.diskStorage({
	destination(req, file, cb) {
		// Define the destination folder where files will be stored
		cb(null, '/FILES/');
	},
	filename(req, file, cb) {
		const uuid = uuidv4();
		req.body.uuidfileName = `${uuid}_${file.originalname}`;
		// Preserve the original file name
		cb(null, `${uuid}_${file.originalname}`);
	},
});

const upload = multer({
	storage,
});

export default upload;
