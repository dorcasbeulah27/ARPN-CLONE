import jwt from 'jsonwebtoken';
import Environment from '../environments/environment';

const auth = async (req, res, next) => {
	try {
		const env = new Environment();
		const jwtSecret = env.secretKey || 'your-secret-key';

		let OUID = req.header('OUID') || 1;
		if (OUID === 'undefined') {
			OUID = 1;
		}
		if (OUID) {
			req.query.OUID = OUID;
		}

		let ROLEID = req.header('ROLEID') || 1;
		if (ROLEID === 'undefined') {
			ROLEID = 1;
		}
		if (ROLEID) {
			req.query.ROLEID = ROLEID;
		}

		//   get the token from the authorization header
		// const token = await req.headers.authorization.split(' ')[1];

		// // check if the token matches the supposed origin
		// const decodedToken = await jwt.verify(token, jwtSecret);

		// // retrieve the user details of the logged in user
		// const user = await decodedToken;
		// // pass the the user down to the endpoints here
		// req.query.USER = user.USERID;
		// req.query.ROLE = user.ROLE;

		// pass down functionality to the endpoint
		next();
	} catch (error) {
		res.status(400).send({
			message:
				"You're session has expired, Please re-login into the portal.",
		});
	}
};

export default auth;
