import * as fs from 'fs';
import * as path from 'path';
import { DotenvParseOutput, config as configDotenv } from 'dotenv';

import { Dialect } from 'sequelize';
import { EnvironmentFile, Environments } from './environment.constant';
import IEnvironment from './environment.interface';

class Environment implements IEnvironment {
	public port: number;

	public secretKey: string;

	public applyEncryption: boolean;

	public env: string;

	public dbUser: string;

	public dbPassword: string;

	public dbDatabase: string;

	public dbIp: string;

	public dbPort: number;

	public dbDialect: Dialect;

	public parsedEnv: DotenvParseOutput;

	public emailId: string;

	public emailPassword: string;

	public mailService: string;

	public maintenanceMails: string;

	public applicationName: string;

	public applicationUri: string;

	public orionUser: string;

	public orionPassword: string;

	public orionConnectionString: string;

	public orionLibraryDir: string;

	public authKey: string;

	/**
	 *
	 * @param NODE_ENV
	 */
	constructor(NODE_ENV?: string) {
		this.env = NODE_ENV || process.env.NODE_ENV || Environments.LOCAL;
		this.setEnvironment(this.env);
		const port: string | undefined | number = this.parsedEnv.PORT || 8080;
		this.port = Number(port);
		this.applyEncryption = JSON.parse(this.parsedEnv.APPLY_ENCRYPTION);
		this.secretKey = this.parsedEnv.SECRET_KEY;
		this.dbUser = this.parsedEnv.DB_USER;
		this.dbPassword = this.parsedEnv.DB_PASSWORD;
		this.dbDatabase = this.parsedEnv.DB_DATABSE;
		this.dbIp = this.parsedEnv.DB_IP;
		this.dbPort = parseInt(this.parsedEnv.DB_PORT || '5432', 10);
		this.emailId = this.parsedEnv.EMAIL_ID;
		this.emailPassword = this.parsedEnv.EMAIL_PASSWORD;
		this.mailService = this.parsedEnv.MAIL_SERVICE;
		this.maintenanceMails = this.parsedEnv.MAINTENANCE_MAILS;
		this.applicationName = this.parsedEnv.APPLICATION_NAME;
		this.applicationUri = this.parsedEnv.APP_URI;
		this.orionUser = this.parsedEnv.DB_ORION_USER || '';
		this.orionPassword = this.parsedEnv.DB_ORION_PASSWORD || '';
		this.orionConnectionString =
			this.parsedEnv.ORION_DB_CONNECT_STRING || '';
		this.orionLibraryDir = this.parsedEnv.ORION_LIB_DIR || '';
		this.authKey = this.parsedEnv.AUTH_KEY || '';
		// this.dbDialect = process.env.DB_DIALECT;
	}

	/**
	 *
	 * @returns
	 */
	public getCurrentEnvironment(): string {
		return this.env;
	}

	/**
	 *
	 * @param env
	 */
	public setEnvironment(env: string): void {
		let envPath: string;
		this.env = env || Environments.LOCAL;
		const rootdir: string = path.resolve(__dirname, '../../');
		switch (env) {
			case Environments.PRODUCTION:
				envPath = path.resolve(rootdir, EnvironmentFile.PRODUCTION);
				break;
			case Environments.TEST:
				envPath = path.resolve(rootdir, EnvironmentFile.TEST);
				break;
			case Environments.STAGING:
				envPath = path.resolve(rootdir, EnvironmentFile.STAGING);
				break;
			case Environments.LOCAL:
				envPath = path.resolve(rootdir, EnvironmentFile.LOCAL);
				break;
			default:
				envPath = path.resolve(rootdir, EnvironmentFile.LOCAL);
		}
		if (!fs.existsSync(envPath)) {
			throw new Error('.env file is missing in root directory');
		}

		const { parsed: parsedConfig } = configDotenv({ path: envPath });
		this.parsedEnv = parsedConfig;
	}

	/**
	 *
	 * @returns
	 */
	public isProductionEnvironment(): boolean {
		return this.getCurrentEnvironment() === Environments.PRODUCTION;
	}

	/**
	 *
	 * @returns
	 */
	public isDevEnvironment(): boolean {
		return this.getCurrentEnvironment() === Environments.LOCAL;
	}

	/**
	 *
	 * @returns
	 */
	public isTestEnvironment(): boolean {
		return this.getCurrentEnvironment() === Environments.TEST;
	}

	/**
	 *
	 * @returns
	 */
	public isStagingEnvironment(): boolean {
		return this.getCurrentEnvironment() === Environments.STAGING;
	}
}

export default Environment;
