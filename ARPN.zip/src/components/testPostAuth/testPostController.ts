import { NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import ApiError from '../../abstractions/ApiError';
import UserMaster from '../../database/models/masters/userMaster';
import logger from '../../lib/logger';
import BaseApi from '../BaseApi';
import testTable from '../../database/models/business/bankMaster/testTable';
import { json } from 'sequelize';


/**
 * User Management controller
 */
export default class TestPostController extends BaseApi {
	constructor() {
		super();
	}

	public register(): Router {
        this.router.post('/createUser', this.createUser.bind(this));
        return this.router;
	}
    public async createUser(req: Request, res: Response) {
		try {
			logger.info('createUser api has been invoked');
			const {data} = req.body;
			const userDetails = await testTable.bulkCreate(data);
            
            
			res.locals.data = JSON.parse(JSON.stringify(userDetails));
			super.send(res);
		} catch (err) {
			logger.error(`Error in createUser : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
}