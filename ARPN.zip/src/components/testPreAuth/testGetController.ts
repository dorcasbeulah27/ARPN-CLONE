import { NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import BaseApi from '../BaseApi';
import logger from '../../lib/logger';
import ApiError from '../../abstractions/ApiError';
import UserMaster from '../../database/models/masters/userMaster';
import testTable from '../../database/models/business/bankMaster/testTable';
import { Op } from 'sequelize';

export default class TestGetControllers extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/getAllUsers', this.getAllUsers.bind(this));

		return this.router;
	}
	public async getAllUsers(req: Request, res: Response) {
		try {
			const count = await testTable.count();
			const users = await testTable.findAll({
				raw: true,
			});

			let finalResult = {
				GROUP1: [],
				GROUP2: [],
				GROUP3: [],
				GROUP4: [],
			};

			// console.log(users);
			for (let element = 0; element < count; element++) {
				if ((users[element] as any).AGE <= 18) {
					finalResult.GROUP1.push(users[element]),
						console.log('finalResult', finalResult);
				} else if (
					(users[element] as any).AGE > 18 &&
					(users[element] as any).AGE <= 25
				) {
					finalResult.GROUP2.push(users[element]),
						console.log('finalResult', finalResult);
				} else if (
					(users[element] as any).AGE > 25 &&
					(users[element] as any).AGE <= 30
				) {
					finalResult.GROUP3.push(users[element]),
						console.log('finalResult', finalResult);
				} else {
					finalResult.GROUP4.push(users[element]),
						console.log('finalResult', finalResult);
				}
			}

			res.locals.data = JSON.parse(JSON.stringify(finalResult));

			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
}
