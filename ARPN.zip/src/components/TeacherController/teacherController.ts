import { Router, Request, Response, NextFunction } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import ApiError from '../../abstractions/ApiError';

import logger from '../../lib/logger';
import BaseApi from '../BaseApi';
import Teachers from '../../database/models/business/teachersTable/teachers';

export default class teacherController extends BaseApi {
	router: any;
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/getAllTeachers', this.getAllTeachers.bind(this));
		this.router.post('/createTeacher', this.createTeacher.bind(this));
		this.router.put('/updateTeacher/:id', this.updateTeacher.bind(this));
		this.router.delete('/deleteTeacher/:id', this.deleteTeacher.bind(this));
		this.router.post(
			'/defaultTeacher',
			this.insertDefaultTeachers.bind(this),
		);

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	public async getAllTeachers(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('getAllTeachers api has been invoked');
			const users = await Teachers.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getAllTeachers : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createTeacher(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('createTeacher api has been invoked');
			const { data } = req.body;
			const user = await Teachers.create(data);
			res.locals.data = JSON.parse(JSON.stringify(user));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in createTeacher : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async updateTeacher(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('updateTeacher api has been invoked');
			const { id } = req.params;
			const { data } = req.body;
			const user = await Teachers.update(data, { where: { id } });
			res.locals.data = JSON.parse(JSON.stringify(user));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in updateTeacher : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	public async deleteTeacher(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('deleteTeacher api has been invoked');
			const { id } = req.params;
			console.log('id', id);
			const { data } = req.body;
			const user = await Teachers.destroy({ where: { ID: id } });
			res.locals.data = { user };
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in deleteTeacher : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	async insertDefaultTeachers(req: Request, res: Response) {
		try {
			await Teachers.bulkCreate([
				{ id: 1, TeacherName: 'HEMA' },
				{ id: 2, TeacherName: 'ARUL' },
				{ id: 3, TeacherName: 'ANGEL' },
				{ id: 4, TeacherName: 'SUCHI' },
			]);
			res.status(200).json({ message: 'Teachers inserted successfully' });
		} catch (error) {
			console.error('Error inserting Teachers:', error);
			res.status(500).json({
				message: 'Failed to insert teachers',
				error,
			});
		}
	}
}
