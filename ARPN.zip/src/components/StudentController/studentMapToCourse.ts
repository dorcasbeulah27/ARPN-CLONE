import { NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import ApiError from '../../abstractions/ApiError';
import StudentMapToCourse from '../../database/models/business/studentTable/studentMapToCourse';
import logger from '../../lib/logger';
import BaseApi from '../BaseApi';

/**
 * User Management controller
 */
export default class studentMapToCourse extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/getAll', this.getAll.bind(this));
		this.router.post(
			'/defaultStudent-Course',
			this.insertStudentMapToCourses.bind(this),
		);

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getAll(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllUsers api has been invoked');
			const users = await StudentMapToCourse.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	async insertStudentMapToCourses(req: Request, res: Response) {
		try {
			await StudentMapToCourse.bulkCreate([
				{ id: 1, studentId: 1, courseId: 1 },
				{ id: 2, studentId: 2, courseId: 2 },
				{ id: 3, studentId: 3, courseId: 4 },
				{ id: 4, studentId: 4, courseId: 3 },
			]);
			res.status(200).json({
				message: 'Student-Course Mappings inserted successfully',
			});
		} catch (error) {
			console.error('Error inserting Student-Course Mappings:', error);
			res.status(500).json({
				message: 'Failed to insert student-course mappings',
				error,
			});
		}
	}
}
