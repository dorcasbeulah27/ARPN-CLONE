import { NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import ApiError from '../../abstractions/ApiError';
import StudentMapToTeacher from '../../database/models/business/studentTable/studentMapToTeacher';
import logger from '../../lib/logger';
import BaseApi from '../BaseApi';

/**
 * User Management controller
 */
export default class studentMapToTeacher extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/getAll', this.getAll.bind(this));
		this.router.post(
			'/defaultStudent-Teacher',
			this.insertStudentMapToTeacher.bind(this),
		);

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getAll(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllUsers api has been invoked');
			const users = await StudentMapToTeacher.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	async insertStudentMapToTeacher(req: Request, res: Response) {
		try {
			await StudentMapToTeacher.bulkCreate([
				{ id: 1, studentId: 1, teacherId: 1 },
				{ id: 2, studentId: 2, teacherId: 3 },
				{ id: 3, studentId: 1, teacherId: 2 },
				{ id: 4, studentId: 2, teacherId: 2 },
				{ id: 5, studentId: 3, teacherId: 4 },
				{ id: 6, studentId: 3, teacherId: 2 },
				{ id: 7, studentId: 4, teacherId: 1 },
				{ id: 8, studentId: 4, teacherId: 3 },
			]);
			res.status(200).json({
				message: 'Student-Teacher Mappings inserted successfully',
			});
		} catch (error) {
			console.error('Error inserting Student-Teacher Mappings:', error);
			res.status(500).json({
				message: 'Failed to insert student-teacher mappings',
				error,
			});
		}
	}
}
