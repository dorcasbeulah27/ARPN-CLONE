import { Router, Request, Response, NextFunction } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import ApiError from '../../abstractions/ApiError';

import logger from '../../lib/logger';
import BaseApi from '../BaseApi';
import Students from '../../database/models/business/studentTable/students';
import Courses from '../../database/models/business/coursesTable/courses';
import { Op, where } from 'sequelize';
import Teachers from '../../database/models/business/teachersTable/teachers';
import { log } from 'console';
import { idText } from 'typescript';
import StudentMapToCourse from '../../database/models/business/studentTable/studentMapToCourse';
import StudentMapToTeacher from '../../database/models/business/studentTable/studentMapToTeacher';

export default class studentController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		// this.router.get('/getAllStudents', this.getAllStudents.bind(this));
		this.router.post('/createStudent', this.createStudent.bind(this));
		this.router.put('/updateStudent/:id', this.updateStudent.bind(this));
		this.router.delete('/deleteStudent/:id', this.deleteStudent.bind(this));
		this.router.post(
			'/defaultStudent',
			this.insertDefaultStudents.bind(this),
		);
		this.router.get(
			'/getStudentsByTC',
			this.getStudentsByteacherAndCourse.bind(this),
		);

		return this.router;
	}
	public async getStudentsByteacherAndCourse(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { courseName, TeacherName } = req.query;
			console.log(
				'----------getStudentsByteacherAndCourse API intiated',
				courseName,
				TeacherName,
			);
			const course = await Courses.findOne({
				where: { courseName: courseName },
				attributes: ['id'],
			});
			const teacher = await Teachers.findOne({
				where: { TeacherName: TeacherName },
				attributes: ['id'],
			});
			const courseId = (course as any).dataValues;
			const teacherId = (teacher as any).dataValues;

			console.log(courseId, ',', teacherId);
			const studentFromTeacher = await StudentMapToTeacher.findAll({
				where: { teacherId: teacherId.id },
				attributes: ['studentId'],
				raw: true,
			});
			const studentFromCourse = await StudentMapToCourse.findAll({
				where: { courseId: courseId.id },
				attributes: ['studentId'],
				raw: true,
			});
			console.log(
				'students in bca',
				studentFromCourse,
				',',
				'students under hema',
				studentFromTeacher,
			);

			const studentDetails = studentFromCourse.reduce((acc, obj) => {
				const curr = (obj as any).studentId;
				console.log(curr);
				const isInArr2 = studentFromTeacher.some((elements) => {
					return (elements as any).studentId === curr;
				});
				console.log(isInArr2);
				if (isInArr2 && !acc.includes(curr)) {
					acc.push(curr);
				}
				return acc;
			}, []);

			console.log(studentDetails);
			const studentName = await Students.findAll({
				where: { id: studentDetails },
			});

			res.locals.data = JSON.parse(JSON.stringify(studentName));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getAllStudents : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	// public async getAllStudents(
	// 	req: Request,
	// 	res: Response,
	// 	next: NextFunction,
	// ) {
	// 	try {
	// 		logger.info('getAllStudents api has been invoked');
	// 		const users = await Students.findAll();
	// 		res.locals.data = JSON.parse(JSON.stringify(users));
	// 		super.send(res);
	// 	} catch (err) {
	// 		logger.error(
	// 			`Error in getAllStudents : ${err.message}\n${err.stack}`,
	// 		);
	// 		throw new ApiError(
	// 			ReasonPhrases.BAD_REQUEST,
	// 			StatusCodes.BAD_REQUEST,
	// 			res,
	// 		);
	// 	}
	// }

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createStudent(req: Request, res: Response) {
		try {
			logger.info('createStudent api has been invoked');
			const { data } = req.body;
			const studentDetails = await Students.bulkCreate(data);

			res.locals.data = JSON.parse(JSON.stringify(studentDetails));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in createStudent : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async updateStudent(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('updateStudent api has been invoked');
			const { id } = req.params;
			const { data } = req.body;
			const user = await Students.update(data, { where: { id } });
			res.locals.data = JSON.parse(JSON.stringify(user));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in updateStudent : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	public async deleteStudent(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('deleteStudent api has been invoked');
			const { id } = req.params;
			console.log('id', id);
			const { data } = req.body;
			const user = await Students.destroy({ where: { ID: id } });
			res.locals.data = { user };
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in deleteStudent : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	async insertDefaultStudents(req: Request, res: Response) {
		try {
			await Students.bulkCreate([
				{ id: 1, studentName: 'BEULAH', REGNO: '1' },
				{ id: 2, studentName: 'DORCAS', REGNO: '2' },
				{ id: 3, studentName: 'IMMAN', REGNO: '3' },
				{ id: 4, studentName: 'CHRISTO', REGNO: '4' },
			]);
			res.status(200).json({ message: 'Students inserted successfully' });
		} catch (error) {
			console.error('Error inserting Students:', error);
			res.status(500).json({
				message: 'Failed to insert students',
				error,
			});
		}
	}
}
