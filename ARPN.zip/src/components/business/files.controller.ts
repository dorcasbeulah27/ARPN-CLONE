import fs from 'fs';
import path from 'path';
import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import ApiError from '../../abstractions/ApiError';
import ActivityLogs from '../../database/models/business/activityLogs';
import Attachments from '../../database/models/business/attachments';
import logger from '../../lib/logger';
import upload from '../../utils/fileUpload';
import BaseApi from '../BaseApi';
import AttachmentsAir from '../../database/models/business/attachmentsAir';
import AttachmentsWheat from '../../database/models/business/attachmentsWheat';
import AttachmentsOil from '../../database/models/business/attachmentsOil';
import Database from '../../database';
import AttachmentsPayment from '../../database/models/business/attachmentsPayment';

/**
 * Status controller
 */
export default class FilesController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/file/:filename', this.getAttachment.bind(this));
		this.router.post('/deleteFile', this.deleteAttachment.bind(this));
		this.router.post('/file', upload.any(), this.saveAttachment.bind(this));
		return this.router;
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getAttachment(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		const { filename, extension } = req.params;
		const filePath = `/FILES/${filename}`;
		console.log('File Api called');
		// Check if the file exists
		fs.readFile(filePath, (err, data) => {
			if (err) {
				console.error(err);
				return res.status(404).send('File not found');
			}

			// Convert file content to base64
			const base64Data = Buffer.from(data).toString('base64');

			const fileExtension = path.extname(filename).toLowerCase();
			const mimeTypes: { [key: string]: string } = {
				'.jpg': 'image/jpeg',
				'.jpeg': 'image/jpeg',
				'.png': 'image/png',
				'.gif': 'image/gif',
				'.bmp': 'image/bmp',
				'.webp': 'image/webp',
				'.pdf': 'application/pdf',
				'.doc': 'application/msword',
				'.docx':
					'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				// Add more image MIME types for other formats as needed
			};

			const mimeType =
				mimeTypes[fileExtension] || 'application/octet-stream';

			// Create Data URI from base64 data with appropriate MIME type
			res.locals.data = {
				data: `data:${mimeType};base64,${base64Data}`,
			};
			super.send(res);
		});
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async deleteAttachment(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { data } = req.body;
			const { PROCUREMENTID, FIELDNAME, DOCNAME } = data;

			await Attachments.destroy({
				where: {
					PROCUREMENTID,
					DOCNAME,
					FIELDNAME,
				},
			});
			const filePath = `/FILES/${DOCNAME}`;
			// Check if the file exists
			if (fs.existsSync(filePath)) {
				fs.unlinkSync(filePath);
				res.locals.data = {
					message: 'File Deleted successfully.',
				};
				super.send(res);
			} else {
				logger.error(`Cannot find the Attachment : ${DOCNAME}`);
				throw new ApiError(
					`Cannot find the Attachment : ${DOCNAME}`,
					StatusCodes.BAD_REQUEST,
					res,
				);
			}
		} catch (err) {
			logger.error(
				`Error while Deleting Attachment : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async saveAttachment(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const transaction = await Database.getConnection().transaction();
			const { uuidfileName, ID, fieldName, TYPE } = req.body;
			const { USERID } = req.query;
			let AttachmentModel;
			switch (TYPE) {
				case 'FZ':
					AttachmentModel = Attachments;
					break;
				case 'AIR':
					AttachmentModel = AttachmentsAir;
					break;
				case 'OIL':
					AttachmentModel = AttachmentsOil;
					break;
				case 'WHEAT':
					AttachmentModel = AttachmentsWheat;
					break;
				case 'PAYMENTS':
					AttachmentModel = AttachmentsPayment;
					break;
				default:
					throw new ApiError(
						'Invalid attachment type',
						StatusCodes.BAD_REQUEST,
						res,
					);
			}

			const data = await AttachmentModel.create(
				{
					DOCNAME: uuidfileName,
					FIELDNAME: fieldName,
					PROCUREMENTID: ID,
				},
				{ transaction },
			);

			await ActivityLogs.create(
				{
					USERID,
					fieldName,
					DATA: {
						FILENAME: uuidfileName,
						MSG: 'File has been updated',
					},
				},
				{ transaction },
			);

			await transaction.commit();
			res.locals.data = {
				message: 'File updated successfully.',
			};
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in Storing File : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}
}
