import BaseApi from "../../BaseApi";
import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Op, Sequelize } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import MaterialMaster from '../../../database/models/business/materialMaster/materialMaster'
import logger from "../../../lib/logger";

export default class MaterialMasterController extends BaseApi {


    constructor() {
        super();
    }

    public register(): Router {
        this.router.get(
            '/getallmaterialmasterData',
            this.getallmaterialmasterData.bind(this),
        );

        return this.router;
    }

    public async getallmaterialmasterData(req: Request, res: Response, next: NextFunction) {
        try {
            const masterDt = await MaterialMaster.findAll({
                attributes: [
                    'ID',
                    'MATERIAL',
                    'MATERIALNAME',
                    'MATERIALGROUP',
                    'MATERIALBASEUNIT',
                    'HSNCODE'
                ],
                raw: true,
            })
            res.locals.data = {
                masterDt
            }
            super.send(res)
        } catch (error) {
            logger.error(`Error While Retreiving Master Data, ${error}`)
            throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error)
        }
    }

}