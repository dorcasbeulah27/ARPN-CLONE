import { NextFunction, Request, Response, Router } from 'express';
import BaseApi from '../../BaseApi';
import { StatusCodes } from 'http-status-codes';
import { Op, Sequelize, Transaction } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import Reports from '../../../database/models/business/reports/reports';
import logger from '../../../lib/logger';
import comboMaster from '../../../database/models/masters/comboMaster';
import Database from '../../../database';
import ActivityLogs from '../../../database/models/business/activityLogs';
import SectionsMaster from '../../../database/models/masters/sectionsMaster';
import FormFieldsMaster from '../../../database/models/masters/formFieldsMaster';
import FormConfigMapping from '../../../database/models/masters/formConfigMapping';
import Pfiitems from '../../../database/models/business/procurement/pfiItems';
import Payment from '../../../database/models/business/payment/payment';
import AttachmentsPayment from '../../../database/models/business/attachmentsPayment';

export default class PaymentController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get(
			'/getPaymentReports',
			this.getPaymentReports.bind(this),
		);
		this.router.get(
			'/getFormMEntriesPayment',
			this.getFormMEntriesPayment.bind(this),
		);

		this.router.get(
			'/getPurchaseOrderPayment',
			this.getPurchaseOrderPayment.bind(this),
		);

		this.router.post(
			'/postPFIEntryPayment',
			this.postPFIEntryPayment.bind(this),
		);
		this.router.post(
			'/postPaymentInfo',
			this.postPaymentInfo.bind(this),
		);

		return this.router;
	}

	public async getPaymentReports(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { ID } = req.query;
			const procurementPaymentData = await Payment.findAll({
				attributes: [
					'REMARKS',
					'PONO',
					'PURPOSE',
					'PURPOSE',
					'DEBIT',
					'ACCOUNTNUMBER',
					'BANK',
					'CURRENCY',
					'AMOUNT',
					'BENEFICIARYNAME',
					'DATE',
				],

				raw: true,
			});

			const finalReport = procurementPaymentData.map((data, index) => ({
				...data,
			}));

			const formFields = await Reports.findAll({
				where: {
					REPORTID: 9,
					ACTIVE: true,
				},
				raw: true,
			});
			const headerData = formFields.reduce((acc, curr) => {
				acc[(curr as any).FIELDNAME] = {
					SEQUENCE: (curr as any).FIELDSEQUENCE,
					DESC: (curr as any).FIELDDESCRIPTION,
				};
				return acc;
			}, {});
			res.locals.data = {
				data: {
					HEADER: headerData,
					DETAIL: finalReport,
				},
			};
			super.send(res);
		} catch (error) {
			logger.error(
				`Error in fetching payment reports : ${error.message}\n${error.stack}`,
			);
			throw new ApiError(error.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getFormMEntriesPayment(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getFormMEntriesPayment initalized');

			const factoriesList = await comboMaster.findAll({
				where: {
					FIELDID: 15,
				},
				raw: true,
			});

			const consolidatedFactories = factoriesList.reduce((acc, curr) => {
				acc[(curr as any).VALUE] = (curr as any).LABEL;
				return acc;
			}, {});

			const procurement = await Payment.findAll({
				raw: true,
				order: [['createdAt', 'desc']],
			});

			res.locals.data = {
				data: procurement.map((e) => {
					const formId = 8;
					e['STAGES'] = [
						{ NAME: 'Payment', STATUS: (e as any).STATUS },
					];
					e['FORMID'] = formId;
					e['FACTORYNAME'] =
						consolidatedFactories[(e as any).FACTORY];
					return e;
				}),
			};
			super.send(res);
			console.log('getFormMEntriesPayment API completed');
		} catch (err) {
			logger.error(
				`Error in getFormMEntriesPayment : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getPurchaseOrderPayment(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getPurchaseOrder Wheat initalized');
			const { OUID = 1, ID } = req.query;

			const procurement = await Payment.findOne({
				where: {
					ID,
				},
				raw: true,
			});

			const attachments = await AttachmentsPayment.findAll({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const attachmentsConsolidated = attachments.reduce((acc, curr) => {
				if (acc[(curr as any).FIELDNAME]) {
					acc[(curr as any).FIELDNAME].push(curr);
				} else {
					acc[(curr as any).FIELDNAME] = [curr];
				}
				return acc;
			}, {});

			const formId = 8;
			const stage = [
				{ NAME: 'Payment', STATUS: (procurement as any).STATUS },
			];

			const finalData = {
				STAGES: stage,
				FORMID: formId,
				...procurement,
				...attachmentsConsolidated,
			};

			res.locals.data = { data: finalData };
			super.send(res);
			console.log('getPurchaseOrder API completed');
		} catch (err) {
			logger.error(
				`Error in getPurchaseOrder for payment: ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */

	public async postPFIEntryPayment(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		const transaction = await Database.getConnection().transaction();
		try {
			console.log('postPaymentInfoData initalized');
			const { data } = req.body;
			const { OUID = 1, ROLEID = 1 } = req.query;

			const { itemDetails = [] } = data;

			const pfiInfo = await Payment.findAll({
				where: {
					PFINO: data?.PFINO,
				},
				raw: true,
				transaction,
			});

			if (pfiInfo.length) {
				logger.error(
					'Error in postPFIInfoPaymentData : PFI is already available',
				);
				throw new ApiError(
					'PFI already exists',
					StatusCodes.BAD_REQUEST,
					res,
				);
			} else {
				let lcInfo = await Payment.create(data, {
					transaction,
				});

				lcInfo = JSON.parse(JSON.stringify(lcInfo));

				if (itemDetails.length > 0) {
					const PFIItems = await Pfiitems.bulkCreate(
						itemDetails.map((e) => ({
							...e,
							OUID,
							PFINO: data.PFINO || '',
							PROCUREMENTID: (lcInfo as any)?.ID,
						})),
						{ transaction },
					);
				}

				const formType = await FormConfigMapping.findOne({
					where: {
						FACTORY: 'PAYMENT',
						TYPEOFMATERIAL: 'PAYMENT',
						ACTIVE: true,
					},
					raw: true,
					transaction,
				});

				if ((formType as any)?.ACTIVE) {
					const distinctSectionIds = await FormFieldsMaster.findAll({
						attributes: ['SECTIONID'],
						include: [
							{
								model: SectionsMaster,
								attributes: ['SECTIONNAME', 'SECTIONSEQUENCE'], // Selecting SECTION from SectionsMaster
								as: 'section',
								where: {
									ACTIVE: true,
								},
							},
						],
						where: {
							FORMID: (formType as any).FORMID,
							ROLEID,
						},
						raw: true,
						transaction,
						group: [
							'SECTIONID',
							'section.SECTIONNAME',
							'section.SECTIONSEQUENCE',
						],
					});

					await Payment.update(
						{ STATUS: true },
						{ where: { PFINO: data.PFINO } },
					);

					console.log('postPFIInfoPaymentData API completed');
				} else {
					logger.error(
						'Error in postPFIInfoPaymentData : No Form Configuration found',
					);
					throw new ApiError(
						'No Form Configuration found',
						StatusCodes.BAD_REQUEST,
						res,
					);
				}

				await transaction.commit();
				res.locals.data = {
					message: 'PFI created successfully.',
					// data: distinctSectionIds,
				};

				super.send(res);
				console.log('postPFIInfoPaymentData API completed');
			}
		} catch (err) {
			transaction.rollback();
			logger.error(
				`Error in postPaymentInfoData : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	public async postPaymentInfo(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		const transaction = await Database.getConnection().transaction({
			isolationLevel: Transaction.ISOLATION_LEVELS.READ_COMMITTED,
		});
		try {
			console.log('postPaymentInfo initalized');
			const { data, FLAG } = req.body;
			const { OUID = 1, USERID } = req.query;
			const finalObj = { ...data, OUID };
			const { SECTIONNAME = '' } = data;

			if (!SECTIONNAME) {
				await transaction.rollback();
				throw new ApiError(
					'Invalid Section Name',
					StatusCodes.BAD_REQUEST,
					res,
				);
			}

			if (SECTIONNAME === 'PROCUREMENT') {
				const ProcurementInfo = await Payment.findOne({
					where: {
						ID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if ((ProcurementInfo as any)?.STATUS) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((ProcurementInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await Payment.update(
							{ ...x, STATUS: data?.FLAG === 'COMPLETED' },
							{
								where: {
									ID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await Payment.create(
							{
								...x,
								STATUS: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					if (data?.ITEMDETAILSFLAG) {
						await Pfiitems.destroy({
							where: {
								PROCUREMENTID: data?.ID,
							},
							transaction,
						});

						await Pfiitems.bulkCreate(
							data?.ITEMDETAILS?.map(
								(element) => {
									const d = { ...element };
									if (d.ID) {
										delete d.ID;
									}
									return {
										...d,
										PROCUREMENTID: data?.ID,
										OUID,
										PFINO: data?.PFINO,
										PONO: data?.PONO,
									};
								},
								{ transaction },
							),
						);
					}

					const attachments = [];
					const attachmentsData = [];
					if (data?.PFIATTACHMENTFLAG) {
						attachments.push('PFIATTACHMENT');
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'PFIATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}
					if (data?.POATTACHMENTFLAG) {
						attachments.push('POATTACHMENT');
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'POATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}
					if (data?.PRATTACHMENTFLAG) {
						attachments.push('PRATTACHMENT');
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'PRATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (attachmentsData?.length) {
						await AttachmentsPayment.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await AttachmentsPayment.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}
			}

			await ActivityLogs.create(
				{
					USERID,
					SECTIONNAME,
					DATA: data,
				},
				{ transaction },
			);

			await transaction.commit();
			res.locals.data = {
				message: 'Data updated successfully.',
				ID: data?.ID,
			};
			super.send(res);
			console.log('postPurchaseOrder API completed');
		} catch (err) {
			await transaction.rollback();
			logger.error(
				`Error in postPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}
}
