import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Op, Sequelize, Transaction, where } from 'sequelize';
import transaction from 'sequelize/types/transaction';
import ApiError from '../../../abstractions/ApiError';
import Database from '../../../database';
import LiquidationTreasuryInfo from '../../../database/models/business/liquidationTreasury/liquidationTreasuryInfo';
import LiquidationTreasuryPayment from '../../../database/models/business/liquidationTreasury/liquidationTreasuryPayment';
import Pfiitems from '../../../database/models/business/procurement/pfiItems';
import Procurement from '../../../database/models/business/procurement/procurement';
import Shipment from '../../../database/models/business/shipment/shipment';
import Tradefinance from '../../../database/models/business/tradeFinance/tradeFinance';
import LC from '../../../database/models/business/ttlc/lc';
import logger from '../../../lib/logger';
import BaseApi from '../../BaseApi';

export default class liquidationTreasuryController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get(
			'/getliquidationdata',
			this.getliquidationdata.bind(this),
		);
		this.router.post('/postpaymentInfo', this.postpaymentInfo.bind(this));
		this.router.post(
			'/postliquidationInfo',
			this.postliquidationInfo.bind(this),
		);
		return this.router;
	}

	public async getliquidationdata(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { ID } = req.query;
			console.log('ID: ', ID);

			const procurementExists = await Procurement.findOne({
				where: { ID },
			});

			if (!procurementExists) {
				throw new Error('ID does not exists.');
			}

			const procurementData = await Procurement.findOne({
				where: { ID },
				raw: true,
			});

			const tradeFinance = await Tradefinance.findOne({
				attributes: [
					'FORMMNAMEOFBANK',
					'FORMMSUBMITTEDDATE',
					'FORMMREGISTEREDDATE',
					'FORMMNO',
				],
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const shipmentInfoDData = await Shipment.findOne({
				attributes: ['BLDATE', 'COMMERCIALINVOICEAMOUNT'],
				where: { PROCUREMENTID: ID },
				include: [{ model: Procurement, as: 'PROCUREMENTINFO' }],
				raw: true,
			});

			console.log('BLDATE: ', (shipmentInfoDData as any)?.BLDATE);

			const itemData = await Pfiitems.findOne({
				attributes: ['ITEMDESCRIPTION'],
				where: { PROCUREMENTID: ID },
				include: [{ model: Procurement, as: 'PROCUREMENTINFO' }],
				raw: true,
			});

			const lcData = await LC.findOne({
				attributes: [
					'LCLATESTSHIPMENTDATE',
					'LCDATE',
					'LCNUMBER',
					'LCAMOUNTWITHTOLERANCE',
					'BANK',
				],
				where: { PROCUREMENTID: ID },
				include: [{ model: Procurement, as: 'PROCUREMENTINFO' }],
				raw: true,
			});

			const paymentData = await LiquidationTreasuryPayment.findOne({
				attributes: ['MODEOFPAYMENT', 'BANKNAME', 'ISPAYMENTDONE'],
				where: { PROCUREMENTID: ID },
				include: [{ model: Procurement, as: 'PROCUREMENTINFO' }],
				raw: true,
			});

			const liquidationData = await LiquidationTreasuryInfo.findAll({
				attributes: [
					'SELECTEDDATE',
					'LIQUIDATIONAMOUNT1',
					'SOURCEOFFUNDS',
					'EXCHANGERATE',
				],
				where: { PROCUREMENTID: ID },
				include: [{ model: Procurement, as: 'PROCUREMENTINFO' }],
				raw: true,
			});

			// const flattenedProcurementData = Object.keys(lcData).reduce((acc, key) => {
			// 	if (key.startsWith('PROCUREMENTINFO.')) {
			// 		const newKey = key.replace('PROCUREMENTINFO.', '');
			// 		acc[newKey] = lcData[key];
			// 	} else {
			// 		acc[key] = lcData[key];
			// 	}
			// 	return acc;
			// }, {});

			const formatDate = (date) => {
				if (!date) return '';
				return new Date(date).toLocaleDateString();
			};

			const shipmentData = {
				PONO: (procurementData as any)?.PONO,
				PFINO: (procurementData as any)?.PFINO,
				ITEMNAME: (itemData as any)?.ITEMDESCRIPTION,
				ITEMTYPE: (procurementData as any)?.TYPEOFMATERIAL,
			};
			const transactions = {
				SUPPLIERNAME: (procurementData as any)?.SUPPLIERNAME,
				APPLICANT: (procurementData as any)?.FACTORY,
				PAYMENTTERMS: (procurementData as any)?.PAYMENTTERMS,
				CURRENCY: (procurementData as any)?.CURRENCY,
				PFIAMOUNT: (procurementData as any)?.PFIAMOUNT,
				PFINO: (procurementData as any)?.PFINO,
				SUPPLIERBANKDETAILS: (procurementData as any)
					?.SUPPLIERBANKDETAILS,
				LCLATESTSHIPMENTDATE: formatDate(
					(lcData as any)?.LCLATESTSHIPMENTDATE,
				),
				LCDATE: formatDate((lcData as any)?.LCDATE),
			};
			console.log(
				'LCLATESTSHIPMENTDATE: ',
				transactions.LCLATESTSHIPMENTDATE,
			);
			const bankingInformation = {
				FORMMNO: (tradeFinance as any)?.FORMMNO,
				FORMMSUBMITTEDDATE: formatDate(
					(tradeFinance as any)?.FORMMSUBMITTEDDATE,
				),
				LCNUMBER: (lcData as any)?.LCNUMBER,
				LCDATE: formatDate((lcData as any)?.LCDATE),
				LCAMOUNTWITHTOLERANCE: (lcData as any)?.LCAMOUNTWITHTOLERANCE,
				BANK: (lcData as any)?.BANK,
				PFIMODEOFPAYMENT: (procurementData as any)?.PFIMODEOFPAYMENT,
			};

			const shipmentInfo = {
				BLDATE: formatDate((shipmentInfoDData as any)?.BLDATE),
				SHIPMENTAMOUNT: (shipmentInfoDData as any)
					?.COMMERCIALINVOICEAMOUNT,
			};

			const paymentInfo = {
				MODEOFPAYMENT: (paymentData as any)?.MODEOFPAYMENT,
				BANKNAME: (paymentData as any)?.BANKNAME,
				ISPAYMENTDONE: (procurementData as any)?.ISPAYMENTDONE,
			};

			const liquidationDataMapper = liquidationData.map((liqui) => ({
				SELECTEDDATE: formatDate((liqui as any)?.SELECTEDDATE),
				LIQUIDATIONAMOUNT1: (liqui as any)?.LIQUIDATIONAMOUNT1,
				SOURCEOFFUNDS: (liqui as any)?.SOURCEOFFUNDS,
				ENTEREDVALUE: (liqui as any)?.ENTEREDVALUE,
			}));

			const responseData = {
				shipmentData,
				transactionsData: transactions,
				bankingData: bankingInformation,
				shipmentinfo: shipmentInfo,
				paymentInfo,
				liquidationInfo: liquidationDataMapper,
			};

			res.locals.data = { data: responseData };
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getting liquidation treasury: ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	// public async postpaymentInfo(req: Request,
	// 	res: Response,
	// 	next: NextFunction) {
	// 		const transaction = await Database.getConnection().transaction();
	// 	try {
	// 		// const { MODEOFPAYMENT, BANKNAME, PROCUREMENTID } = req.body.data
	// 		const { data } = req.body
	// 		const { MODEOFPAYMENT, BANKNAME, PROCUREMENTID } = data[0]

	// 		if (!MODEOFPAYMENT || !BANKNAME || !PROCUREMENTID) {
	//             return res.status(400).json({ error: 'MODEOFPAYMENT, BANKNAME, and PROCUREMENTID are required fields.' });
	//         }

	// 		const paymentDt = await LiquidationTreasuryPayment.create({
	// 			MODEOFPAYMENT, BANKNAME, PROCUREMENTID
	// 		}, { transaction }
	// 	)
	// 	const updateFlag = await Procurement.update(
	// 		{ ISPAYMENTDONE: true },
	// 		{ where: { ID: PROCUREMENTID }, returning: true }
	// 	);
	// 	console.log('updateFlag: ', updateFlag[0]);

	// 	const updateDt =   await LC.update({ BANK: BANKNAME }, { where: { PROCUREMENTID }, transaction });
	// 		await transaction.commit()
	// 		const finalData = { paymentDt, ...updateFlag}
	// 		res.locals.data = {
	// 			message: "Data updated successfully.",
	// 			finalData,
	// 		}
	// 		super.send(res)
	// 	} catch (err) {
	// 		await transaction.rollback()
	// 		logger.error(
	// 			`Error in posting payment info : ${err.message}\n${err.stack}`,
	// 		);
	// 		throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);

	// 	}
	// }

	public async postpaymentInfo(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		const transaction = await Database.getConnection().transaction();
		try {
			// const { MODEOFPAYMENT, BANKNAME, PROCUREMENTID } = req.body.data
			const { data } = req.body;
			const { MODEOFPAYMENT, BANKNAME, PROCUREMENTID } = data;

			if (!MODEOFPAYMENT || !BANKNAME || !PROCUREMENTID) {
				return res.status(400).json({
					error: 'MODEOFPAYMENT, BANKNAME, and PROCUREMENTID are required fields.',
				});
			}

			const paymentDt = await LiquidationTreasuryPayment.create(
				{
					MODEOFPAYMENT,
					BANKNAME,
					PROCUREMENTID,
				},
				{ transaction },
			);

			const [numUpdatedRows, updatedRows] = await Procurement.update(
				{ ISPAYMENTDONE: true },
				{ where: { ID: PROCUREMENTID }, returning: true },
			);

			const updatedProcurement: any = updatedRows[0];
			console.log('updatedProcurement: ', updatedProcurement);

			const updateDt = await LC.update(
				{ BANK: BANKNAME },
				{ where: { PROCUREMENTID }, transaction },
			);
			await transaction.commit();

			const finalData = {
				paymentDt,
				ISPAYMENTDONE: updatedProcurement.ISPAYMENTDONE,
			};

			res.locals.data = {
				message: 'Data updated successfully.',
				finalData,
			};

			super.send(res);
		} catch (err) {
			await transaction.rollback();
			logger.error(
				`Error in posting payment info : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	public async postliquidationInfo(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		const transaction = await Database.getConnection().transaction();
		try {
			const { PROCUREMENTID, LIQUIDATIONINFO } = req.body.data;

			const bankInof = await LiquidationTreasuryPayment.findOne({
				where: {
					PROCUREMENTID,
				},
				raw: true,
			});

			LiquidationTreasuryInfo.bulkCreate(
				LIQUIDATIONINFO.map(async (element) => ({
					...element,
					BANKNAME: (bankInof as any).BANKNAME,
					EXCHANGERATE:
						parseFloat(element.MRATE) ||
						parseFloat(element.EXCHANGERATE) ||
						0,
					LIQUIDATIONAMOUNT1: parseFloat(element.LIQUIDATIONAMOUNT1) || 0,
				})),
			);

			res.locals.data = {
				message: 'Data updated successfully.',
			};
			super.send(res);
		} catch (err) {
			await transaction.rollback();

			logger.error(
				`Error in posting liquidation info: ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}
}
