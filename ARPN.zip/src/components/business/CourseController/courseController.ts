import { NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';

import BaseApi from '../../BaseApi';
import ApiError from '../../../abstractions/ApiError';

import logger from '../../../lib/logger';
import Courses from '../../../database/models/business/coursesTable/courses';

/**
 * User Management controller
 */
export default class courseController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/getAllCourses', this.getAllCourses.bind(this));
		this.router.post('/createCourse', this.createCourse.bind(this));
		this.router.put('/updateCourse/:id', this.updateCourse.bind(this));
		this.router.delete('/deleteCourse/:id', this.deleteCourse.bind(this));
		this.router.post(
			'/defaultCourse',
			this.insertDefaultCourses.bind(this),
		);

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	public async getAllCourses(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('getAllUsers api has been invoked');
			const users = await Courses.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createCourse(req: Request, res: Response) {
		try {
			logger.info('createStudent api has been invoked');
			const { data } = req.body;
			const studentDetails = await Courses.bulkCreate(data);

			res.locals.data = JSON.parse(JSON.stringify(studentDetails));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in createStudent : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async updateCourse(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('updateUser api has been invoked');
			const { id } = req.params;
			const { data } = req.body;
			const user = await Courses.update(data, { where: { id } });
			res.locals.data = JSON.parse(JSON.stringify(user));
			super.send(res);
		} catch (err) {
			logger.error(`Error in updateUser : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	public async deleteCourse(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('deleteUser api has been invoked');
			const { id } = req.params;
			console.log('id', id);
			const { data } = req.body;
			const user = await Courses.destroy({ where: { ID: id } });
			res.locals.data = { user };
			super.send(res);
		} catch (err) {
			logger.error(`Error in deleteUser : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	async insertDefaultCourses(req: Request, res: Response) {
		try {
			await Courses.bulkCreate([
				{ id: 1, courseName: 'BCA' },
				{ id: 2, courseName: 'BBA' },
				{ id: 3, courseName: 'B.COM' },
				{ id: 4, courseName: 'VSCOM' },
			]);
			res.status(200).json({ message: 'Courses inserted successfully' });
		} catch (error) {
			console.error('Error inserting Courses:', error);
			res.status(500).json({
				message: 'Failed to insert courses',
				error,
			});
		}
	}
}
