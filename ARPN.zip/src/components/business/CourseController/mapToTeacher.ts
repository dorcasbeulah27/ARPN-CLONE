import { NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';

import BaseApi from '../../BaseApi';
import ApiError from '../../../abstractions/ApiError';

import logger from '../../../lib/logger';
import courseMapToTeacher from '../../../database/models/business/coursesTable/courseMapToTeacher';
import Students from '../../../database/models/business/studentTable/students';
import StudentMapToCourse from '../../../database/models/business/studentTable/studentMapToCourse';
import StudentMapToTeacher from '../../../database/models/business/studentTable/studentMapToTeacher';
import Teachers from '../../../database/models/business/teachersTable/teachers';
import Courses from '../../../database/models/business/coursesTable/courses';
import { Op } from 'sequelize';

/**
 * User Management controller
 */
export default class mapToTeacher extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/getAll', this.getAll.bind(this));
		this.router.get(
			'/getTndCfromStudent',
			this.getTndCfromStudent.bind(this),
		);

		this.router.post(
			'/defaultCourse-Teacher',
			this.insertCourseMapToTeacher.bind(this),
		);
		return this.router;
	}

	public async getTndCfromStudent(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { studentName } = req.query;
			const studentId = await Students.findOne({
				where: { studentName },
				attributes: ['id'],
				raw: true,
			});

			console.log(studentId.dataValues);
			const sMapC = await StudentMapToCourse.findAll({
				where: { studentId: (studentId as any).id },
				attributes: ['courseId'],
				raw: true,
			});
			console.log('student mapped to the course', sMapC);
			const sMapT = await StudentMapToTeacher.findAll({
				where: { studentId: (studentId as any).id },
				attributes: ['teacherId'],
				raw: true,
			});
			console.log('students mapped to the teachers', sMapT);
			const teacherArr = sMapT.reduce((acc, obj) => {
				acc.push((obj as any).teacherId);
				return acc;
			}, []);
			console.log(teacherArr);
			const courseArr = sMapC.reduce((acc, obj) => {
				acc.push((obj as any).courseId);
				return acc;
			}, []);
			console.log(courseArr);
			const teacherName = await Teachers.findAll({
				where: {
					id: { [Op.in]: teacherArr },
				},
				attributes: ['TeacherName'],
				raw: true,
			});
			const CourseName = await Courses.findAll({
				where: {
					id: { [Op.in]: courseArr },
				},
				attributes: ['courseName'],
				raw: true,
			});
			console.log(CourseName, teacherName);
			// res.locals.data = JSON.parse(
			// 	JSON.stringify(
			// 		`STUDENT:${studentName} COURSE:${CourseName} TEACHER:${teacherName}`,
			// 	),
			// );
			res.locals.data = {
				studentName,
				CourseName,
				teacherName: teacherName,
			};
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getAllStudents : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	public async getAll(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllUsers api has been invoked');
			const users = await courseMapToTeacher.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	async insertCourseMapToTeacher(req: Request, res: Response) {
		try {
			await courseMapToTeacher.bulkCreate([
				{ id: 1, courseId: 1, TeacherId: 1 },
				{ id: 2, courseId: 2, TeacherId: 1 },
				{ id: 3, courseId: 1, TeacherId: 2 },
				{ id: 4, courseId: 2, TeacherId: 2 },
				{ id: 5, courseId: 3, TeacherId: 3 },
				{ id: 6, courseId: 4, TeacherId: 3 },
				{ id: 7, courseId: 3, TeacherId: 4 },
				{ id: 8, courseId: 4, TeacherId: 4 },
			]);
			res.status(200).json({
				message: 'Course-Teacher Mappings inserted successfully',
			});
		} catch (error) {
			console.error('Error inserting Course-Teacher Mappings:', error);
			res.status(500).json({
				message: 'Failed to insert course-teacher mappings',
				error,
			});
		}
	}
}
