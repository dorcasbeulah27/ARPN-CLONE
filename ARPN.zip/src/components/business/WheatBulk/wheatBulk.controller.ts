import fs from 'fs';
import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Op, Sequelize, Transaction } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import Database from '../../../database';
import ActivityLogs from '../../../database/models/business/activityLogs';
import AttachmentsWheat from '../../../database/models/business/attachmentsWheat';
import ClearanceWheat from '../../../database/models/business/clearanceWheat/clearanceWheat';
import PfiitemsWheat from '../../../database/models/business/procurementWheat/pfiItems';
import ProcurementWheat from '../../../database/models/business/procurementWheat/procurement';
import PolcsectionstatusWheat from '../../../database/models/business/purchaseOrder/poLcSectionStatusWheat';
import Reports from '../../../database/models/business/reports/reports';
import TradeFinanceWheatModel from '../../../database/models/business/tradeFinanceWheat/tradeFinanceWheat';
import comboMaster from '../../../database/models/masters/comboMaster';
import FormConfigMapping from '../../../database/models/masters/formConfigMapping';
import FormFieldsMaster from '../../../database/models/masters/formFieldsMaster';
import SectionsMaster from '../../../database/models/masters/sectionsMaster';
import TradeFinanceWheat from '../../../database/models/business/tradeFinanceWheat/tradeFinanceWheat';
import logger from '../../../lib/logger';
import BaseApi from '../../BaseApi';

/**
 * Status controller
 */
export default class WheatBulksController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get(
			'/getFormMEntriesWheat',
			this.getFormMEntriesWheat.bind(this),
		);
		this.router.post('/postPFIWheat', this.postPFIWheat.bind(this));
		this.router.get(
			'/getPurchaseOrderWheat',
			this.getPurchaseOrderWheat.bind(this),
		);
		this.router.get(
			'/getPurchaseOrderWheat',
			this.getPurchaseOrderWheat.bind(this),
		);
		this.router.get(
			'/getcommercialWheatReports',
			this.getcommercialWheatReports.bind(this),
		);
		this.router.get(
			'/getoperationsWheatReports',
			this.getoperationsWheatReports.bind(this),
		);
		this.router.post('/postLCInfoWheat', this.postLCInfoWheat.bind(this));
		return this.router;
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getFormMEntriesWheat(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getFormMEntriesWheat initalized');

			const factoriesList = await comboMaster.findAll({
				where: {
					FIELDID: 15,
				},
				raw: true,
			});

			const consolidatedFactories = factoriesList.reduce((acc, curr) => {
				acc[(curr as any).VALUE] = (curr as any).LABEL;
				return acc;
			}, {});

			const procurement = await ProcurementWheat.findAll({
				raw: true,
				order: [['createdAt', 'desc']],
			});

			const statusData = await PolcsectionstatusWheat.findAll({
				attributes: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				raw: true,
				group: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				order: [['SECTIONSEQUENCE', 'asc']],
			});

			const consolidatedData = statusData.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...acc[(curr as any).PROCUREMENTID],
					[(curr as any).SECTIONAME]: {
						STATUS: (curr as any).STATUS,
						SECTIONSEQUENCE: (curr as any).SECTIONSEQUENCE,
						SECTIONAME: (curr as any).SECTIONAME,
					},
					FORMID: (curr as any).FORMID,
				};
				return acc;
			}, {});

			res.locals.data = {
				data: procurement.map((e) => {
					console.log(Object.values(consolidatedData[(e as any).ID]));
					const d = Object.values(
						consolidatedData[(e as any).ID],
					).reduce((acc, curr) => {
						acc[(curr as any).SECTIONSEQUENCE - 1] = {
							NAME: (curr as any).SECTIONAME,
							STATUS: (curr as any).STATUS,
						};
						return acc;
					}, []);

					const formId = consolidatedData[(e as any).ID]?.FORMID || 6;
					// delete d.FORMID;
					e["STAGES"] = d;
					e["FORMID"] = formId;
					e["FACTORYNAME"] =
						consolidatedFactories[(e as any).FACTORY];
					return e;
				}),
			};
			super.send(res);
			console.log('postPurchaseOrder API completed');
		} catch (err) {
			logger.error(
				`Error in postPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async postPFIWheat(req: Request, res: Response, next: NextFunction) {
		const transaction = await Database.getConnection().transaction();
		try {
			console.log('postPFIData initalized');
			const { data } = req.body;
			const { OUID = 1, ROLEID = 1 } = req.query;

			const { itemDetails = [] } = data;

			const pfiInfo = await ProcurementWheat.findAll({
				where: {
					PFINO: data?.PFINO,
				},
				raw: true,
				transaction,
			});

			if (pfiInfo.length) {
				// logger.error('Error in postPFIData : PFI is already available');
				// throw new ApiError(
				// 	'PFI already exists',
				// 	StatusCodes.BAD_REQUEST,
				// 	res,
				// );
			} else {
				let lcInfo = await ProcurementWheat.create(data, {
					transaction,
				});

				lcInfo = JSON.parse(JSON.stringify(lcInfo));

				if (itemDetails.length > 0) {
					const PFIItems = await PfiitemsWheat.bulkCreate(
						itemDetails.map((e) => ({
							...e,
							OUID,
							PFINO: data.PFINO || '',
							PROCUREMENTID: (lcInfo as any)?.ID,
						})),
						{ transaction },
					);
				}

				const formType = await FormConfigMapping.findOne({
					where: {
						FACTORY: 'WHEAT',
						ACTIVE: true,
					},
					raw: true,
					transaction,
				});

				if ((formType as any)?.ACTIVE) {
					const distinctSectionIds = await FormFieldsMaster.findAll({
						attributes: ['SECTIONID'],
						include: [
							{
								model: SectionsMaster,
								attributes: ['SECTIONNAME', 'SECTIONSEQUENCE'], // Selecting SECTION from SectionsMaster
								as: 'section',
								where: {
									ACTIVE: true,
								},
							},
						],
						where: {
							FORMID: (formType as any).FORMID,
							ROLEID,
							ACTIVE: true,
						},
						raw: true,
						transaction,
						group: [
							'SECTIONID',
							'section.SECTIONNAME',
							'section.SECTIONSEQUENCE',
						],
					});

					await PolcsectionstatusWheat.bulkCreate(
						distinctSectionIds.map((element) => ({
							OUID,
							PROCUREMENTID: (lcInfo as any)?.ID || 0,
							PROCUREMENTSEQUENCE: (lcInfo as any)?.ID || 0,
							FORMMNO: data?.FORMMNO || '',
							FORMID: (formType as any).FORMID,
							SECTIONAME: element['section.SECTIONNAME'],
							SECTIONSEQUENCE: element['section.SECTIONSEQUENCE'],
							STATUS: 'NEW',
						})),
						{
							transaction,
						},
					);

					console.log('PFI entry API completed');
				} else {
					logger.error(
						'Error in PFI entry : No Form Configuration found',
					);
					throw new ApiError(
						'No Form Configuration found',
						StatusCodes.BAD_REQUEST,
						res,
					);
				}

				await transaction.commit();
				res.locals.data = {
					message: 'PFI created successfully.',
				};

				super.send(res);
				console.log('postPFI API completed');
			}
		} catch (err) {
			transaction.rollback();
			logger.error(`Error in postPFI : ${err.message}\n${err.stack}`);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getPurchaseOrderWheat(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getPurchaseOrder Wheat initalized');
			const { OUID = 1, ID } = req.query;

			const procurement = await ProcurementWheat.findOne({
				where: {
					ID,
				},
				raw: true,
			});

			const factory = await comboMaster.findOne({
				where: {
					FIELDID: 15,
					LABEL: (procurement as any)?.FACTORY,
				},
				raw: true,
			});

			// const poItems = await PoItems.findAll({
			// 	where: {
			// 		ID,
			// 	},
			// 	raw: true,
			// });
			const pfiItems = await PfiitemsWheat.findAll({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});
			const tradeFinance = await TradeFinanceWheat.findOne({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const clearance = await ClearanceWheat.findOne({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const attachments = await AttachmentsWheat.findAll({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const attachmentsConsolidated = attachments.reduce((acc, curr) => {
				if (acc[(curr as any).FIELDNAME]) {
					acc[(curr as any).FIELDNAME].push(curr);
				} else {
					acc[(curr as any).FIELDNAME] = [curr];
				}
				return acc;
			}, {});

			const statusData = await PolcsectionstatusWheat.findAll({
				attributes: [
					'FORMID',
					'PROCUREMENTID',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
				],
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
				group: [
					'FORMID',
					'PROCUREMENTID',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
				],
				order: [['SECTIONSEQUENCE', 'asc']],
			});

			const consolidatedData = statusData.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...acc[(curr as any).PROCUREMENTID],
					[(curr as any).SECTIONAME]: {
						STATUS: (curr as any).STATUS,
						SECTIONSEQUENCE: (curr as any).SECTIONSEQUENCE,
						SECTIONAME: (curr as any).SECTIONAME,
					},
					FORMID: (curr as any).FORMID,
				};
				return acc;
			}, {});

			const d = Object.values(
				consolidatedData[(procurement as any).ID],
			).reduce((acc, curr) => {
				console.log('curr==>', curr);
				if (isNaN(curr as any)) {
					acc[(curr as any).SECTIONSEQUENCE - 1] = {
						NAME: (curr as any).SECTIONAME,
						STATUS: (curr as any).STATUS,
					};
				}

				return acc;
			}, []);

			const formId =
				consolidatedData[(procurement as any).SEQUENCE]?.FORMID || 1;

			// delete d.FORMID;

			const finalData = {
				...clearance,
				...tradeFinance,
				STAGES: d,
				ITEMDETAILS: pfiItems,
				FORMID: formId,
				FACTORYNAME: (factory as any)?.LABEL || '',
				...procurement,
				...attachmentsConsolidated,
			};

			res.locals.data = {
				data: finalData,
			};
			super.send(res);
			console.log('getPurchaseOrder Wheat  API completed');
		} catch (err) {
			logger.error(
				`Error in getPurchaseOrder Wheat: ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async postLCInfoWheat(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		const transaction = await Database.getConnection().transaction({
			isolationLevel: Transaction.ISOLATION_LEVELS.READ_COMMITTED,
		});
		try {
			console.log('postPurchaseOrder initalized');
			const { data, FLAG } = req.body;
			const { OUID = 1, USERID } = req.query;
			const finalObj = { ...data, OUID };
			const { SECTIONNAME = '' } = data;

			if (!SECTIONNAME) {
				await transaction.rollback();
				throw new ApiError(
					'Invalid Section Name',
					StatusCodes.BAD_REQUEST,
					res,
				);
			}

			if (SECTIONNAME === 'PROCUREMENT') {
				const ProcurementInfo = await ProcurementWheat.findOne({
					where: {
						ID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if (
					(ProcurementInfo as any)?.SUBMITTED ||
					(ProcurementInfo as any)?.LOCKED
				) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((ProcurementInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await ProcurementWheat.update(
							{ ...x, SUBMITTED: data?.FLAG === 'COMPLETED' },
							{
								where: {
									ID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await ProcurementWheat.create(
							{
								...x,
								SUBMITTED: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					if (data?.ITEMDETAILSFLAG) {
						await PfiitemsWheat.destroy({
							where: {
								PROCUREMENTID: data?.ID,
							},
							transaction,
						});

						await PfiitemsWheat.bulkCreate(
							data?.ITEMDETAILS?.map(
								(element) => {
									const d = { ...element };
									if (d.ID) {
										delete d.ID;
									}
									return {
										...d,
										PROCUREMENTID: data?.ID,
										OUID,
										PFINO: data?.PFINO,
										PONO: data?.PONO,
									};
								},
								{ transaction },
							),
						);
					}

					const attachments = [];
					const attachmentsData = [];
					if (data?.PFIATTACHMENTFLAG) {
						attachments.push('PFIATTACHMENT');
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'PFIATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}
					if (data?.POATTACHMENTFLAG) {
						attachments.push('POATTACHMENT');
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'POATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}
					if (data?.SHIPMENTPLANNINGANDEXECUTIONATTACHMENTFLAG) {
						attachments.push(
							'SHIPMENTPLANNINGANDEXECUTIONATTACHMENT',
						);
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME:
									'SHIPMENTPLANNINGANDEXECUTIONATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (attachmentsData?.length) {
						await AttachmentsWheat.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await AttachmentsWheat.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}
			} else if (SECTIONNAME === 'TRADEFINANCE') {
				const tradeFinanceInfo = await TradeFinanceWheat.findOne({
					where: {
						PROCUREMENTID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if (
					(tradeFinanceInfo as any)?.SUBMITTED ||
					(tradeFinanceInfo as any)?.LOCKED
				) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((tradeFinanceInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await TradeFinanceWheat.update(
							{ ...x, SUBMITTED: data?.FLAG === 'COMPLETED' },
							{
								where: {
									PROCUREMENTID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await TradeFinanceWheat.create(
							{
								...x,
								PROCUREMENTID: data?.ID,
								SUBMITTED: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					const attachments = [];
					const attachmentsData = [];

					if (data?.LCATTACHMENTFLAG) {
						attachments.push('LCATTACHMENT');
						data?.LCATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'LCATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.INSURANCEATTACHMENTFLAG) {
						attachments.push('INSURANCEATTACHMENT');
						data?.FORMMATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'INSURANCEATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.FORMMATTACHMENTFLAG) {
						attachments.push('FORMMATTACHMENT');
						data?.FORMMATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'FORMMATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.PAARATTACHMENTFLAG) {
						attachments.push('PAARATTACHMENT');
						data?.FORMMATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'PAARATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (attachmentsData?.length) {
						await AttachmentsWheat.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await AttachmentsWheat.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}
			} else if (SECTIONNAME === 'CLEARANCE') {
				const clearanceInfo = await ClearanceWheat.findOne({
					where: {
						PROCUREMENTID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if (
					(clearanceInfo as any)?.SUBMITTED ||
					(clearanceInfo as any)?.LOCKED
				) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((clearanceInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await ClearanceWheat.update(
							{ ...x, SUBMITTED: data?.FLAG === 'COMPLETED' },
							{
								where: {
									PROCUREMENTID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await ClearanceWheat.create(
							{
								...x,
								SUBMITTED: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					const attachments = [];
					const attachmentsData = [];

					if (data?.DUTYASSESMENTATTACHMENTFLAG) {
						attachments.push('DUTYASSESMENTATTACHMENT');
						data?.DUTYASSESMENTATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'DUTYASSESMENTATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.NPANIMASAABUJAAPPROVALATTACHMENTSFLAG) {
						attachments.push('NPANIMASAABUJAAPPROVALATTACHMENTS');
						data?.DUTYASSESMENTATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'NPANIMASAABUJAAPPROVALATTACHMENTS',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.ECDATTACHMENTFLAG) {
						attachments.push('ECDATTACHMENT');
						data?.ECDINVOICEATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'ECDATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (attachmentsData?.length) {
						await AttachmentsWheat.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await AttachmentsWheat.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}
			}
			const x = await PolcsectionstatusWheat.update(
				{
					STATUS: data.FLAG,
				},
				{
					where: {
						PROCUREMENTID: data?.ID,
						SECTIONAME: SECTIONNAME,
					},
					transaction,
				},
			);

			await ActivityLogs.create(
				{
					USERID,
					SECTIONNAME,
					DATA: data,
				},
				{ transaction },
			);

			await transaction.commit();
			res.locals.data = {
				message: 'Data updated successfully.',
				ID: data?.ID,
			};
			super.send(res);
			console.log('postPurchaseOrder Wheat API completed');
		} catch (err) {
			await transaction.rollback();
			logger.error(
				`Error in postPurchaseOrder Wheat : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	public async getcommercialWheatReports(
		req: Request, res: Response, next: NextFunction
	) {
		try {
			const wheatreportData = await ProcurementWheat.findAll({
				attributes: ['SUPPLIER', 'ORIGIN', 'PROTEINLEVEL', 'PROTEINPERCENT', 'FOBMT', 'FREIGHTMT', 'CNFMT', 'ORDEREDQTYPHCMT', 'ORDEREDQTYAPAPAMT', 'TOTALORDEREDQTYMT', 'TOTALVALUE', 'SHIPMENTWINDOWSTART', 'SHIPMENTWINDOWEND', 'AGREEMENTDATE', 'VESSELNUMBER', 'PORTOFLOADING'],
				raw: true
			});

			const wheatrawReport = await ClearanceWheat.findAll({
				attributes: ['ACTUALTIMEOFSAILING', 'ACTUALTIMEOFARRIVALAPAPA', 'ACTUALTIMEOFARRIVALPHC', 'RECEIVEDQUANTITYAPAPAMT', 'RECEIVEDQTYPHCMT', 'TOTALRECEIVEDQTYMT', 'TOTALVALUE', 'DEMURRAGEDAY', 'DEMURRAGEDESPATCHAPAPA', 'DEMURRAGEDESPATCHPHC', 'GAFTAAPPADOLLAR', 'GAFTAPHCDOLLAR', 'ECDRECEIVEDDATE', 'ECDSUBMISSIONDATE', 'ECDACKNOWLEDGEMENT'],
				raw: true
			});


			const finalReport = wheatreportData.map((data, index) => ({
				...data,
				...wheatrawReport[index]
			}));

			const formFields = await Reports.findAll({
				where: {
					REPORTID: 6,
					ACTIVE: true
				},
				raw: true
			});
			const headerData = formFields.reduce((acc, curr) => {
				acc[(curr as any).FIELDNAME] = {
					SEQUENCE: (curr as any).FIELDSEQUENCE,
					DESC: (curr as any).FIELDDESCRIPTION,
				};
				return acc;

			}, {});
			res.locals.data = {
				data: {
					HEADER: headerData,
					DETAIL: finalReport,
				}
			};
			super.send(res);
		} catch (error) {
			logger.error(
				`Error in getting commercial wheat : ${error.message}\n${error.stack}`,
			);
			throw new ApiError(error.message, StatusCodes.BAD_REQUEST, res);
		}
	}
	

/**
	 * @param req
	 * @param res
	 * @param next
	 */
public async getoperationsWheatReports(
	req: Request, res: Response, next: NextFunction
) {
	try {
		const { ID } = req.query;
		const wheatreportData = await ProcurementWheat.findAll({
			attributes: [
				'ID',
				'SUPPLIER',
				'ORIGIN',
				'FOBMT',
				'FREIGHTMT',
				'CNFMT',
				'TOTALORDEREDQTYMT',
				'TOTALVALUE',
				'SHIPMENTWINDOWSTART',
				'VESSELNUMBER',
				'VESSELNAME',
				'BLDATE',
				'BLNO',
				'ARRIVALMONTH',
				'PONO',
				'SHIPMENTWINDOWEND',
			],
			raw: true
		});

		const wheatrawReport = await ClearanceWheat.findAll({
			attributes: [
				'ASSESMENTDATE',
				'ASSESMENTNUMBER',
				'DUTYNAIRA',
				'ABUJAAPPROVALCHANGES',
				'NOR',
				'SHIPMENTCOMPLETION',
				'PORT',
				'AGENT',
				'DEMURRAGEDAY',
				'DEMURRAGEDESPATCH',
				'GAFTAREFUNDSDOLLAR',
				'NAQSNAIRA',
				'MANIFESTNAIRA',
				'NPADOLLAR',
				'NPANAIRADOLLAR',
				'NIMASAIMPORTLEVY',
				'NIMASASEAPROTECTIONLEVY',
				'TERMINALCHARGES',
				'TERMINALCHARGESNAIRA',
				'AGENCYFEE',
				'NAFDACCHARGES',
				'DISCHARGEHOLDANDSEAL',
				'PRIORITYBERTHINGDOLLAR',
				'FINALADJUSTMENTDOLLAR',
				'FINALADJUSTMENTNAIRADOLLAR',
				'NETADJUSTMENTAEAF',
				'MARITIMEUNIONCHARGES',
				'OTHEREXPENSESDOLLAREURO',
				'OTHEREXPENSESNAIRA',
				'SURVEYORCHARGESNAIRA',
				'CONTINGENTDEPOSITDOLLARNPAANDPTOL',
				
			],
			raw: true
		});

		const tradefinanceReport = await TradeFinanceWheat.findAll({
			attributes: ['FORMMNO', 'LCNUMBER', 'LCINVOICEAMOUNT', ]
		});

		const finalReport = wheatreportData.map((data, index) => ({
			...data,
			...wheatrawReport[index],
			...tradefinanceReport[index]
		}));

		const formFields = await Reports.findAll({
			where: {
				REPORTID: 7,
				ACTIVE: true
			},
			raw: true
		});
		const headerData = formFields.reduce((acc, curr) => {
			acc[(curr as any).FIELDNAME] = {
				SEQUENCE: (curr as any).FIELDSEQUENCE,
				DESC: (curr as any).FIELDDESCRIPTION,
			};
			return acc;

		}, {});
		res.locals.data = {
			data: {
				HEADER: headerData,
				DETAIL: finalReport,
			}
		};
		super.send(res);
	} catch (error) {
		logger.error(
			`Error in getting operation oil : ${error.message}\n${error.stack}`,
		);
		throw new ApiError(error.message, StatusCodes.BAD_REQUEST, res);
	}
}


}
