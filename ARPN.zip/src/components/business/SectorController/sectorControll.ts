import { NextFunction, Request, Response, Router } from 'express';

import BaseApi from '../../BaseApi';

import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import ApiError from '../../../abstractions/ApiError';
import logger from '../../../lib/logger';
import Sectors from '../../../database/models/business/Sector/Sector';
import Geolocation from '../../../database/models/business/Geolocation/Geolocation';

/**
 * User Management controller
 */
export default class SectorController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/getAllSectors', this.getAllSectors.bind(this));
		this.router.post('/defaultSector', this.insertSectors.bind(this));
		this.router.post('/createSector', this.createSector.bind(this));
		this.router.put('/updateSector/:id', this.updateSector.bind(this));
		this.router.delete('/deleteSector/:id', this.deleteSector.bind(this));

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createSector(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('createSector api has been invoked');
			const { data } = req.body;
			const user = await Sectors.create(data);
			res.locals.data = JSON.parse(JSON.stringify(user));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in createSector : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async updateSector(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('updateSector api has been invoked');
			const { id } = req.params;
			const { data } = req.body;
			const user = await Sectors.update(data, { where: { id } });
			res.locals.data = JSON.parse(JSON.stringify(user));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in updateSector : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	public async deleteSector(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('deleteSector api has been invoked');
			const { id } = req.params;
			console.log('id', id);
			const { data } = req.body;
			const user = await Sectors.destroy({ where: { ID: id } });
			res.locals.data = { user };
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in deleteSector : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	public async getAllSectors(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('getAllUsers api has been invoked');
			const users = await Sectors.findAll({
				include: {
					model: Geolocation,
					attributes: ['LATITUDE', 'LONGITUDE'],
					as: 'sectorGeolocations',
				},
			});

			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	async insertSectors(req: Request, res: Response) {
		try {
			await Sectors.bulkCreate([
				{ ID: 1, SECTOR_NAME: 'Grain and Cereal Farming' },
				{ ID: 2, SECTOR_NAME: 'Fruit and Nut Farming' },
				{ ID: 3, SECTOR_NAME: 'Vegetable and Melon Farming' },
				{
					ID: 4,
					SECTOR_NAME:
						'Greenhouse, Nursery, and Floriculture Production',
				},
				{ ID: 5, SECTOR_NAME: 'Cotton and Fiber Crops' },
			]);
			res.status(200).json({
				message: ' sectors inserted successfully',
			});
		} catch (error) {
			console.error('Error inserting sectors:', error);
			res.status(500).json({
				message: 'Failed to insert sectors',
				error,
			});
		}
	}
}
