import fs from 'fs';
import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Op, Sequelize, Transaction } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import Procurement from '../../../database/models/business/procurement/procurement';
import Polcsectionstatus from '../../../database/models/business/purchaseOrder/poLcSectionStatus';
import comboMaster from '../../../database/models/masters/comboMaster';
import LC from '../../../database/models/business/ttlc/lc';
import Shipment from '../../../database/models/business/shipment/shipment';
import BaseApi from '../../BaseApi';
import logger from '../../../lib/logger';
// import sequelize from 'sequelize/types/sequelize';

/**
 * Status controller
 */
export default class OrderTrackerKPIController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/getEntriesCount', this.getEntriesCount.bind(this));
		this.router.get(
			'/getKPIOrderTracker',
			this.getKPIOrderTracker.bind(this),
		);
		return this.router;
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getKPIOrderTracker(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getKPIBasedScreens initalized');
			const { OUID = 1, APITYPE } = req.query;

			let where = {};
			if (APITYPE === 'PFIPOCOUNT') {
				where = {
					PONO: {
						[Op.or]: [{ [Op.in]: [''] }, { [Op.is]: null }],
					},
					PFINO: {
						[Op.or]: [{ [Op.notIn]: [''] }, { [Op.not]: null }],
					},
				};
			} else if (APITYPE === 'POPFICOUNT') {
				where = {
					PFINO: {
						[Op.or]: [{ [Op.in]: [''] }, { [Op.is]: null }],
					},
					PONO: {
						[Op.or]: [{ [Op.notIn]: [''] }, { [Op.not]: null }],
					},
				};
			} else if (APITYPE === 'LCCOUNT') {
				const lcDateCount = await LC.findAll({
					attributes: [
						[
							Sequelize.fn(
								'DISTINCT',
								Sequelize.col('PROCUREMENTID'),
							),

							'LCCOUNT',
						],
					],
					where: {
						LCDATE: {
							[Op.lt]: Sequelize.literal(
								"NOW() - INTERVAL '10 days'",
							),
						},
					},
					raw: true,
				});

				where = {
					ID: {
						[Op.in]: lcDateCount.map(
							(element) => (element as any).LCCOUNT,
						),
					},
				};
			} else if (APITYPE === 'SHIPMENTCOUNT') {
				const shipmentDateCount = await Shipment.findAll({
					attributes: [
						[
							Sequelize.fn(
								'DISTINCT',
								Sequelize.col('PROCUREMENTID'),
							),

							'SHIPMENTCOUNT',
						],
					],
					where: {
						ACTUALSHIPMENTDATE: {
							[Op.lt]: Sequelize.literal(
								"NOW() - INTERVAL '10 days'",
							),
						},
					},
					raw: true,
				});
				where = {
					ID: {
						[Op.in]: shipmentDateCount.map(
							(element) => (element as any).SHIPMENTCOUNT,
						),
					},
				};
			} else if (APITYPE === 'SCANDOCSRECEIVEDCOUNT') {
				const scanDocsCount = await Shipment.findAll({
					attributes: [
						[
							Sequelize.fn(
								'DISTINCT',
								Sequelize.col('PROCUREMENTID'),
							),
							'SCANDOCSRECEIVEDCOUNT',
						],
					],
					where: {
						SCANDOCSRECEIVED: {
							[Op.or]: [{ [Op.in]: [false] }, { [Op.is]: null }],
						},
					},
					raw: true,
				});
				where = {
					ID: {
						[Op.in]: scanDocsCount.map(
							(element) => (element as any).SCANDOCSRECEIVEDCOUNT,
						),
					},
				};
			} else if (APITYPE === 'PHYSICALDOCSRECEIVEDCOUNT') {
				const physicalDocsCount = await Shipment.findAll({
					attributes: [
						[
							Sequelize.fn(
								'DISTINCT',
								Sequelize.col('PROCUREMENTID'),
							),
							'PHYSICALDOCSCOUNT',
						],
					],
					where: {
						ORIGINALDOCSRECEIVED: {
							[Op.or]: [{ [Op.in]: true }, { [Op.is]: null }],
						},
					},
					raw: true,
				});
				where = {
					ID: {
						[Op.in]: physicalDocsCount.map(
							(element) => (element as any).PHYSICALDOCSCOUNT,
						),
					},
				};
			} else {
				where = {};
			}

			// const PoData = await LCMain.findAll({
			// 	raw: true,
			// });

			const factoriesList = await comboMaster.findAll({
				where: {
					FIELDID: 15,
				},
				raw: true,
			});

			const consolidatedFactories = factoriesList.reduce((acc, curr) => {
				acc[(curr as any).VALUE] = (curr as any).LABEL;
				return acc;
			}, {});

			const procurement = await Procurement.findAll({
				where,
				raw: true,
				order: [['createdAt', 'desc']],
			});

			console.log('procurement', procurement);

			const statusData = await Polcsectionstatus.findAll({
				attributes: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				// where: {
				// 	PROCUREMENTID: ID,
				// },
				raw: true,
				group: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				order: [['SECTIONSEQUENCE', 'asc']],
			});

			const consolidatedData = statusData.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...acc[(curr as any).PROCUREMENTID],
					[(curr as any).SECTIONAME]: {
						STATUS: (curr as any).STATUS,
						SECTIONSEQUENCE: (curr as any).SECTIONSEQUENCE,
						SECTIONAME: (curr as any).SECTIONAME,
					},
					FORMID: (curr as any).FORMID,
				};
				return acc;
			}, {});

			res.locals.data = {
				data: procurement.map((e) => {
					const d = Object.values(
						consolidatedData[(e as any).ID] || {},
					).reduce((acc, curr) => {
						acc[(curr as any).SECTIONSEQUENCE - 1] = {
							NAME: (curr as any).SECTIONAME,
							STATUS: (curr as any).STATUS,
						};
						return acc;
					}, []);

					const formId = consolidatedData[(e as any).ID]?.FORMID || 1;
					// delete d.FORMID;
					e['STAGES'] = d;
					e['FORMID'] = formId;

					e['FACTORYNAME'] =
						consolidatedFactories[(e as any).FACTORY];
					return e;
				}),
			};
			super.send(res);
			console.log('postPurchaseOrder API completed');
		} catch (err) {
			logger.error(
				`Error in getKPIBasedScreens : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getEntriesCount(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getFormMEntriesWheat initalized');

			const pfiPocount = await Procurement.findAll({
				attributes: [
					[Sequelize.fn('COUNT', Sequelize.col('*')), 'COUNT'],
					[
						Sequelize.literal(`
                      CASE
                        WHEN "PFIDATE" >= NOW() - INTERVAL '14 days' THEN 'LESSTHAN14DAYSAGO'
                        ELSE 'MORETHAN14DAYSAGO'
                      END
                    `),
						'DATERANGE',
					],
				],
				where: {
					PONO: {
						[Op.or]: [{ [Op.in]: [''] }, { [Op.is]: null }],
					},
					PFINO: {
						[Op.or]: [{ [Op.notIn]: [''] }, { [Op.not]: null }],
					},
				},
				raw: true,
				group: ['DATERANGE'],
				having: Sequelize.where(
					Sequelize.fn('COUNT', Sequelize.col('*')),
					'>',
					0,
				),
			});

			const poPfiCount = await Procurement.findAll({
				attributes: [
					[Sequelize.fn('COUNT', Sequelize.col('*')), 'COUNT'],
					[
						Sequelize.literal(`
                      CASE
                        WHEN "PODATE" >= NOW() - INTERVAL '14 days' THEN 'LESSTHAN14DAYSAGO'
                        ELSE 'MORETHAN14DAYSAGO'
                      END
                    `),
						'DATERANGE',
					],
				],
				where: {
					PFINO: {
						[Op.or]: [{ [Op.in]: [''] }, { [Op.is]: null }],
					},
					PONO: {
						[Op.or]: [{ [Op.notIn]: [''] }, { [Op.not]: null }],
					},
				},
				raw: true,
				group: ['DATERANGE'],
				having: Sequelize.where(
					Sequelize.fn('COUNT', Sequelize.col('*')),
					'>',
					0,
				),
			});

			const lcDateCount = await LC.findAll({
				attributes: [
					[
						Sequelize.fn(
							'COUNT',
							Sequelize.fn(
								'DISTINCT',
								Sequelize.col('PROCUREMENTID'),
							),
						),
						'LCCOUNT',
					],
				],
				where: {
					LCDATE: {
						[Op.lt]: Sequelize.literal(
							"NOW() - INTERVAL '10 days'",
						),
					},
				},
				raw: true,
			});

			const shipmentDateCount = await Shipment.findAll({
				attributes: [
					[
						Sequelize.fn(
							'COUNT',
							Sequelize.fn(
								'DISTINCT',
								Sequelize.col('PROCUREMENTID'),
							),
						),
						'SHIPMENTCOUNT',
					],
				],
				where: {
					ACTUALSHIPMENTDATE: {
						[Op.lt]: Sequelize.literal(
							"NOW() - INTERVAL '10 days'",
						),
					},
				},
				raw: true,
			});

			const scanDocsCount = await Shipment.findAll({
				attributes: [
					[
						Sequelize.fn(
							'COUNT',
							Sequelize.fn(
								'DISTINCT',
								Sequelize.col('PROCUREMENTID'),
							),
						),
						'SCANDOCSRECEIVEDCOUNT',
					],
				],
				where: {
					SCANDOCSRECEIVED: {
						[Op.or]: [{ [Op.in]: [false] }, { [Op.is]: null }],
					},
				},
				raw: true,
			});

			const physicalDocsCount = await Shipment.findAll({
				attributes: [
					[
						Sequelize.fn(
							'COUNT',
							Sequelize.fn(
								'DISTINCT',
								Sequelize.col('PROCUREMENTID'),
							),
						),
						'PHYSICALDOCSCOUNT',
					],
				],
				where: {
					ORIGINALDOCSRECEIVED: {
						[Op.or]: [{ [Op.in]: true }, { [Op.is]: null }],
					},
				},
				raw: true,
			});

			const factoryCount = await Procurement.findAll({
				attributes: [
					'FACTORY', // Group by FACTORY column
					[Sequelize.fn('COUNT', Sequelize.col('PONO')), 'COUNT'], // Count distinct PONO values
				],
				group: ['FACTORY'], // Group by FACTORY column
				raw: true,
			});

			const factoryValue = await Procurement.findAll({
				attributes: [
					'FACTORY', // Group by FACTORY column
					[Sequelize.fn('SUM', Sequelize.col('PFIAMOUNT')), 'SUM'], // Count distinct PONO values
				],
				group: ['FACTORY'], // Group by FACTORY column
				raw: true,
			});

			const factoriesList = await comboMaster.findAll({
				where: {
					FIELDID: 15,
				},
				raw: true,
			});

			const consolidatedFactories = factoriesList.reduce((acc, curr) => {
				acc[(curr as any).VALUE] = (curr as any).LABEL;
				return acc;
			}, {});

			res.locals.data = {
				data: {
					PFIPOCOUNT: pfiPocount.reduce(
						(acc: any, curr: any) => {
							acc[(curr as any).DATERANGE] = parseInt(
								(curr as any).COUNT,
							);
							acc.TOTAL += parseInt((curr as any).COUNT);
							return acc;
						},
						{
							TOTAL: 0,
						},
					),
					POPFICOUNT: poPfiCount.reduce(
						(acc: any, curr: any) => {
							acc[(curr as any).DATERANGE] = parseInt(
								(curr as any).COUNT,
							);
							acc.TOTAL += parseInt((curr as any).COUNT);
							return acc;
						},
						{
							TOTAL: 0,
						},
					),
					LCCOUNT: lcDateCount[0]
						? parseInt((lcDateCount[0] as any)?.LCCOUNT)
						: 0,
					SHIPMENTCOUNT: shipmentDateCount[0]
						? parseInt((shipmentDateCount[0] as any)?.SHIPMENTCOUNT)
						: 0,
					SCANDOCSRECEIVEDCOUNT: scanDocsCount[0]
						? parseInt(
								(scanDocsCount[0] as any)
									?.SCANDOCSRECEIVEDCOUNT,
						  )
						: 0,
					PHYSICALDOCSRECEIVEDCOUNT: physicalDocsCount[0]
						? parseInt(
								(physicalDocsCount[0] as any)
									?.SCANDOCSRECEIVEDCOUNT,
						  )
						: 0,
					FACTORYCOUNT: factoryCount.map((e) => {
						e['FACTORYNAME'] =
							consolidatedFactories[(e as any).FACTORY];
						return e;
					}),
					FACTORYVALUE: factoryValue.map((e) => {
						e['name'] = consolidatedFactories[(e as any).FACTORY];
						e['value'] = parseFloat((e as any).SUM || 0);
						return e;
					}),
				},
			};
			super.send(res);
			console.log('postPurchaseOrder API completed');
		} catch (err) {
			logger.error(
				`Error in postPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}
}
