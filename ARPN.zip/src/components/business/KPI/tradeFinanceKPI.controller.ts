import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Op, Sequelize, Transaction } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import { currentDate, firstDayOfLastMonth, lastDayOfLastMonth, firstDayOfCurrentMonth, lastDayOfCurrentMonth, tenDaysAgo, tweleveDaysAgo, twentyDays, sevenDaysAgo } from '../../../abstractions/dateFinder';
import { dataLcClosure, dataLcOngoing, countLcClosure, countPaar, countLcOngoing, dataFormmRegisteredGrt12, countFormmRegisGrtThan12, countFormmSubmGrtThan10, dataFormmSubmittedGrtThan10, countOrgDocsGrtThan20, dataOrgDocsGrtThan20, dataLcOngoingGrtThan20, countLcOngoingGrt20, dataPaarPending } from '../../../abstractions/queryBuilder';
import Database from '../../../database';
import Procurement from '../../../database/models/business/procurement/procurement';
import Polcsectionstatus from '../../../database/models/business/purchaseOrder/poLcSectionStatus';
import Shipment from '../../../database/models/business/shipment/shipment';
import Tradefinance from '../../../database/models/business/tradeFinance/tradeFinance';
import LC from '../../../database/models/business/ttlc/lc';
import comboMaster from '../../../database/models/masters/comboMaster';
import logger from '../../../lib/logger';
import BaseApi from '../../BaseApi';

export default class TradeFinanceKPIDashboardController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get(
			'/getTradeFinancedashboard',
			this.getTradeFinancedashboard.bind(this),
		);
		this.router.get(
			'/getKPITradeFinance',
			this.getKPITradeFinance.bind(this),
		);
		return this.router;
	}

	public async getTradeFinancedashboard(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const sequelize = Database.getConnection();
			const countLastMonthPFI = await Procurement.count({
				where: {
					PFIDATE: {
						[Op.between]: [firstDayOfLastMonth, lastDayOfLastMonth],
					},
				},
			});
			const countCurrentMonthPFI = await Procurement.count({
				where: {
					PFIDATE: {
						[Op.between]: [
							firstDayOfCurrentMonth,
							lastDayOfCurrentMonth,
						],
					},
				},
			});
			const sonProdCount = await Tradefinance.count({
				where: {
					SONPRODCERTALREDAVAIL: false,
					SONPRODCERTAPPSENTTOCQA: false,
				},
			});
			const formmCount = await Tradefinance.count({
				where: {
					FORMMSUBMITTEDDATE: null,
				},
			});
			const formmGrt10: any = await countFormmSubmGrtThan10();

			const formmRegisteredCount = await Tradefinance.count({
				where: {
					FORMMREGISTEREDDATE: null,
				},
			});
			const formmRegistGrt12: any = await countFormmRegisGrtThan12();

			// const data = await Procurement.findAll({
			//     include: [{
			//         model: LC,
			//         as: 'PROCUREMENTINFO',
			//         where: {
			//             LCRECEIVEDBYSUPPLIER: { [Op.not]: null }
			//         }
			//     }],
			//     where: {
			//         PFIMODEOFPAYMENT: { [Op.not]: null }
			//     }
			// });
			// console.log('data: ', data);

			// const [pfiCount, supplierCount] = await Promise.all([
			//     Procurement.count({ where: { PFIMODEOFPAYMENT: 'LC' } }),
			//     LC.count({ where: { LCRECEIVEDBYSUPPLIER: null } })
			// ]);

			// const groupedCounts = {
			//     pfiCount,
			//     supplierCount,
			//     isReceivedBySupplierNull: supplierCount,
			//     isReceivedBySupplierNotNull: pfiCount - supplierCount
			// };

			// console.log('groupedCounts: ', groupedCounts);

			const lcongoingCount: any = await countLcOngoing();

			const rawLcOngoingGrt20: any = await countLcOngoingGrt20();

			const groupedCounts1 = await Tradefinance.count({
				where: {
					FORMMSUBMITTEDDATE: {
						[Op.gt]: sevenDaysAgo,
					},
				},
			});

			const miroPendingCount = await Shipment.count({
				where: {
					SHIPMENTPLANNINGANDEXECUTIONMIRONO: null,
				},
			});
			const ibdPendingCount = await Shipment.count({
				where: {
					IBDNUMBER: null,
				},
			});
			const paarRawCount: any = await countPaar();

			const originalDocsCount = await LC.count({
				where: {
					SCANNEDDOCSRECEIVED: false,
				},
			});

			const originalDocsGrt20 = await countOrgDocsGrtThan20();

			const lcClousreCount: any = await countLcClosure();

			const blDateCount = await Shipment.count({
				where: {
					BLDATE: null,
				},
			});
			const procurementCount = await Procurement.count({
				where: {
					FACTORY: 'NG10',
				},
			});

			const shipmentCount = await Shipment.count({
				where: {
					APPLIEDFORPAAR: false,
				},
			});

			const lcCount = await LC.count({
				where: {
					SCANNEDDOCSRECEIVED: true,
				},
			});
			res.locals.data = {
				data: {
					PFICOUNT: {
						LASTMONTHCOUNTPFITF: countLastMonthPFI,
						CURRENTMONTHCOUNTPFITF: countCurrentMonthPFI,
					},
					SONPRODUCT: {
						SONPRODUCTCOUNTSONTF: sonProdCount,
					},
					FORMMCOUNT: {
						FORMMCOUNTSFCTF: formmCount,
						FORMMGRTTHAN10FSTF: formmGrt10,
						FORMMREGISTEREDCOUNTTFSTF: formmRegisteredCount,
						FORMMREGISTEREDGRTTHAN12FRTF: formmRegistGrt12,
					},
					MIROCOUNT: {
						MIROPENDINDCOUNTMIROTF: miroPendingCount,
					},
					IBDCOUNT: {
						IBDPENDINGCOUNTIBDTF: ibdPendingCount,
					},
					LCCOUNT: {
						LCONGOINGCOUNTLCTF: lcongoingCount,
						LCONGOINGGRTTHAN20LCTF: rawLcOngoingGrt20,
					},
					PAAR: {
						PAARCOUNT: paarRawCount,
					},
					ORIGINALDOCS: {
						ORIGINALDOCSCOUNTODTF: originalDocsCount,
						ORIGINALDOCSCOUNTGRTTHAN20ODTF: originalDocsGrt20,
					},
					LCCLOUSRECOUNT: {
						LCCLOSURECOUNTLCTF: lcClousreCount,
					},
				},
			};
			super.send(res);
		} catch (err) {
			console.log('error: ', err);
			logger.error(
				`Error in getting trade finanace dashboard: ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	public async getKPITradeFinance(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const sequelize = Database.getConnection();
			const { OUID = 1, APITYPE } = req.query;
			const where = {};
			let data;
			if (APITYPE === 'LASTMONTHCOUNTPFITF') {
				data = await Procurement.findAll({
					where: {
						PFIDATE: {
							[Op.between]: [
								firstDayOfLastMonth,
								lastDayOfLastMonth,
							],
						},
					},
					raw: true,
				});
			} else if (APITYPE === 'CURRENTMONTHCOUNTPFITF') {
				data = await Procurement.findAll({
					where: {
						PFIDATE: {
							[Op.between]: [
								firstDayOfCurrentMonth,
								lastDayOfCurrentMonth,
							],
						},
						
					},
                    raw: true,
				});
			} else if (APITYPE === 'SONPRODUCTCOUNTSONTF') {
				const x = await Tradefinance.findAll({
					where: {
						SONPRODCERTALREDAVAIL: false,
						SONPRODCERTAPPSENTTOCQA: false,
					},
					raw: true,
				});
				const proc = await Procurement.findAll({
					where: {
						ID: {
							[Op.in]: x.map((e) => (e as any).PROCUREMENTID),
						},
					},
					raw: true,
				});
				const consolidatedData = proc.reduce((acc, curr) => {
					acc[(curr as any).ID] = curr;
					return acc;
				}, {});
				data = x.map((e) => {
					const newS = {
                        ...e,
                        ...consolidatedData[(e as any).PROCUREMENTID],
					};
					return newS;
				});
			} else if (APITYPE === 'MIROPENDINDCOUNTMIROTF') {
				const x = await Shipment.findAll({
					where: {
						SHIPMENTPLANNINGANDEXECUTIONMIRONO: null,
					},
				});
				const proc = await Procurement.findAll({
					where: {
						ID: {
							[Op.in]: x.map((e) => (e as any).PROCUREMENTID),
						},
					},
					raw: true,
				});
				const consolidatedData = proc.reduce((acc, curr) => {
					acc[(curr as any).ID] = curr;
					return acc;
				}, {});
				data = x.map((e) => {
					const newS = {
						...e,
                        ...consolidatedData[(e as any).PROCUREMENTID],
					};
					return newS;
				});
			} else if (APITYPE === 'IBDPENDINGCOUNTIBDTF') {
				const x = await Shipment.findAll({
					where: {
						IBDNUMBER: null,
					},
				});

				const proc = await Procurement.findAll({
					where: {
						ID: {
							[Op.in]: x.map((e) => (e as any).PROCUREMENTID),
						},
					},
					raw: true,
				});
				const consolidatedData = proc.reduce((acc, curr) => {
					acc[(curr as any).ID] = curr;
					return acc;
				}, {});
				data = x.map((e) => {
					const newS = {
                        ...e,
                        ...consolidatedData[(e as any).PROCUREMENTID],
					};
					return newS;
				});
			} else if (APITYPE === 'ORIGINALDOCSCOUNTODTF') {
				const x = await LC.findAll({
					where: {
						SCANNEDDOCSRECEIVED: false,
					},
				});

				const proc = await Procurement.findAll({
					where: {
						ID: {
							[Op.in]: x.map((e) => (e as any).PROCUREMENTID),
						},
					},
					raw: true,
				});
				const consolidatedData = proc.reduce((acc, curr) => {
					acc[(curr as any).ID] = curr;
					return acc;
				}, {});
				data = x.map((e) => {
					const newS = {
						...e,
                        ...consolidatedData[(e as any).PROCUREMENTID],
					};
					return newS;
				});
			} else if (APITYPE === 'ORIGINALDOCSCOUNTGRTTHAN20ODTF') {
				const x = await dataOrgDocsGrtThan20();
				const proc = await Procurement.findAll({
					where: {
						ID: {
							[Op.in]: x.map((e) => (e as any).PROCUREMENTID),
						},
					},
					raw: true,
				});
				const consolidatedData = proc.reduce((acc, curr) => {
					acc[(curr as any).ID] = curr;
					return acc;
				}, {});
				data = x.map((e) => {
					const newS = {
                        ...e,
                        ...consolidatedData[(e as any).PROCUREMENTID],
					};
					return newS;
				});
			} else if (APITYPE === 'FORMMCOUNTSFCTF') {
				const x = await Tradefinance.findAll({
					where: {
						FORMMSUBMITTEDDATE: null,
					},
				});

				const proc = await Procurement.findAll({
					where: {
						ID: {
							[Op.in]: x.map((e) => (e as any).PROCUREMENTID),
						},
					},
					raw: true,
				});
				const consolidatedData = proc.reduce((acc, curr) => {
					acc[(curr as any).ID] = curr;
					return acc;
				}, {});
				data = x.map((e) => {
					const newS = {	
						...e,
                        ...consolidatedData[(e as any).PROCUREMENTID],
					};
					return newS;
				});
			} else if (APITYPE === 'FORMMGRTTHAN10FSTF') {
				data = await dataFormmSubmittedGrtThan10();
				console.log('formmLess10: ', data[0]);
			} else if (APITYPE === 'FORMMREGISTEREDCOUNTTFSTF') {
				data = await Tradefinance.findAll({
					where: {
						FORMMREGISTEREDDATE: null,
					},
				});
			} else if (APITYPE === 'FORMMREGISTEREDGRTTHAN12FRTF') {
				data = await dataFormmRegisteredGrt12();
				console.log('formmRegistLess12: ', data);
			} else if (APITYPE === 'LCCLOSURECOUNTLCTF') {
				data = await dataLcClosure();
				console.log('LCCLOSUREdata: ', data);
			} else if (APITYPE === 'LCONGOINGCOUNTLCTF') {
				data = await dataLcOngoing();
			} else if (APITYPE === 'LCONGOINGGRTTHAN20LCTF') {
				data = await dataLcOngoingGrtThan20();
			} else if (APITYPE === 'PAARCOUNT') {
				data = await dataPaarPending();
			}

			const factoriesList = await comboMaster.findAll({
				where: {
					FIELDID: 15,
				},
				raw: true,
			});

			const consolidatedFactories = factoriesList.reduce((acc, curr) => {
				acc[(curr as any).VALUE] = (curr as any).LABEL;
				return acc;
			}, {});

			const statusData = await Polcsectionstatus.findAll({
				attributes: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				// where: {
				// 	PROCUREMENTID: ID,
				// },
				raw: true,
				group: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				order: [['SECTIONSEQUENCE', 'asc']],
			});

			const consolidatedData = statusData.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...acc[(curr as any).PROCUREMENTID],
					[(curr as any).SECTIONAME]: {
						STATUS: (curr as any).STATUS,
						SECTIONSEQUENCE: (curr as any).SECTIONSEQUENCE,
						SECTIONAME: (curr as any).SECTIONAME,
					},
					FORMID: (curr as any).FORMID,
				};
				return acc;
			}, {});

			res.locals.data = {
				data: data.map((e) => {
					const d = Object.values(
						consolidatedData[(e as any).ID] || {},
					).reduce((acc, curr) => {
						acc[(curr as any).SECTIONSEQUENCE - 1] = {
							NAME: (curr as any).SECTIONAME,
							STATUS: (curr as any).STATUS,
						};
						return acc;
					}, []);

					const formId = consolidatedData[(e as any).ID]?.FORMID || 1;
					// delete d.FORMID;
					e.STAGES = d;
					e.FORMID = formId;

					e.FACTORYNAME =
						consolidatedFactories[(e as any).FACTORY];
					return e;
				}),
			};
			// res.locals.data = {
			//     data: data
			// }
			console.log('where: ', where);
			super.send(res);
		} catch (error) {
			logger.error(
				`Error in while retriveing data: ${error.message}\n${error.stack}`,
			);
			throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
		}
	}
}
