import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Op, Sequelize } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import BankAccount from '../../../database/models/business/bankMaster/bankAccount';
import BankMaster from '../../../database/models/business/bankMaster/bankMaster';
import LCComissionMaster from '../../../database/models/business/bankMaster/lcComissionMaster';
import PostNegMaster from '../../../database/models/business/bankMaster/postNegMaster';
import PreNegMaster from '../../../database/models/business/bankMaster/preNegMaster';
import logger from '../../../lib/logger';
import comboFormatter from '../../../utils/comboFormatter';
import dateFormatter from '../../../utils/dateFormatter';
import BaseApi from '../../BaseApi';

const moment = require('moment');
/**
 * BankMaster Controller
 */
export default class BankMasterController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 * Register API routes
	 */
	public register(): Router {
		this.router.get('/getBankMaster', this.getBankMaster.bind(this));

		this.router.get('/getBankList', this.getBankList.bind(this));
		this.router.post(
			'/createOrUpdateBankMaster',
			this.createOrUpdateBankMaster.bind(this),
		);

		return this.router;
	}

	/**
	 * Get BankMaster details
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getBankList(req: Request, res: Response, next: NextFunction) {
		try {
			console.log('getBankList initialized');
			const { OUID = 1, BANKNAMES } = req.query;

			const bankAccount = await BankAccount.findAll({
				where: {
					[Op.and]: [
						Sequelize.where(
							Sequelize.fn(
								'LOWER',
								Sequelize.fn(
									'REPLACE',
									Sequelize.fn(
										'REPLACE',
										Sequelize.col('GLACCOUNTDESCRIPTION'),
										' ',
										'',
									),
									'  ',
									'',
								),
							),
							{
								[Op.like]: `%${((BANKNAMES as string) || '')
									.split(' ')
									.join('')
									.toLowerCase()}%`,
							},
						),
					],
				},
				raw: true,
			});
			res.locals.data = comboFormatter(bankAccount, 'GLACCOUNTDESCRIPTION', 'ID');

			super.send(res);
			console.log('getBankList API completed');
		} catch (err) {
			logger.error(`Error in getBankList : ${err.message}\n${err.stack}`);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * Get BankMaster details
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getBankMaster(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getBankMaster initialized');
			const { OUID = 1 } = req.query;

			const bankmasterDetails = await BankMaster.findAll({
				where: { OUID },
				order: [['BANKNAME', 'ASC']],
				include: [
					{
						model: PreNegMaster,
						attributes: [
							'PRENEGPERCENTAGE',
							['STARTDATE', 'PRENEGSTARTDATE'],
							['ENDDATE', 'PRENEGENDDATE'],
						],
						required: false,
						order: [['STARTDATE', 'DESC']],
						limit: 1,
					},
					{
						model: PostNegMaster,
						attributes: [
							'POSTNEGPERCENTAGE',
							['STARTDATE', 'POSTNEGSTARTDATE'],
							['ENDDATE', 'POSTNEGENDDATE'],
						],
						required: false,
						order: [['STARTDATE', 'DESC']],
						limit: 1,
					},
					{
						model: LCComissionMaster,
						attributes: [
							'COMISSIONPERCENTAGE',
							['STARTDATE', 'COMISSIONSTARTDATE'],
							['ENDDATE', 'COMISSIONENDDATE'],
						],
						required: false,
						order: [['STARTDATE', 'DESC']],
						limit: 1,
					},
				],
			});

			res.locals.data = JSON.parse(
				JSON.stringify({ data: bankmasterDetails }),
			);

			super.send(res);
			console.log('getBankMaster API completed');
		} catch (err) {
			logger.error(
				`Error in getBankMaster : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * Create or update BankMaster entry based on FLAG
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createOrUpdateBankMaster(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { FLAG } = req.body;
			const { OUID = 1 } = req.query;

			if (!FLAG) {
				throw new Error('FLAG not provided');
			}

			const action =
				FLAG === 'CREATE'
					? this.createBankMaster
					: this.updateBankMaster;
			await action(req, res, next, OUID);
		} catch (err) {
			logger.error(
				`Error in createOrUpdateBankMaster : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	private async createBankMaster(
		req: Request,
		res: Response,
		next: NextFunction,
		OUID: any,
	) {
		const {
			BANKNAME,
			BANKIMAGE,
			ODFL,
			STFFL,
			IIFFL,
			TOTALFL,
			COMISSIONPERCENTAGE,
			COMISSIONSTARTDATE,
			COMISSIONENDDATE,
			PRENEGPERCENTAGE,
			PRENEGSTARTDATE,
			PRENEGENDDATE,
			POSTNEGPERCENTAGE,
			POSTNEGSTARTDATE,
			POSTNEGENDDATE,
		} = req.body;
		console.log('createBankMaster initialized');
		const createdBankMaster = await BankMaster.create({
			BANKNAME,
			BANKIMAGE,
			ODFL: parseFloat(ODFL),
			STFFL: parseFloat(STFFL),
			IIFFL: parseFloat(IIFFL),
			TOTALFL: parseFloat(TOTALFL),
			ODFU: 0,
			STFFU: 0,
			IIFFU: 0,
			NONOVERDUELC: 0,
			LTL: 0,
			TOTALFU: 0,
			TOTAL: 0,
			AVAILABLELINE: 0,
			OUID: parseInt(OUID),
		});

		const [preNegMaster, postNegMaster, lcComissionMaster] =
			await Promise.all([
				PreNegMaster.create({
					PRENEGPERCENTAGE,
					STARTDATE: dateFormatter(
						PRENEGSTARTDATE,
						'YYYY-MM-DD HH:mm:ss',
					),
					ENDDATE: dateFormatter(
						PRENEGENDDATE,
						'YYYY-MM-DD HH:mm:ss',
					),
					BANKID: createdBankMaster.dataValues.ID,
					OUID: parseInt(OUID),
				}),
				PostNegMaster.create({
					POSTNEGPERCENTAGE,
					STARTDATE: dateFormatter(
						POSTNEGSTARTDATE,
						'YYYY-MM-DD HH:mm:ss',
					),
					ENDDATE: dateFormatter(
						POSTNEGENDDATE,
						'YYYY-MM-DD HH:mm:ss',
					),
					BANKID: createdBankMaster.dataValues.ID,
					OUID: parseInt(OUID),
				}),
				LCComissionMaster.create({
					COMISSIONPERCENTAGE,
					STARTDATE: dateFormatter(
						COMISSIONSTARTDATE,
						'YYYY-MM-DD HH:mm:ss',
					),
					ENDDATE: dateFormatter(
						COMISSIONENDDATE,
						'YYYY-MM-DD HH:mm:ss',
					),
					BANKID: createdBankMaster.dataValues.ID,
					OUID: parseInt(OUID),
				}),
			]);

		res.locals.data = { message: 'Bank Master inserted successfully.' };
		super.send(res);
	}

	private async updateBankMaster(
		req: Request,
		res: Response,
		next: NextFunction,
		OUID: any | 1,
	) {
		console.log('updateBankMaster initialized');
		const {
			ID,
			BANKIMAGE,
			ODFL,
			STFFL,
			IIFFL,
			TOTALFL,
			COMISSIONPERCENTAGE,
			COMISSIONSTARTDATE,
			COMISSIONENDDATE,
			PRENEGPERCENTAGE,
			PRENEGSTARTDATE,
			PRENEGENDDATE,
			POSTNEGPERCENTAGE,
			POSTNEGSTARTDATE,
			POSTNEGENDDATE,
		} = req.body;

		const updatedBankMaster = await BankMaster.findByPk(ID);
		if (!updatedBankMaster) {
			throw new Error('BankMaster not found');
		}

		await updatedBankMaster.update({
			BANKIMAGE,
			ODFL,
			STFFL,
			IIFFL,
			TOTALFL,
		});

		const promises = [];
		if (PRENEGPERCENTAGE && PRENEGSTARTDATE && PRENEGENDDATE) {
			promises.push(
				PreNegMaster.create({
					PRENEGPERCENTAGE,
					STARTDATE: dateFormatter(
						PRENEGSTARTDATE,
						'YYYY-MM-DD HH:mm:ss',
					),
					ENDDATE: dateFormatter(
						PRENEGENDDATE,
						'YYYY-MM-DD HH:mm:ss',
					),
					BANKID: ID,
					OUID: parseInt(OUID),
				}),
			);
		}

		if (POSTNEGPERCENTAGE && POSTNEGSTARTDATE && POSTNEGENDDATE) {
			promises.push(
				PostNegMaster.create({
					POSTNEGPERCENTAGE,
					STARTDATE: dateFormatter(
						POSTNEGSTARTDATE,
						'YYYY-MM-DD HH:mm:ss',
					),
					ENDDATE: dateFormatter(
						POSTNEGENDDATE,
						'YYYY-MM-DD HH:mm:ss',
					),
					BANKID: ID,
					OUID: parseInt(OUID),
				}),
			);
		}
		if (COMISSIONPERCENTAGE && COMISSIONSTARTDATE && COMISSIONENDDATE) {
			promises.push(
				LCComissionMaster.create({
					COMISSIONPERCENTAGE,
					STARTDATE: dateFormatter(
						COMISSIONSTARTDATE,
						'YYYY-MM-DD HH:mm:ss',
					),
					ENDDATE: dateFormatter(
						COMISSIONENDDATE,
						'YYYY-MM-DD HH:mm:ss',
					),
					BANKID: ID,
					OUID: parseInt(OUID),
				}),
			);
		}

		await Promise.all(promises);
		res.locals.data = { message: 'BankMaster updated successfully' };
		super.send(res);
	}
}
