import { NextFunction, Request, Response, Router } from 'express';

import BaseApi from '../../BaseApi';
import Blocks from '../../../database/models/business/Blocks/Blocks';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import ApiError from '../../../abstractions/ApiError';
import logger from '../../../lib/logger';
import Geolocation from '../../../database/models/business/Geolocation/Geolocation';
import { Console, log } from 'console';
import Sectors from '../../../database/models/business/Sector/Sector';
import { json, Op } from 'sequelize';

/**
 * User Management controller
 */
export default class BlockController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/getAllLatLogs', this.getAllLatLogs.bind(this));
		this.router.post(
			'/defaultGeoLocation',
			this.insertGeoLocation.bind(this),
		);
		this.router.get('/getAll', this.getAllLatLogs.bind(this));

		this.router.post(
			'/createGeolocation',
			this.createGeolocation.bind(this),
		);
		this.router.put(
			'/updateGeolocation/:id',
			this.updateGeolocation.bind(this),
		);
		this.router.delete(
			'/deleteGeolocation/:id',
			this.deleteGeolocation.bind(this),
		);

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createGeolocation(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('createGeolocation api has been invoked');
			const { data } = req.body;
			const user = await Geolocation.create(data);
			res.locals.data = JSON.parse(JSON.stringify(user));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in createGeolocation : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async updateGeolocation(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('updateGeolocation api has been invoked');
			const { id } = req.params;
			const { data } = req.body;
			const user = await Geolocation.update(data, { where: { id } });
			res.locals.data = JSON.parse(JSON.stringify(user));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in updateGeolocation : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	public async deleteGeolocation(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('deleteGeolocation api has been invoked');
			const { id } = req.params;
			console.log('id', id);
			const { data } = req.body;
			const user = await Geolocation.destroy({ where: { ID: id } });
			res.locals.data = { user };
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in deleteGeolocation : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	public async getAllLatLogs(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const geoLocations = await Geolocation.findAll({
				attributes: [
					'ID',
					'BLOCK_ID',
					'SECTOR_ID',
					'LATITUDE',
					'LONGITUDE',
				],
				include: [
					{
						model: Blocks,
						attributes: ['BLOCK_NAME'],
						as: 'blockInfo',
					},
					{
						model: Sectors,
						attributes: ['SECTOR_NAME'],
						as: 'sectorInfo',
					},
				],
				raw: true,
			});
			console.log('nnnnn', geoLocations);
			// console.log(JSON.parse(JSON.stringify(geoLocations)));
			const result = geoLocations.map((element) => ({
				ID: (element as any).ID,
				BLOCK_NAME: (element as any)['blockInfo.BLOCK_NAME'],
				SECTOR_NAME: (element as any)['sectorInfo.SECTOR_NAME'],
				LATITUDE: (element as any).LATITUDE,
				LONGITUDE: (element as any).LONGITUDE,
			}));
			res.locals.data = result;
			super.send(res);
			// const ids = await Geolocation.findAll({
			// 	attributes: ['BLOCK_ID', 'SECTOR_ID'],
			// });

			// console.log(ids);
			// const blockArray = await ids.reduce((acc, curr) => {
			// 	acc.push((curr as any).SECTOR_ID);
			// 	return acc;
			// }, []);
			// const sectorArray = await ids.reduce((acc, curr) => {
			// 	acc.push((curr as any).BLOCK_ID);
			// 	return acc;
			// }, []);
			// console.log(blockArray, sectorArray);

			// const blockName = await Blocks.findAll({
			// 	where: {
			// 		ID: {
			// 			[Op.in]: blockArray,
			// 		},
			// 	},
			// 	attributes: ['ID', 'BLOCK_NAME'],
			// 	raw: true,
			// });
			// const SectorName = await Sectors.findAll({
			// 	where: {
			// 		ID: {
			// 			[Op.in]: sectorArray,
			// 		},
			// 	},
			// 	attributes: ['ID', 'SECTOR_NAME'],
			// 	raw: true,
			// });
			// console.log(blockName, SectorName);

			// res.locals.data = JSON.parse(JSON.stringify(result));
			// super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	async insertGeoLocation(req: Request, res: Response) {
		try {
			await Geolocation.bulkCreate([
				{
					ID: 1,
					BLOCK_ID: 1,
					LATITUDE: 40.7128,
					LONGITUDE: -74.006,
					SECTOR_ID: 1,
				},
				{
					ID: 2,
					BLOCK_ID: 1,
					LATITUDE: 40.713,
					LONGITUDE: -74.0055,
					SECTOR_ID: 1,
				},
				{
					ID: 3,
					BLOCK_ID: 1,
					LATITUDE: 40.7132,
					LONGITUDE: -74.005,
					SECTOR_ID: 1,
				},
				{
					ID: 4,
					BLOCK_ID: 2,
					LATITUDE: 34.0522,
					LONGITUDE: -118.2437,
					SECTOR_ID: 2,
				},
				{
					ID: 5,
					BLOCK_ID: 2,
					LATITUDE: 34.0524,
					LONGITUDE: -118.2432,
					SECTOR_ID: 2,
				},
				{
					ID: 6,
					BLOCK_ID: 2,
					LATITUDE: 34.0526,
					LONGITUDE: -118.2427,
					SECTOR_ID: 2,
				},
				{
					ID: 7,
					BLOCK_ID: 3,
					LATITUDE: 35.6895,
					LONGITUDE: 139.6917,
					SECTOR_ID: 3,
				},
				{
					ID: 8,
					BLOCK_ID: 3,
					LATITUDE: 35.6897,
					LONGITUDE: 139.6912,
					SECTOR_ID: 3,
				},
				{
					ID: 9,
					BLOCK_ID: 3,
					LATITUDE: 35.6899,
					LONGITUDE: 139.6907,
					SECTOR_ID: 3,
				},
				{
					ID: 10,
					BLOCK_ID: 4,
					LATITUDE: 48.8566,
					LONGITUDE: 2.3522,
					SECTOR_ID: 4,
				},
				{
					ID: 11,
					BLOCK_ID: 4,
					LATITUDE: 48.8568,
					LONGITUDE: 2.3527,
					SECTOR_ID: 4,
				},
				{
					ID: 12,
					BLOCK_ID: 4,
					LATITUDE: 48.857,
					LONGITUDE: 2.3532,
					SECTOR_ID: 4,
				},
				{
					ID: 13,
					BLOCK_ID: 5,
					LATITUDE: 51.5074,
					LONGITUDE: -0.1278,
					SECTOR_ID: 5,
				},
				{
					ID: 14,
					BLOCK_ID: 5,
					LATITUDE: 51.5076,
					LONGITUDE: -0.1273,
					SECTOR_ID: 5,
				},
				{
					ID: 15,
					BLOCK_ID: 5,
					LATITUDE: 51.5078,
					LONGITUDE: -0.1268,
					SECTOR_ID: 5,
				},
			]);
			res.status(200).json({
				message: 'Geolocations inserted successfully',
			});
		} catch (error) {
			console.error('Error inserting geolocations:', error);
			res.status(500).json({
				message: 'Failed to insert geolocations',
				error,
			});
		}
	}
}
