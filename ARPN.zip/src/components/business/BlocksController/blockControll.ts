import { NextFunction, Request, Response, Router } from 'express';

import BaseApi from '../../BaseApi';
import Blocks from '../../../database/models/business/Blocks/Blocks';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import ApiError from '../../../abstractions/ApiError';
import logger from '../../../lib/logger';
import Geolocation from '../../../database/models/business/Geolocation/Geolocation';

/**
 * User Management controller
 */
export default class BlockController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/getAllBlocks', this.getAllBlocks.bind(this));

		this.router.post('/createBlock', this.createBlock.bind(this));
		this.router.put('/updateBlock/:id', this.updateBlock.bind(this));
		this.router.delete('/deleteBlock/:id', this.deleteBlock.bind(this));
		this.router.post('/defaultBlocks', this.insertBlocks.bind(this));

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createBlock(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('createBlock api has been invoked');
			const { data } = req.body;
			const user = await Blocks.create(data);
			res.locals.data = JSON.parse(JSON.stringify(user));
			super.send(res);
		} catch (err) {
			logger.error(`Error in createBlock : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async updateBlock(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('updateBlock api has been invoked');
			const { id } = req.params;
			const { data } = req.body;
			const user = await Blocks.update(data, { where: { id } });
			res.locals.data = JSON.parse(JSON.stringify(user));
			super.send(res);
		} catch (err) {
			logger.error(`Error in updateBlock : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	public async deleteBlock(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('deleteBlock api has been invoked');
			const { id } = req.params;
			console.log('id', id);
			const { data } = req.body;
			const user = await Blocks.destroy({ where: { ID: id } });
			res.locals.data = { user };
			super.send(res);
		} catch (err) {
			logger.error(`Error in deleteBlock : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	public async getAllBlocks(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllUsers api has been invoked');
			const latLogs = await Blocks.findAll({
				include: {
					model: Geolocation,
					attributes: ['LATITUDE', 'LONGITUDE'],
					as: 'geolocations',
				},
				// raw: true,
			});
			res.locals.data = JSON.parse(JSON.stringify(latLogs));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	async insertBlocks(req: Request, res: Response) {
		try {
			await Blocks.bulkCreate([
				{ ID: 1, BLOCK_NAME: 'Wheatfield Block' },
				{ ID: 2, BLOCK_NAME: 'Maize Valley Block' },
				{ ID: 3, BLOCK_NAME: 'Rice Belt Block' },
				{ ID: 4, BLOCK_NAME: 'Sugarcane Plains Block' },
				{ ID: 5, BLOCK_NAME: 'Soybean District' },
			]);
			res.status(200).json({
				message: 'blocks data inserted successfully',
			});
		} catch (error) {
			console.error('Error inserting blocks:', error);
			res.status(500).json({
				message: 'Failed to insert blocks',
				error,
			});
		}
	}
}
