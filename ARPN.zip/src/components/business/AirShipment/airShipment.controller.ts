import { NextFunction, Request, Response, Router } from 'express';
import BaseApi from '../../BaseApi';
import { StatusCodes } from 'http-status-codes';
import { Op, Sequelize, Transaction } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import Reports from '../../../database/models/business/reports/reports';
import logger from '../../../lib/logger';
import ProcurementAir from '../../../database/models/business/procurementAir/procurementAir';
import ClearanceAir from '../../../database/models/business/clearanceAir/clearanceAir';
import comboMaster from '../../../database/models/masters/comboMaster';
import PolcsectionstatusAir from '../../../database/models/business/purchaseOrder/poLcSectionStatusAir';
import AttachmentsAir from '../../../database/models/business/attachmentsAir';
import Database from '../../../database';
import ActivityLogs from '../../../database/models/business/activityLogs';
import SectionsMaster from '../../../database/models/masters/sectionsMaster';
import FormFieldsMaster from '../../../database/models/masters/formFieldsMaster';
import FormConfigMapping from '../../../database/models/masters/formConfigMapping';
import Pfiitems from '../../../database/models/business/procurement/pfiItems';

export default class AirShipmentController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get(
			'/getAirShipmentReports',
			this.getAirShipmentReports.bind(this),
		);
		this.router.get(
			'/getFormMEntriesAirShipment',
			this.getFormMEntriesAirShipment.bind(this),
		);

		this.router.get(
			'/getPurchaseOrderAirShipment',
			this.getPurchaseOrderAirShipment.bind(this),
		);

		this.router.post('/postPFIEntryAir', this.postPFIEntryAir.bind(this));
		this.router.post('/postLCInfoAir', this.postLCInfoAir.bind(this));

		return this.router;
	}

	public async getAirShipmentReports(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { ID } = req.query;
			const procurementAirData = await ProcurementAir.findAll({
				attributes: [
					'ID',
					'PONO',
					'BOOKINGDATE',
					'SUPPLIERNAME',
					'SUBJECTOFMAIL',
					'ITEMNAME',
					'ITEMTYPE',
					'ORDERPLACEDBY',
					'PICKUPLOCATION',
					'DROPLOCATION',
					'OPERATIONS',
					'SHIPMENTTYPE',
					'TOTALVALUE',
				],

				raw: true,
			});

			const clearanceAirData = await ClearanceAir.findAll({
				attributes: [
					'AGENT',
					'ETA',
					'DELIVERYDATE',
					'GROSSWEIGHT',
					'NETWEIGHT',
					'DIMENSIONS',
					'AWBNO',
					'AGREEDRATE',
					'CONSIGNEENAMEONAWB',
					'SHIPMENTSTATUS',
					'INVOICEDATE',
					'INVOICENO',
					'CUSTOMSDUTY',
					'BALANCE',
					'TOTALAMOUNT',
					'REMARKS',
				],
				raw: true,
			});

			const finalReport = procurementAirData.map((data, index) => ({
				...data,
				...clearanceAirData[index],
			}));

			const formFields = await Reports.findAll({
				where: {
					REPORTID: 8,
					ACTIVE: true,
				},
				raw: true,
			});
			const headerData = formFields.reduce((acc, curr) => {
				acc[(curr as any).FIELDNAME] = {
					SEQUENCE: (curr as any).FIELDSEQUENCE,
					DESC: (curr as any).FIELDDESCRIPTION,
				};
				return acc;
			}, {});
			res.locals.data = {
				data: {
					HEADER: headerData,
					DETAIL: finalReport,
				},
			};
			super.send(res);
		} catch (error) {
			logger.error(
				`Error in fetching air shipment reports : ${error.message}\n${error.stack}`,
			);
			throw new ApiError(error.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getFormMEntriesAirShipment(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getFormMEntriesAirShipment initalized');

			const factoriesList = await comboMaster.findAll({
				where: {
					FIELDID: 15,
				},
				raw: true,
			});

			const consolidatedFactories = factoriesList.reduce((acc, curr) => {
				acc[(curr as any).VALUE] = (curr as any).LABEL;
				return acc;
			}, {});

			const procurement = await ProcurementAir.findAll({
				raw: true,
				order: [['createdAt', 'desc']],
			});

			const statusData = await PolcsectionstatusAir.findAll({
				attributes: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				raw: true,
				group: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				order: [['SECTIONSEQUENCE', 'asc']],
			});

			const consolidatedData = statusData.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...acc[(curr as any).PROCUREMENTID],
					[(curr as any).SECTIONAME]: {
						STATUS: (curr as any).STATUS,
						SECTIONSEQUENCE: (curr as any).SECTIONSEQUENCE,
						SECTIONAME: (curr as any).SECTIONAME,
					},
					FORMID: (curr as any).FORMID,
				};
				return acc;
			}, {});

			res.locals.data = {
				data: procurement.map((e) => {
					console.log(Object.values(consolidatedData[(e as any).ID]));
					const d = Object.values(
						consolidatedData[(e as any).ID],
					).reduce((acc, curr) => {
						acc[(curr as any).SECTIONSEQUENCE - 1] = {
							NAME: (curr as any).SECTIONAME,
							STATUS: (curr as any).STATUS,
						};
						return acc;
					}, []);

					const formId = consolidatedData[(e as any).ID]?.FORMID || 7;
					// delete d.FORMID;
					e['STAGES'] = d;
					e['FORMID'] = formId;
					e['FACTORYNAME'] =
						consolidatedFactories[(e as any).FACTORY];
					return e;
				}),
			};
			super.send(res);
			console.log('getformmentries API completed');
		} catch (err) {
			logger.error(
				`Error in getformmentries : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getPurchaseOrderAirShipment(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getPurchaseOrder initalized');
			const { OUID = 1, ID } = req.query;

			const procurement = await ProcurementAir.findOne({
				where: {
					ID,
				},
				raw: true,
			});

			// const factory = await comboMaster.findOne({
			// 	where: {
			// 		FIELDID: 15,
			// 		LABEL: (procurement as any)?.FACTORY,
			// 	},
			// 	raw: true,
			// });

			const clearance = await ClearanceAir.findOne({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const attachments = await AttachmentsAir.findAll({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const attachmentsConsolidated = attachments.reduce((acc, curr) => {
				if (acc[(curr as any).FIELDNAME]) {
					acc[(curr as any).FIELDNAME].push(curr);
				} else {
					acc[(curr as any).FIELDNAME] = [curr];
				}
				return acc;
			}, {});

			const statusData = await PolcsectionstatusAir.findAll({
				attributes: [
					'FORMID',
					'PROCUREMENTID',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
				],
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
				group: [
					'FORMID',
					'PROCUREMENTID',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
				],
				order: [['SECTIONSEQUENCE', 'asc']],
			});

			const consolidatedData = statusData.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...acc[(curr as any).PROCUREMENTID],
					[(curr as any).SECTIONAME]: {
						STATUS: (curr as any).STATUS,
						SECTIONSEQUENCE: (curr as any).SECTIONSEQUENCE,
						SECTIONAME: (curr as any).SECTIONAME,
					},
					FORMID: (curr as any).FORMID,
				};
				return acc;
			}, {});

			const d = Object.values(
				consolidatedData[(procurement as any).ID],
			).reduce((acc, curr) => {
				console.log('curr==>', curr);
				if (isNaN(curr as any)) {
					acc[(curr as any).SECTIONSEQUENCE - 1] = {
						NAME: (curr as any).SECTIONAME,
						STATUS: (curr as any).STATUS,
					};
				}

				return acc;
			}, []);

			const formId =
				consolidatedData[(procurement as any).SEQUENCE]?.FORMID || 7;

			// delete d.FORMID;

			const finalData = {
				...clearance,
				STAGES: d,
				FORMID: formId,
				// FACTORYNAME: (factory as any)?.LABEL || '',
				...procurement,
				...attachmentsConsolidated,
			};

			res.locals.data = {
				data: finalData,
			};
			super.send(res);
			console.log('getPurchaseOrder API completed');
		} catch (err) {
			logger.error(
				`Error in getPurchaseOrder  ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */

	public async postPFIEntryAir(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		const transaction = await Database.getConnection().transaction();
		try {
			console.log('postLCInfoAirData initalized');
			const { data } = req.body;
			const { OUID = 1, ROLEID = 1 } = req.query;

			const { itemDetails = [] } = data;

			const pfiInfo = await ProcurementAir.findAll({
				where: {
					PFINO: data?.PFINO,
				},
				raw: true,
				transaction,
			});

			if (pfiInfo.length) {
				logger.error(
					'Error in postPFIInfoAirData : PFI is already available',
				);
				throw new ApiError(
					'PFI already exists',
					StatusCodes.BAD_REQUEST,
					res,
				);
			} else {
				// await PurchaseOrder.create(data, { transaction });

				let lcInfo = await ProcurementAir.create(data, {
					transaction,
				});

				lcInfo = JSON.parse(JSON.stringify(lcInfo));

				if (itemDetails.length > 0) {
					const PFIItems = await Pfiitems.bulkCreate(
						itemDetails.map((e) => ({
							...e,
							OUID,
							PFINO: data.PFINO || '',
							PROCUREMENTID: (lcInfo as any)?.ID,
						})),
						{ transaction },
					);
				}

				const formType = await FormConfigMapping.findOne({
					where: {
						FACTORY: 'AIR',
						TYPEOFMATERIAL: 'AIR',
						ACTIVE: true,
					},
					raw: true,
					transaction,
				});

				if ((formType as any)?.ACTIVE) {
					const distinctSectionIds = await FormFieldsMaster.findAll({
						attributes: ['SECTIONID'],
						include: [
							{
								model: SectionsMaster,
								attributes: ['SECTIONNAME', 'SECTIONSEQUENCE'], // Selecting SECTION from SectionsMaster
								as: 'section',
								where: {
									ACTIVE: true,
								},
							},
						],
						where: {
							FORMID: (formType as any).FORMID,
							ROLEID,
						},
						raw: true,
						transaction,
						group: [
							'SECTIONID',
							'section.SECTIONNAME',
							'section.SECTIONSEQUENCE',
						],
					});

					await PolcsectionstatusAir.bulkCreate(
						distinctSectionIds.map((element) => ({
							OUID,
							PROCUREMENTID: (lcInfo as any)?.ID || 0,
							PROCUREMENTSEQUENCE: (lcInfo as any)?.ID || 0,
							FORMMNO: data?.FORMMNO || '',
							FORMID: (formType as any).FORMID,
							SECTIONAME: element['section.SECTIONNAME'],
							SECTIONSEQUENCE: element['section.SECTIONSEQUENCE'],
							STATUS: 'NEW',
						})),
						{
							transaction,
						},
					);

					console.log('postPFIInfoAirData API completed');
				} else {
					logger.error(
						'Error in postPFIInfoAirData : No Form Configuration found',
					);
					throw new ApiError(
						'No Form Configuration found',
						StatusCodes.BAD_REQUEST,
						res,
					);
				}

				await transaction.commit();
				res.locals.data = {
					message: 'PFI created successfully.',
					// data: distinctSectionIds,
				};

				super.send(res);
				console.log('postPFIInfoAirData API completed');
			}
		} catch (err) {
			transaction.rollback();
			logger.error(
				`Error in postLCInfoAirData : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	public async postLCInfoAir(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		const transaction = await Database.getConnection().transaction({
			isolationLevel: Transaction.ISOLATION_LEVELS.READ_COMMITTED,
		});
		try {
			console.log('postLCInfoAir initalized');
			const { data, FLAG } = req.body;
			const { OUID = 1, USERID } = req.query;
			const finalObj = { ...data, OUID };
			const { SECTIONNAME = '' } = data;

			if (!SECTIONNAME) {
				await transaction.rollback();
				throw new ApiError(
					'Invalid Section Name',
					StatusCodes.BAD_REQUEST,
					res,
				);
			}

			if (SECTIONNAME === 'PROCUREMENT') {
				const ProcurementInfo = await ProcurementAir.findOne({
					where: {
						ID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if (
					(ProcurementInfo as any)?.SUBMITTED ||
					(ProcurementInfo as any)?.LOCKED
				) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((ProcurementInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await ProcurementAir.update(
							{ ...x, SUBMITTED: data?.FLAG === 'COMPLETED' },
							{
								where: {
									ID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await ProcurementAir.create(
							{
								...x,
								SUBMITTED: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					if (data?.ITEMDETAILSFLAG) {
						await Pfiitems.destroy({
							where: {
								PROCUREMENTID: data?.ID,
							},
							transaction,
						});

						await Pfiitems.bulkCreate(
							data?.ITEMDETAILS?.map(
								(element) => {
									const d = { ...element };
									if (d.ID) {
										delete d.ID;
									}
									return {
										...d,
										PROCUREMENTID: data?.ID,
										OUID,
										PFINO: data?.PFINO,
										PONO: data?.PONO,
									};
								},
								{ transaction },
							),
						);
					}

					// if (data?.ITEMDETAILSFLAG) {
					// 	await Pfiitems.destroy({
					// 		where: {
					// 			PROCUREMENTID: data?.ID,
					// 		},
					// 	});

					// 	await Pfiitems.bulkCreate(
					// 		data?.ITEMDETAILS?.map((element) => ({
					// 			...element,
					// 			PROCUREMENTID: data?.ID,
					// 			OUID,
					// 			PFINO: data?.PFINO,
					// 			PONO: data?.PONO,
					// 		})),
					// 	);
					// }

					const attachments = [];
					const attachmentsData = [];
					if (data?.PFIATTACHMENTFLAG) {
						attachments.push('PFIATTACHMENT');
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'PFIATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}
					if (data?.POATTACHMENTFLAG) {
						attachments.push('POATTACHMENT');
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'POATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}
					if (data?.PRATTACHMENTFLAG) {
						attachments.push('PRATTACHMENT');
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'PRATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (attachmentsData?.length) {
						await AttachmentsAir.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await AttachmentsAir.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}
			} else if (SECTIONNAME === 'CLEARANCE') {
				const clearanceInfo = await ClearanceAir.findOne({
					where: {
						PROCUREMENTID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if (
					(clearanceInfo as any)?.SUBMITTED ||
					(clearanceInfo as any)?.LOCKED
				) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((clearanceInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await ClearanceAir.update(
							{ ...x, SUBMITTED: data?.FLAG === 'COMPLETED' },
							{
								where: {
									PROCUREMENTID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						console.log('CLEARANCE', x);
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await ClearanceAir.create(
							{
								...x,
								SUBMITTED: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					const attachments = [];
					const attachmentsData = [];

					if (data?.CLEARENCERELEASEFOUATTACHMENTFLAG) {
						attachments.push('CLEARENCERELEASEFOUATTACHMENT');
						data?.CLEARENCERELEASEFOUATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'CLEARENCERELEASEFOUATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.DUTYASSESMENTATTACHMENTFLAG) {
						attachments.push('DUTYASSESMENTATTACHMENT');
						data?.DUTYASSESMENTATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'DUTYASSESMENTATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.ECDINVOICEATTACHMENTFLAG) {
						attachments.push('ECDINVOICEATTACHMENT');
						data?.ECDINVOICEATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'ECDINVOICEATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (attachmentsData?.length) {
						await AttachmentsAir.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await AttachmentsAir.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}
			}
			const x = await PolcsectionstatusAir.update(
				{
					STATUS: data.FLAG,
				},
				{
					where: {
						PROCUREMENTID: data?.ID,
						SECTIONAME: SECTIONNAME,
					},
					transaction,
				},
			);

			await ActivityLogs.create(
				{
					USERID,
					SECTIONNAME,
					DATA: data,
				},
				{ transaction },
			);

			await transaction.commit();
			res.locals.data = {
				message: 'Data updated successfully.',
				ID: data?.ID,
			};
			super.send(res);
			console.log('postPurchaseOrder API completed');
		} catch (err) {
			await transaction.rollback();
			logger.error(
				`Error in postPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}
}
