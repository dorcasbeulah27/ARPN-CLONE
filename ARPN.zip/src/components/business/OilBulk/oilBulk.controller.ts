import fs from 'fs';
import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Op, Sequelize, Transaction } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import Database from '../../../database';
import ActivityLogs from '../../../database/models/business/activityLogs';
import AttachmentsOil from '../../../database/models/business/attachmentsOil';
import ClearanceOil from '../../../database/models/business/clearanceOil/clearanceOil';
import PfiitemsOil from '../../../database/models/business/procurementOil/pfiItems';
import ProcurementOil from '../../../database/models/business/procurementOil/procurement';
import PolcsectionstatusOil from '../../../database/models/business/purchaseOrder/poLcSectionStatusOil';
import Reports from '../../../database/models/business/reports/reports';
import TradeFinanceOil from '../../../database/models/business/tradeFinanceOil/tradeFinanceOil';
import comboMaster from '../../../database/models/masters/comboMaster';
import FormConfigMapping from '../../../database/models/masters/formConfigMapping';
import FormFieldsMaster from '../../../database/models/masters/formFieldsMaster';
import SectionsMaster from '../../../database/models/masters/sectionsMaster';
import TT from '../../../database/models/business/ttlc/tt';
import logger from '../../../lib/logger';
import BaseApi from '../../BaseApi';

/**
 * Status controller
 */
export default class OilBulksController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get(
			'/getFormMEntriesOil',
			this.getFormMEntriesOil.bind(this),
		);
		this.router.post('/postPFIOil', this.postPFIOil.bind(this));
		this.router.get(
			'/getPurchaseOrderOil',
			this.getPurchaseOrderOil.bind(this),
		);
		this.router.get('/getoilcommercialreports', this.getcommercialOilReports.bind(this));
		this.router.get('/getoperationsoilreports', this.getoperationsOilReports.bind(this));
		this.router.post('/postLCInfoOil', this.postLCInfoOil.bind(this));
		return this.router;
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getFormMEntriesOil(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getFormMEntriesOil initalized');

			const factoriesList = await comboMaster.findAll({
				where: {
					FIELDID: 15,
				},
				raw: true,
			});

			const consolidatedFactories = factoriesList.reduce((acc, curr) => {
				acc[(curr as any).VALUE] = (curr as any).LABEL;
				return acc;
			}, {});

			const procurement = await ProcurementOil.findAll({
				raw: true,
				order: [['createdAt', 'desc']],
			});

			const statusData = await PolcsectionstatusOil.findAll({
				attributes: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				raw: true,
				group: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				order: [['SECTIONSEQUENCE', 'asc']],
			});

			const consolidatedData = statusData.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...acc[(curr as any).PROCUREMENTID],
					[(curr as any).SECTIONAME]: {
						STATUS: (curr as any).STATUS,
						SECTIONSEQUENCE: (curr as any).SECTIONSEQUENCE,
						SECTIONAME: (curr as any).SECTIONAME,
					},
					FORMID: (curr as any).FORMID,
				};
				return acc;
			}, {});

			res.locals.data = {
				data: procurement.map((e) => {
					console.log(Object.values(consolidatedData[(e as any).ID]));
					const d = Object.values(
						consolidatedData[(e as any).ID],
					).reduce((acc, curr) => {
						acc[(curr as any).SECTIONSEQUENCE - 1] = {
							NAME: (curr as any).SECTIONAME,
							STATUS: (curr as any).STATUS,
						};
						return acc;
					}, []);

					const formId = consolidatedData[(e as any).ID]?.FORMID || 6;
					// delete d.FORMID;
					e["STAGES"] = d;
					e["FORMID"] = formId;
					e["FACTORYNAME"] =
						consolidatedFactories[(e as any).FACTORY];
					return e;
				}),
			};
			super.send(res);
			console.log('postPurchaseOrder API completed');
		} catch (err) {
			logger.error(
				`Error in postPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async postPFIOil(req: Request, res: Response, next: NextFunction) {
		const transaction = await Database.getConnection().transaction();
		try {
			console.log('postPFIData initalized');
			const { data } = req.body;
			const { OUID = 1, ROLEID = 1 } = req.query;

			const { itemDetails = [] } = data;

			const pfiInfo = await ProcurementOil.findAll({
				where: {
					PFINO: data?.PFINO,
				},
				raw: true,
				transaction,
			});

			if (pfiInfo.length) {
				// logger.error('Error in postPFIData : PFI is already available');
				// throw new ApiError(
				// 	'PFI already exists',
				// 	StatusCodes.BAD_REQUEST,
				// 	res,
				// );
			} else {
				let lcInfo = await ProcurementOil.create(data, {
					transaction,
				});

				lcInfo = JSON.parse(JSON.stringify(lcInfo));

				if (itemDetails.length > 0) {
					const PFIItems = await PfiitemsOil.bulkCreate(
						itemDetails.map((e) => ({
							...e,
							OUID,
							PFINO: data.PFINO || '',
							PROCUREMENTID: (lcInfo as any)?.ID,
						})),
						{ transaction },
					);
				}

				const formType = await FormConfigMapping.findOne({
					where: {
						FACTORY: 'OIL',
						ACTIVE: true,
					},
					raw: true,
					transaction,
				});

				if ((formType as any)?.ACTIVE) {
					const distinctSectionIds = await FormFieldsMaster.findAll({
						attributes: ['SECTIONID'],
						include: [
							{
								model: SectionsMaster,
								attributes: ['SECTIONNAME', 'SECTIONSEQUENCE'], // Selecting SECTION from SectionsMaster
								as: 'section',
								where: {
									ACTIVE: true,
								},
							},
						],
						where: {
							FORMID: (formType as any).FORMID,
							ROLEID,
							ACTIVE: true,
						},
						raw: true,
						transaction,
						group: [
							'SECTIONID',
							'section.SECTIONNAME',
							'section.SECTIONSEQUENCE',
						],
					});

					await PolcsectionstatusOil.bulkCreate(
						distinctSectionIds.map((element) => ({
							OUID,
							PROCUREMENTID: (lcInfo as any)?.ID || 0,
							PROCUREMENTSEQUENCE: (lcInfo as any)?.ID || 0,
							FORMMNO: data?.FORMMNO || '',
							FORMID: (formType as any).FORMID,
							SECTIONAME: element['section.SECTIONNAME'],
							SECTIONSEQUENCE: element['section.SECTIONSEQUENCE'],
							STATUS: 'NEW',
						})),
						{
							transaction,
						},
					);

					console.log('PFI entry API completed');
				} else {
					logger.error(
						'Error in PFI entry : No Form Configuration found',
					);
					throw new ApiError(
						'No Form Configuration found',
						StatusCodes.BAD_REQUEST,
						res,
					);
				}

				await transaction.commit();
				res.locals.data = {
					message: 'PFI created successfully.',
				};

				super.send(res);
				console.log('postPFI API completed');
			}
		} catch (err) {
			transaction.rollback();
			logger.error(`Error in postPFI : ${err.message}\n${err.stack}`);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getPurchaseOrderOil(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getPurchaseOrder Oil initalized');
			const { OUID = 1, ID } = req.query;

			const procurement = await ProcurementOil.findOne({
				where: {
					ID,
				},
				raw: true,
			});

			const factory = await comboMaster.findOne({
				where: {
					FIELDID: 15,
					LABEL: (procurement as any)?.FACTORY,
				},
				raw: true,
			});

			// const poItems = await PoItems.findAll({
			// 	where: {
			// 		ID,
			// 	},
			// 	raw: true,
			// });
			const pfiItems = await PfiitemsOil.findAll({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});
			const tradeFinance = await TradeFinanceOil.findOne({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const clearance = await ClearanceOil.findOne({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const attachments = await AttachmentsOil.findAll({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const attachmentsConsolidated = attachments.reduce((acc, curr) => {
				if (acc[(curr as any).FIELDNAME]) {
					acc[(curr as any).FIELDNAME].push(curr);
				} else {
					acc[(curr as any).FIELDNAME] = [curr];
				}
				return acc;
			}, {});

			const statusData = await PolcsectionstatusOil.findAll({
				attributes: [
					'FORMID',
					'PROCUREMENTID',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
				],
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
				group: [
					'FORMID',
					'PROCUREMENTID',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
				],
				order: [['SECTIONSEQUENCE', 'asc']],
			});

			const consolidatedData = statusData.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...acc[(curr as any).PROCUREMENTID],
					[(curr as any).SECTIONAME]: {
						STATUS: (curr as any).STATUS,
						SECTIONSEQUENCE: (curr as any).SECTIONSEQUENCE,
						SECTIONAME: (curr as any).SECTIONAME,
					},
					FORMID: (curr as any).FORMID,
				};
				return acc;
			}, {});

			const d = Object.values(
				consolidatedData[(procurement as any).ID],
			).reduce((acc, curr) => {
				console.log('curr==>', curr);
				if (isNaN(curr as any)) {
					acc[(curr as any).SECTIONSEQUENCE - 1] = {
						NAME: (curr as any).SECTIONAME,
						STATUS: (curr as any).STATUS,
					};
				}

				return acc;
			}, []);

			const formId =
				consolidatedData[(procurement as any).SEQUENCE]?.FORMID || 1;

			// delete d.FORMID;

			const finalData = {
				...clearance,
				...tradeFinance,
				STAGES: d,
				ITEMDETAILS: pfiItems,
				FORMID: formId,
				FACTORYNAME: (factory as any)?.LABEL || '',
				...procurement,
				...attachmentsConsolidated,
			};

			res.locals.data = {
				data: finalData,
			};
			super.send(res);
			console.log('getPurchaseOrder Oil  API completed');
		} catch (err) {
			logger.error(
				`Error in getPurchaseOrder Oil: ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async postLCInfoOil(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		const transaction = await Database.getConnection().transaction({
			isolationLevel: Transaction.ISOLATION_LEVELS.READ_COMMITTED,
		});
		try {
			console.log('postPurchaseOrder initalized');
			const { data, FLAG } = req.body;
			const { OUID = 1, USERID } = req.query;
			const finalObj = { ...data, OUID };
			const { SECTIONNAME = '' } = data;

			if (!SECTIONNAME) {
				await transaction.rollback();
				throw new ApiError(
					'Invalid Section Name',
					StatusCodes.BAD_REQUEST,
					res,
				);
			}

			if (SECTIONNAME === 'PROCUREMENT') {
				const ProcurementInfo = await ProcurementOil.findOne({
					where: {
						ID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if (
					(ProcurementInfo as any)?.SUBMITTED ||
					(ProcurementInfo as any)?.LOCKED
				) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((ProcurementInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await ProcurementOil.update(
							{ ...x, SUBMITTED: data?.FLAG === 'COMPLETED' },
							{
								where: {
									ID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await ProcurementOil.create(
							{
								...x,
								SUBMITTED: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					if (data?.ITEMDETAILSFLAG) {
						await PfiitemsOil.destroy({
							where: {
								PROCUREMENTID: data?.ID,
							},
							transaction,
						});

						await PfiitemsOil.bulkCreate(
							data?.ITEMDETAILS?.map(
								(element) => {
									const d = { ...element };
									if (d.ID) {
										delete d.ID;
									}
									return {
										...d,
										PROCUREMENTID: data?.ID,
										OUID,
										PFINO: data?.PFINO,
										PONO: data?.PONO,
									};
								},
								{ transaction },
							),
						);
					}

					const attachments = [];
					const attachmentsData = [];
					if (data?.PFIATTACHMENTFLAG) {
						attachments.push('PFIATTACHMENT');
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'PFIATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}
					if (data?.POATTACHMENTFLAG) {
						attachments.push('POATTACHMENT');
						data?.POATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'POATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.SHIPMENTPLANNINGANDEXECUTIONATTACHMENTFLAG) {
						attachments.push(
							'SHIPMENTPLANNINGANDEXECUTIONATTACHMENT',
						);
						data?.SHIPMENTPLANNINGANDEXECUTIONATTACHMENT.map(
							(e) => {
								attachmentsData.push({
									DOCNAME: e,
									FIELDNAME:
										'SHIPMENTPLANNINGANDEXECUTIONATTACHMENT',
									PROCUREMENTID: data?.ID,
								});
							},
						);
					}

					if (attachmentsData?.length) {
						await AttachmentsOil.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await AttachmentsOil.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}
			} else if (SECTIONNAME === 'TRADEFINANCE') {
				const tradeFinanceInfo = await TradeFinanceOil.findOne({
					where: {
						PROCUREMENTID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if (
					(tradeFinanceInfo as any)?.SUBMITTED ||
					(tradeFinanceInfo as any)?.LOCKED
				) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((tradeFinanceInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await TradeFinanceOil.update(
							{ ...x, SUBMITTED: data?.FLAG === 'COMPLETED' },
							{
								where: {
									PROCUREMENTID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await TradeFinanceOil.create(
							{
								...x,
								PROCUREMENTID: data?.ID,
								SUBMITTED: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					if (data?.TTFLAG) {
						await TT.destroy({
							where: {
								PROCUREMENTID: data?.ID,
							},
							transaction,
						});

						await TT.bulkCreate(
							data?.TT?.map((element) => {
								const d = { ...element };
								if (d.ID) {
									delete d.ID;
								}
								return {
									...d,
									PROCUREMENTID: data?.ID,
									SUBMITTED: data?.FLAG === 'COMPLETED',
									OUID,
								};
							}),
							{ transaction },
						);
					}

					const attachments = [];
					const attachmentsData = [];

					if (data?.TRANSIREATTACHMENTFLAG) {
						attachments.push('TRANSIREATTACHMENT');
						data?.TRANSIREATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'TRANSIREATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.DUTYASSESMENTATTACHMENTFLAG) {
						attachments.push('DUTYASSESMENTATTACHMENT');
						data?.DUTYASSESMENTATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'DUTYASSESMENTATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.NPAANDNIMASAATTACHMENTFLAG) {
						attachments.push('NPAANDNIMASAATTACHMENT');
						data?.NPAANDNIMASAATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'NPAANDNIMASAATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.ECDATTACHMENTFLAG) {
						attachments.push('ECDATTACHMENT');
						data?.ECDATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'ECDATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.NEPZAATTACHMENTSFLAG) {
						attachments.push('NEPZAATTACHMENTS');
						data?.NEPZAATTACHMENTS.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'NEPZAATTACHMENTS',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (attachmentsData?.length) {
						await AttachmentsOil.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await AttachmentsOil.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}
			} else if (SECTIONNAME === 'CLEARANCE') {
				const clearanceInfo = await ClearanceOil.findOne({
					where: {
						PROCUREMENTID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if (
					(clearanceInfo as any)?.SUBMITTED ||
					(clearanceInfo as any)?.LOCKED
				) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((clearanceInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await ClearanceOil.update(
							{ ...x, SUBMITTED: data?.FLAG === 'COMPLETED' },
							{
								where: {
									PROCUREMENTID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await ClearanceOil.create(
							{
								...x,
								SUBMITTED: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					const attachments = [];
					const attachmentsData = [];

					if (data?.INSURANCEATTACHMENTFLAG) {
						attachments.push('INSURANCEATTACHMENT');
						data?.INSURANCEATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'INSURANCEATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.TTATTACHMENTFLAG) {
						attachments.push('TTATTACHMENT');
						data?.TTATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'TTATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (attachmentsData?.length) {
						await AttachmentsOil.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await AttachmentsOil.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}
			}
			const x = await PolcsectionstatusOil.update(
				{
					STATUS: data.FLAG,
				},
				{
					where: {
						PROCUREMENTID: data?.ID,
						SECTIONAME: SECTIONNAME,
					},
					transaction,
				},
			);

			await ActivityLogs.create(
				{
					USERID,
					SECTIONNAME,
					DATA: data,
				},
				{ transaction },
			);

			await transaction.commit();
			res.locals.data = {
				message: 'Data updated successfully.',
				ID: data?.ID,
			};
			super.send(res);
			console.log('postPurchaseOrder Oil API completed');
		} catch (err) {
			await transaction.rollback();
			logger.error(
				`Error in postPurchaseOrder Oil : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}


	/**
	 * @param req
	 * @param res
	 * @param next
	 */


	public async getcommercialOilReports(
		req: Request, res: Response, next: NextFunction
	) {
		try {
			const { ID } = req.query;
			const oilreportData = await ProcurementOil.findAll({
				attributes: [
					'ID',
					'TOTALVALUE',
					'SUPPLIERNAME',
					'FOB',
					'FREIGHT',
					'CNF',
					'AGREEMENTDATE',
					'VESSELNO',
					'VESSELNAME',
					'ATS',
					'PORTOFLOADING',
					'QTY',
					'SHIPMENTWINDOWSTART',
					'SHIPMENTWINDOWEND'
				],

				raw: true
			});

			const oilrawReport = await ClearanceOil.findAll({
				attributes: [
					'DEMURRAGE',
					'DEMURRAGEINNCURED',
					'INTRESTCALCULATION',
					'ARMEDGAURDS',
					'FOFSA',
					'SHIPMENTCOMPLETIONDATEATA'
				],
				raw: true
			});			

			const finalReport = oilreportData.map((data, index) => ({
				...data,
				...oilrawReport[index]
			}));
	

			const formFields = await Reports.findAll({
				where: {
					REPORTID: 4,
					ACTIVE: true
				},
				raw: true
			});
			const headerData = formFields.reduce((acc, curr) => {
				acc[(curr as any).FIELDNAME] = {
					SEQUENCE: (curr as any).FIELDSEQUENCE,
					DESC: (curr as any).FIELDDESCRIPTION,
				};
				return acc;

			}, {});
			res.locals.data = {
				data: {
					HEADER: headerData,
					DETAIL: finalReport,
				}
			};
			super.send(res);
		} catch (error) {
			logger.error(
				`Error in getting commercial Oil : ${error.message}\n${error.stack}`,
			);
			throw new ApiError(error.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getoperationsOilReports(
		req: Request, res: Response, next: NextFunction
	) {
		try {
			const { ID } = req.query;
			const oilreportData = await ProcurementOil.findAll({
				attributes: [
					'ID',
					'SUPPLIERNAME',
					'COO',
					'FOB',
					'FREIGHT',
					'CNF',
					'QTY',
					'UOM',
					'VESSELNAME',
					'VESSELNO',
					'SHIPMENTMONTH',
					'NORDATE',
					'BLDATE',
					'BLNO',
					'SUPPLIERINVOICEVALUE',
					'INFINITYINVOICEVALUE',
					'PONO',
				],
				raw: true
			});

			const oilrawReport = await ClearanceOil.findAll({
				attributes: [
					'ASSESSMENTDATE',
					'ASSESSMENTNUMBER',
					'DUTYNAIRA',
					'PORT',
					'TERMINALOFDISCHARGE',
					'BERTHNO',
					'AGENT',
					'SHIPMENTCOMPLETIONDATEATA',
					'DEMURRAGE',
					'FOFSA',
					'INTRESTCALCULATION',
					'DEMURRAGEINNCURED',
					'SECUIRTYCHARGES',
					'NPA',
					'NPAINNAIRA',
					'NIMISAIMPORTLEVY',
					'NIMISASEAPROTECTIONONLEVY',
					'TERMINALCHARGES',
					'TERMINALCHARGESINNAIRA',
					'ADJUSTMENT',
					'ADJUSTMENTINNAIRA',
					'HARBOURANDPILOTHANDINGCHARGES',
					'FOREIGNNATIONALIMMIGRATIONINNAIRA',
					'HANDINGCHARGESINAIRA',
					'OTHERCHARGES',
					'SCLSURVEYORCHARGESINNAIRA',
					'DISCHARGEHOSERENTALCHARGESINNAIRA',
					'DISCHARGEPIPESRENTALCHARGESINNAIRA',
					'OTHERMISCINNAIRA',
					'OTHEREXPENCES',
					'OTHEREXPENCESINNAIRA',
					'CONTINGENTDEPOSIT',
					'DOCUMENTS',
					
				],
				raw: true
			});

			const finalReport = oilreportData.map((data, index) => ({
				...data,
				...oilrawReport[index]
			}));

			const formFields = await Reports.findAll({
				where: {
					REPORTID: 5,
					ACTIVE: true
				},
				raw: true
			});
			const headerData = formFields.reduce((acc, curr) => {
				acc[(curr as any).FIELDNAME] = {
					SEQUENCE: (curr as any).FIELDSEQUENCE,
					DESC: (curr as any).FIELDDESCRIPTION,
				};
				return acc;

			}, {});
			res.locals.data = {
				data: {
					HEADER: headerData,
					DETAIL: finalReport,
				}
			};
			super.send(res);
		} catch (error) {
			logger.error(
				`Error in getting operation oil : ${error.message}\n${error.stack}`,
			);
			throw new ApiError(error.message, StatusCodes.BAD_REQUEST, res);
		}
	}
}
