import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Op, Sequelize } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import PurchaseOrder from '../../../database/models/business/purchaseOrder/purchaseOrder';
import Environment from '../../../environments/environment';
import logger from '../../../lib/logger';
import BaseApi from '../../BaseApi';

/**
 * Status controller
 */
export default class SAPIntegrationController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.post(
			'/postPurchaseOrder',
			this.postPurchaseOrder.bind(this),
		);

		return this.router;
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async postPurchaseOrder(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('postPurchaseOrder initalized');
			const { data } = req.body;
			const authKey = req.headers['auth-key'];
			const db = new Environment();

			// await PurchaseOrder.bulkCreate(finalObj);
			if (authKey === db.authKey) {
				console.log('Purchase Order Details:', JSON.stringify(data));
				logger.info(`Purchase Order Details: ${JSON.stringify(data)}`);
				res.locals.data = {
					message: 'Purchase order uploaded successfully.',
				};
			} else {
				res.locals.data = {
					message: 'Invalid Key, please check your API Key.',
				};
			}

			super.send(res);
			console.log('postPurchaseOrder API completed');
		} catch (err) {
			logger.error(
				`Error in postPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async postBillOfLading(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('postBillOfLading initalized');
			const { data } = req.body;
			const { OUID = 1 } = req.query;
			const finalObj = data.map((item) => ({
				...item,
				OUID,
			}));

			// await PurchaseOrder.bulkCreate(finalObj);

			res.locals.data = {
				message: 'Bill Of lading uploaded successfully.',
			};
			super.send(res);
			console.log('postBillOfLading API completed');
		} catch (err) {
			logger.error(
				`Error in postBillOfLading : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}
}
