import fs from 'fs';
import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Sequelize } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import Clearance from '../../../database/models/business/clearance/clearance';
import Pfiitems from '../../../database/models/business/procurement/pfiItems';
import Procurement from '../../../database/models/business/procurement/procurement';
import Reports from '../../../database/models/business/reports/reports';
import Shipment from '../../../database/models/business/shipment/shipment';
import Tradefinance from '../../../database/models/business/tradeFinance/tradeFinance';
import LC from '../../../database/models/business/ttlc/lc';
import TT from '../../../database/models/business/ttlc/tt';
import logger from '../../../lib/logger';
import BaseApi from '../../BaseApi';

/**
 * Status controller
 */
export default class ScmReportsController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get(
			'/getOrderTrackerReport',
			this.getOrderTrackerReport.bind(this),
		);
		this.router.get(
			'/getTradeFinanceReport',
			this.getTradeFinanceReport.bind(this),
		);
		this.router.get(
			'/getClearanceReport',
			this.getClearanceReport.bind(this),
		);
		return this.router;
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getOrderTrackerReport(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { OUID = 1, USERID } = req.query;
			console.log('getOrderTrackerReport API Initiated');

			const pfiItems = await Pfiitems.findAll({
				where: {
					OUID,
				},
				include: [
					{
						model: Procurement,
						// attributes: ['SECTIONNAME', 'SECTIONSEQUENCE'], // Selecting SECTION from SectionsMaster
						as: 'PROCUREMENTINFO',
					},
				],
				order: [['ID', 'desc']],
			});

			const lc = await LC.findAll({
				attributes: ['BANK', 'LCNUMBER', 'LCDATE', 'PROCUREMENTID'],
				where: {},
			});

			let consolidatedLcData = [];

			if (lc && lc.length) {
				consolidatedLcData = JSON.parse(JSON.stringify(lc)).reduce(
					(acc, curr) => {
						acc[(curr as any)?.PROCUREMENTID] = curr;
						return acc;
					},
					{},
				);
			}

			const shipment = await Shipment.findAll({
				attributes: [
					'PROCUREMENTID',
					'TENATIVESHIPMENTDATE',
					'SCANDOCSRECEIVED',
					'BLDATE',
					'BLNO',
					'ORIGINALDOCSRECEIVED',
					'ACTUALSHIPMENTDATE',
					'EXPETAPORT',
				],
				where: {},
			});

			let consolidatedShipmentData = [];
			if (shipment && shipment.length) {
				consolidatedShipmentData = JSON.parse(
					JSON.stringify(shipment),
				).reduce((acc, curr) => {
					acc[(curr as any)?.PROCUREMENTID] = curr;
					return acc;
				}, {});
			}

			const tt = await TT.findAll({
				attributes: [
					'TTPAYMENTDATE',
					'TTPAYMENTAMOUNT',
					'PROCUREMENTID',
				],
				where: {},
				raw: true,
			});

			let consolidatedTT = {};

			if (tt && tt.length) {
				consolidatedTT = tt.reduce((acc, curr) => {
					if (acc[(curr as any)?.PROCUREMENTID]) {
						acc[(curr as any)?.PROCUREMENTID].push(curr);
					} else {
						acc[(curr as any)?.PROCUREMENTID] = [curr];
					}

					return acc;
				}, {});
			}

			const actualData = JSON.parse(JSON.stringify(pfiItems)).map((e) => {
				const lcInfo = consolidatedLcData[e?.PROCUREMENTID];
				const shipmentData = consolidatedShipmentData[e?.PROCUREMENTID];
				const tt = consolidatedTT[e?.PROCUREMENTID];
				const pfiItems = { ...e };
				delete pfiItems.PROCUREMENTINFO;
				const consolidatedTTs =
					tt && tt.length
						? tt.reduce((acc, curr, index) => {
								acc[`PAYMENTDATE${index + 1}`] =
									curr.TTPAYMENTDATE;
								acc[`PAYMENTAMOUNT${index + 1}`] =
									curr.TTPAYMENTAMOUNT;
								return acc;
						  }, {})
						: {};
				const data = {
					...pfiItems,
					...lcInfo,
					...shipmentData,
					...e?.PROCUREMENTINFO,
					...consolidatedTTs,
				};
				return data;
			});

			const formFields = await Reports.findAll({
				where: {
					REPORTID: 1,
					ACTIVE: true,
				},
				raw: true,
			});

			const header = formFields.reduce((acc, curr) => {
				acc[(curr as any).FIELDNAME] = {
					SEQUENCE: (curr as any).FIELDSEQUENCE,
					DESC: (curr as any).FIELDDESCRIPTION,
				};
				return acc;
			}, {});
			// const data = await Procurement.findAll({
			// 	where: {
			// 		OUID: OUID,
			// 	},
			// 	raw: true,
			// });

			console.log('actualData', actualData);
			res.locals.data = {
				data: {
					HEADER: header,
					DETAIL: actualData,
				},
			};
			super.send(res);
			console.log('getOrderTrackerReport API completed');
		} catch (err) {
			logger.error(
				`Error in getOrderTrackerReport : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getTradeFinanceReport(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { OUID = 1, USERID } = req.query;
			console.log('getTradeFinanceReport API Initiated');

			const tradeFinanceData = await Tradefinance.findAll({
				attributes: [
					'PROCUREMENTID',
					'SONAPPLICABLE',
					'SONPRODCERTAPPSENTTOCQA',
					'SONCAPRECEIVEDCQA',
					'INSURANCERATE',
					'INSURANCEAPPLICATIONNAMEOFBANK',
					'INSURANCEAPPLIED',
					'INSURANCEVALIDATED',
					'INSURANCEDATE',
					'INSURANCECERTIFICATENO',
					'INSURANCEPREMIUMAMOUNT',
					'SUMASSURED',
					'COVERAGE',
					'FORMMVALIDATEDDATE',
					'FORMMREGISTEREDDATE',
					'FORMMNO',
					'FORMMHSCODE',
					'PVSNO',
					'BANKAPPLICATIONNO',
					'FORMMNAMEOFBANK',
				],
				where: {},
				raw: true,
			});

			const pfiItems = await Pfiitems.findAll({
				attributes: [
					'ITEMDESCRIPTION',
					'ITEMQUANTITY',
					'PROCUREMENTID',
				],
				where: {},
				include: [
					{
						model: Procurement,
						attributes: [
							'ID',
							'PONO',
							'PODATE',
							'PFIAMOUNT',
							'CURRENCY',
							'PFIMODEOFPAYMENT',
							'PAYMENTTERMS',
							'FACTORY',
							'PFIDATE',
							'PFINO',
							'SUPPLIERNAME',
							'TYPEOFMATERIAL',
						], // Selecting SECTION from SectionsMaster
						as: 'PROCUREMENTINFO',
					},
				],
				order: [['ID', 'desc']],
			});

			let tradeFinanceConsolidation = {};
			if (tradeFinanceData && tradeFinanceData.length) {
				tradeFinanceConsolidation = tradeFinanceData.reduce(
					(acc, curr) => {
						acc[(curr as any).PROCUREMENTID] = curr;
						return acc;
					},
					{},
				);
			}

			const shipmentData = await Shipment.findAll({
				attributes: [
					'PROCUREMENTID',
					'SCANDOCSRECEIVED',
					'COMMERCIALINVOICENUMBER',
					'COMMERCIALINVOICEDATE',
					'COMMERCIALINVOICEAMOUNT',
					'BLDATE',
					'BLNO',
					'SCANNEDDOCUMENTSSHAREDTOIMPORTTEAM',
					'IBDDATE',
					'IBDNUMBER',
					'SONCAPIPAPPLIEDDATE',
					'SONCAPIPRECEIVEDDATE',
					'FURTHERSHIPMENTS',
					'SHIPMENTPLANNINGANDEXECUTIONMODEOFPAYMENT',
					'ORIGINALDOCSRECEIVED',
					'APPLIEDFORPAAR',
					'PAARRECEIVEDDATE',
					'PAARSENTTOIMPORTTEAM',
					'DEBITNOTEDATEFORINSURANCE',
					'DEBITNOTENOFORINSURANCE',
					'DEBITNOTEPAYMENTCOMPLETEDFORINSURANCE',
				],
				where: {},
				raw: true,
			});

			let shipmentDataConsolidation = {};
			if (shipmentData && shipmentData.length) {
				shipmentDataConsolidation = shipmentData.reduce((acc, curr) => {
					acc[(curr as any).PROCUREMENTID] = curr;
					return acc;
				}, {});
			}

			const lcData = await LC.findAll({
				attributes: [
					'PROCUREMENTID',
					'REQUESTFORDRAFTLC',
					'DRAFTLCRECEIVED',
					'DRAFTLCSHAREDTOSUPPLIER',
					'SUPPLIERFEEDBACKONDRAFTLC',
					'REQUESTFORREVISEDDRAFTLC',
					'REVISEDDRAFTLCRECEIVEDFROMBANK',
					'REVISEDDRAFTLCSHAREDWITHSUPPLIER',
					'SUPPLIERFEEDBACKONREVISEDDRAFTLC',
					'REQUESTTOBANKFORFINALLCTELEX',
					'FINALLCTELEXRECEIVED',
					'FINALLCTELEXSHAREDWITHSUPPLIER',
					'LCRECEIVEDBYSUPPLIER',
					'LCDATE',
					'LCNUMBER',
					'LCAMOUNT',
					'TOLERANCEPERECENT',
					'LCLATESTSHIPMENTDATE',
					'DATEOFEXPIRY',
					'LCSTATUS',
					'LCAMENDMENTREQUIRED',
					'LCAMENDMENTCOMPLETED',
					'DISCRIPANCYOBSERVED',
					'DISCRIPANCYWAIVED',
					'LCCLOSUREREQUESTREQUIRED',
					'LCCLOSUREREQUESTSENTTOBANK',
				],
				where: {},
				raw: true,
			});

			let lcDataConsolidation = {};
			if (lcData && lcData.length) {
				lcDataConsolidation = lcData.reduce((acc, curr) => {
					acc[(curr as any).PROCUREMENTID] = curr;
					return acc;
				}, {});
			}

			const ttData = await TT.findAll({
				where: {},
				raw: true,
			});

			const ttDataConsolidation = {};

			if (ttData && ttData.length) {
				ttData.map((element) => {
					if (!ttDataConsolidation[(element as any).PROCUREMENTID]) {
						ttDataConsolidation[(element as any).PROCUREMENTID] =
							{};
					}
					if (ttDataConsolidation[(element as any).PROCUREMENTID]) {
						if (
							ttDataConsolidation[(element as any).PROCUREMENTID]
								?.TTCOUNT
						) {
							ttDataConsolidation[
								(element as any).PROCUREMENTID
							].TTCOUNT += 1;
						} else {
							ttDataConsolidation[
								(element as any).PROCUREMENTID
							].TTCOUNT = 1;
						}
						const count =
							ttDataConsolidation[(element as any).PROCUREMENTID]
								.TTCOUNT;
						ttDataConsolidation[(element as any).PROCUREMENTID][
							`PAYMENTDATE${count}`
						] = (element as any).TTPAYMENTDATE;
						ttDataConsolidation[(element as any).PROCUREMENTID][
							`PAYMENTAMOUNT${count}`
						] = (element as any).TTPAYMENTAMOUNT;
					}
				});
			}

			const actualData = JSON.parse(JSON.stringify(pfiItems)).map((e) => {
				const tradeFinanceInfo =
					tradeFinanceConsolidation[e?.PROCUREMENTID];
				const shipmentData =
					shipmentDataConsolidation[e?.PROCUREMENTID];
				const lcInfo = lcDataConsolidation[e?.PROCUREMENTID];

				const tt = ttDataConsolidation[e?.PROCUREMENTID];
				const pfiItems = { ...e };
				delete pfiItems.PROCUREMENTINFO;

				const data = {
					...tradeFinanceInfo,
					...pfiItems,
					...lcInfo,
					...shipmentData,
					...e?.PROCUREMENTINFO,
					...tt,
				};
				return data;
			});

			const formFields = await Reports.findAll({
				where: {
					REPORTID: 2,
					ACTIVE: true,
				},
				raw: true,
			});

			const header = formFields.reduce((acc, curr) => {
				acc[(curr as any).FIELDNAME] = {
					SEQUENCE: (curr as any).FIELDSEQUENCE,
					DESC: (curr as any).FIELDDESCRIPTION,
				};
				return acc;
			}, {});

			res.locals.data = {
				data: {
					HEADER: header,
					DETAIL: actualData,
				},
			};
			super.send(res);
			console.log('getTradeFinanceReport API completed');
		} catch (err) {
			logger.error(
				`Error in getTradeFinanceReport : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getClearanceReport(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { OUID = 1, USERID } = req.query;
			console.log('getClearanceReport API Initiated');

			const pfiItems = await Pfiitems.findAll({
				attributes: [
					'ITEMDESCRIPTION',
					'ITEMQUANTITY',
					'PROCUREMENTID',
				],
				where: {},
				include: [
					{
						model: Procurement,
						attributes: [
							'ID',
							'PONO',
							'PODATE',
							'FACTORY',
							'SUPPLIERNAME',
						], // Selecting SECTION from SectionsMaster
						as: 'PROCUREMENTINFO',
					},
				],
				order: [['ID', 'desc']],
			});

			const tradeFinance = await Tradefinance.findAll({
				attributes: ['FORMMNO', 'PROCUREMENTID'],
				raw: true,
			});

			let tradeFinanceConsolidation = {};
			if (tradeFinance && tradeFinance.length) {
				tradeFinanceConsolidation = tradeFinance.reduce((acc, curr) => {
					acc[(curr as any).PROCUREMENTID] = curr;
					return acc;
				}, {});
			}

			const shipment = await Shipment.findAll({
				attributes: [
					'PROCUREMENTID',
					'SCANDOCSRECEIVED',
					'BLDATE',
					'BLNO',
					'IBDNUMBER',
					'SHIPMENTPLANNINGANDEXECUTIONMIRONO',
					'ORIGINALDOCSRECEIVED',
					'EXPETAPORT',
					'SHIPPINGLINE',
					'TERMINAL',
					'VESSESLNAME',
					// 'CONTAINERNO',
					// 'CONTAINERSIZE',
					'TOCHECKUPLOADEDINGOCOMET',
					'SHIPMENTPLANNINGANDEXECUTIONAGENT',
					'SHIPMENTPLANNINGANDEXECUTIONDOCSTOFACTORY',
					'MAILTOINSURANCE',
				],
				raw: true,
			});

			let shipmentDataConsolidation = {};
			if (shipment && shipment.length) {
				shipmentDataConsolidation = shipment.reduce((acc, curr) => {
					acc[(curr as any).PROCUREMENTID] = curr;
					return acc;
				}, {});
			}

			const clearance = await Clearance.findAll({
				attributes: [
					'PROCUREMENTID',
					'DUTYASSESSMENT',
					'CNUMBER',
					'ANUMBER',
					'DUTYASSESMENTDOCSTOFACTORY',
					'DUTYRECEIPTNEPZACOLLECTION',
					'CUSTOMRELEASE',
					'SHIPPINGLINECHARGES',
					'SHIPPINGLINEDEMMURAGE',
					'FOU3',
					'EXIT1',
					'SDO1',
					'TDO',
					'GATEOUT',
					'FACTORYIN',
					'FACTORYOUT',
					'EMPTYRETURN',
					'IM4059',
					'CLEARANCE',
					'DUTYAMOUNT',
					'FACTORYOFFLOADANDRETURNVAT',
					'IM5900',
					'FACTORYOFFLOADINGANDRETURNAGENT',
					'ECDRECEIVED',
					'ECDSUBMISSION',
					'ECDACKNOWLEDGEMENT',
					'AGENCYFEE',
					'DEMURRAGEONTRUCK',
					'ECDANDINVOICEVAT',
					'CONTAINERDEPOSIT',
					'TERMINALREFUND',
					'SHIPPINGLINEREFUND',
					'CONTAINERDEPOSITREFUND',
					'DNAMOUNT',
					'FINALPCACLOSURE',
					'TRANSPORT',
					'FINALNAFDAC',
					'TERMINALCHARGES',
					'TERMINALSTORAGE',
					'ADVANCE',
					'NAFDAC',
					'SON',
				],
				where: {},
				raw: true,
			});

			let clearanceConsolidation = {};
			if (clearance && clearance.length) {
				clearanceConsolidation = clearance.reduce((acc, curr) => {
					acc[(curr as any).PROCUREMENTID] = curr;
					return acc;
				}, {});
			}

			const actualData = JSON.parse(JSON.stringify(pfiItems)).map((e) => {
				const tradeFinanceInfo =
					tradeFinanceConsolidation[e?.PROCUREMENTID];
				const shipmentData =
					shipmentDataConsolidation[e?.PROCUREMENTID];
				const clearanceInfo = clearanceConsolidation[e?.PROCUREMENTID];
				const pfiItems = { ...e };
				delete pfiItems.PROCUREMENTINFO;

				const data = {
					...tradeFinanceInfo,
					...pfiItems,
					...clearanceInfo,
					...shipmentData,
					...e?.PROCUREMENTINFO,
				};
				return data;
			});

			const formFields = await Reports.findAll({
				where: {
					REPORTID: 3,
					ACTIVE: true,
				},
				raw: true,
			});

			const header = formFields.reduce((acc, curr) => {
				acc[(curr as any).FIELDNAME] = {
					SEQUENCE: (curr as any).FIELDSEQUENCE,
					DESC: (curr as any).FIELDDESCRIPTION,
				};
				return acc;
			}, {});

			res.locals.data = {
				data: {
					HEADER: header,
					DETAIL: actualData,
				},
			};
			super.send(res);
			console.log('getClearanceReport API completed');
		} catch (err) {
			logger.error(
				`Error in getClearanceReport : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}
}
