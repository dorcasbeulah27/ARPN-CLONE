import { config } from 'dotenv';
import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Op, Sequelize, Transaction, where } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import Database from '../../../database';
import LCMain from '../../../database/models/business/LCMain';
import ActivityLogs from '../../../database/models/business/activityLogs';
import Attachments from '../../../database/models/business/attachments';
import Clearance from '../../../database/models/business/clearance/clearance';
import LiquidationList from '../../../database/models/business/liquidation/liquidation';
import ttList from '../../../database/models/business/liquidation/tt';
import Pfiitems from '../../../database/models/business/procurement/pfiItems';
import PoItems from '../../../database/models/business/procurement/poItems';
import Procurement from '../../../database/models/business/procurement/procurement';
import ProcurementOil from '../../../database/models/business/procurementOil/procurement';
import ProcurementWheat from '../../../database/models/business/procurementWheat/procurement';
import Polcsectionstatus from '../../../database/models/business/purchaseOrder/poLcSectionStatus';
import PolcsectionstatusOil from '../../../database/models/business/purchaseOrder/poLcSectionStatusOil';
import PolcsectionstatusWheat from '../../../database/models/business/purchaseOrder/poLcSectionStatusWheat';
import PurchaseOrder from '../../../database/models/business/purchaseOrder/purchaseOrder';
import Container from '../../../database/models/business/shipment/container';
import Shipment from '../../../database/models/business/shipment/shipment';
import Tradefinance from '../../../database/models/business/tradeFinance/tradeFinance';
import LC from '../../../database/models/business/ttlc/lc';
import TT from '../../../database/models/business/ttlc/tt';
import comboMaster from '../../../database/models/masters/comboMaster';
import FormConfigMapping from '../../../database/models/masters/formConfigMapping';
import FormFieldsMaster from '../../../database/models/masters/formFieldsMaster';
import SectionsMaster from '../../../database/models/masters/sectionsMaster';
import logger from '../../../lib/logger';
import comboFormatter from '../../../utils/comboFormatter';
import upload from '../../../utils/fileUpload';
import BaseApi from '../../BaseApi';

/**
 * Purchase Order Controller
 */
export default class PurchaseOrderController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.post(
			'/postPurchaseOrder',
			this.postPurchaseOrder.bind(this),
		);
		this.router.post('/postPFI', this.postPFI.bind(this));
		this.router.get('/poNumber', this.getPoNumber.bind(this));
		this.router.post('/postLCInfo', this.postLCInfo.bind(this));
		this.router.post('/postLCEntry', this.postLCEntry.bind(this));
		this.router.post(
			'/createNewShipment',
			this.createNewShipment.bind(this),
		);
		this.router.get('/getPurchaseOrder', this.getPurchaseOrder.bind(this));
		this.router.get('/getFormMEntries', this.getFormMEntries.bind(this));
		this.router.get(
			'/getFormMEntriesOil',
			this.getFormMEntriesOil.bind(this),
		);
		this.router.get('/getFactories', this.getFactories.bind(this));
		this.router.get('/getMaterialType', this.getMaterialType.bind(this));
		// this.router.get(
		// 	'/getPurchaseOrderKPI',
		// 	this.getPurchaseOrderKPI.bind(this),
		// );
		return this.router;
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createNewShipment(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		const transaction = await Database.getConnection().transaction();
		try {
			console.log('postIndividualLCEntries initalized');
			const { data } = req.body;
			const { OUID = 1, ROLEID = 1 } = req.query;
			const { ID } = data;
			const procurement = await Procurement.findOne({
				where: {
					ID,
				},
				raw: true,
				transaction,
			});
			delete (procurement as any).ID;
			(procurement as any).SEQUENCE = (procurement as any).SEQUENCE + 1;

			const newProcurement = await Procurement.create(
				procurement as any,
				{ transaction },
			);

			const polcSelectionInfo = await Polcsectionstatus.findAll({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
				transaction,
			});

			if (polcSelectionInfo?.length) {
				const polcSelection = await Polcsectionstatus.bulkCreate(
					(polcSelectionInfo as any).map((element) => {
						delete element.ID;
						element.PROCUREMENTID = (newProcurement as any).ID;
						if (
							element.SECTIONAME == 'SHIPMENT' ||
							element.SECTIONAME == 'CLEARANCE'
						) {
							element.STATUS = 'NEW';
						}
						return element;
					}),
					{ transaction },
				);
			}

			const pfiItems = await Pfiitems.findAll({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
				transaction,
			});
			if (pfiItems?.length) {
				const newPFI = await Pfiitems.bulkCreate(
					(pfiItems as any).map((element) => {
						delete element.ID;
						element.PROCUREMENTID = (newProcurement as any).ID;
						return element;
					}),
					{ transaction },
				);
			}

			const tradeFinance = await Tradefinance.findOne({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
				transaction,
			});
			if ((tradeFinance as any)?.ID) {
				(tradeFinance as any).PROCUREMENTID = (
					newProcurement as any
				).ID;
				delete (tradeFinance as any).ID;
				const newTradeFinance = await Tradefinance.create(
					tradeFinance as any,
					{ transaction },
				);
			}

			const lc = await LC.findOne({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
				transaction,
			});

			if ((lc as any)?.ID) {
				(lc as any).PROCUREMENTID = (newProcurement as any).ID;
				delete (lc as any).ID;
				const newLC = await LC.create(lc as any, { transaction });
			}

			const attachments = await Attachments.findAll({
				where: {
					PROCUREMENTID: ID,
					FIELDNAME: {
						[Op.in]: [
							'PFIATTACHMENT',
							'POATTACHMENT',
							'PRATTACHMENT',
							'FORMMATTACHMENT',
							'LCATTACHMENT',
						],
					},
				},
				raw: true,
				transaction,
			});

			if (attachments?.length) {
				const newAttachments = await Attachments.bulkCreate(
					(attachments as any).map((element) => {
						delete element.ID;
						element.PROCUREMENTID = (newProcurement as any).ID;
						return element;
					}),
					{ transaction },
				);
			}

			await transaction.commit();
			res.locals.data = {
				message: 'New Shipment has been created successfully.',
			};

			super.send(res);
			console.log('New Shipment has been created');
		} catch (err) {
			await transaction.rollback();
			logger.error(
				`Error in Adding New Shipment entry : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async postLCInfo(req: Request, res: Response, next: NextFunction) {
		const transaction = await Database.getConnection().transaction({
			isolationLevel: Transaction.ISOLATION_LEVELS.READ_COMMITTED,
		});
		try {
			console.log('postPurchaseOrder initalized');
			const { data, FLAG } = req.body;
			const { OUID = 1, USERID } = req.query;
			const finalObj = { ...data, OUID };
			const { SECTIONNAME = '' } = data;

			if (!SECTIONNAME) {
				await transaction.rollback();
				throw new ApiError(
					'Invalid Section Name',
					StatusCodes.BAD_REQUEST,
					res,
				);
			}

			if (SECTIONNAME === 'PROCUREMENT') {
				const ProcurementInfo = await Procurement.findOne({
					where: {
						ID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if (
					(ProcurementInfo as any)?.SUBMITTED ||
					(ProcurementInfo as any)?.LOCKED
				) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((ProcurementInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await Procurement.update(
							{ ...x, SUBMITTED: data?.FLAG === 'COMPLETED' },
							{
								where: {
									ID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await Procurement.create(
							{
								...x,
								SUBMITTED: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					if (data?.ITEMDETAILSFLAG) {
						await Pfiitems.destroy({
							where: {
								PROCUREMENTID: data?.ID,
							},
							transaction,
						});

						await Pfiitems.bulkCreate(
							data?.ITEMDETAILS?.map(
								(element) => {
									const d = { ...element };
									if (d.ID) {
										delete d.ID;
									}
									return {
										...d,
										PROCUREMENTID: data?.ID,
										OUID,
										PFINO: data?.PFINO,
										PONO: data?.PONO,
									};
								},
								{ transaction },
							),
						);
					}

					// if (data?.ITEMDETAILSFLAG) {
					// 	await Pfiitems.destroy({
					// 		where: {
					// 			PROCUREMENTID: data?.ID,
					// 		},
					// 	});

					// 	await Pfiitems.bulkCreate(
					// 		data?.ITEMDETAILS?.map((element) => ({
					// 			...element,
					// 			PROCUREMENTID: data?.ID,
					// 			OUID,
					// 			PFINO: data?.PFINO,
					// 			PONO: data?.PONO,
					// 		})),
					// 	);
					// }

					const attachments = [];
					const attachmentsData = [];
					if (data?.PFIATTACHMENTFLAG) {
						attachments.push('PFIATTACHMENT');
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'PFIATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}
					if (data?.POATTACHMENTFLAG) {
						attachments.push('POATTACHMENT');
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'POATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}
					if (data?.PRATTACHMENTFLAG) {
						attachments.push('PRATTACHMENT');
						data?.PFIATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'PRATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (attachmentsData?.length) {
						await Attachments.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await Attachments.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}
			} else if (SECTIONNAME === 'TRADEFINANCE') {
				const tradeFinanceInfo = await Tradefinance.findOne({
					where: {
						PROCUREMENTID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if (
					(tradeFinanceInfo as any)?.SUBMITTED ||
					(tradeFinanceInfo as any)?.LOCKED
				) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((tradeFinanceInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await Tradefinance.update(
							{ ...x, SUBMITTED: data?.FLAG === 'COMPLETED' },
							{
								where: {
									PROCUREMENTID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await Tradefinance.create(
							{
								...x,
								PROCUREMENTID: data?.ID,
								SUBMITTED: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					const attachments = [];
					const attachmentsData = [];

					if (data?.SONNAFDACATTACHMENTFLAG) {
						attachments.push('SONNAFDACATTACHMENT');
						data?.SONNAFDACATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'SONNAFDACATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					// if (data?.SONNAFDACATTACHMENTFLAG) {
					// 	attachments.push('SONNAFDACATTACHMENT');
					// 	data?.SONNAFDACATTACHMENT.map((e) => {
					// 		attachmentsData.push({
					// 			DOCNAME: e,
					// 			FIELDNAME: 'SONNAFDACATTACHMENT',
					// 			PROCUREMENTID: data?.ID,
					// 		});
					// 	});
					// }

					if (data?.FORMMATTACHMENTFLAG) {
						attachments.push('FORMMATTACHMENT');
						data?.FORMMATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'FORMMATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (attachmentsData?.length) {
						await Attachments.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await Attachments.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}
			} else if (SECTIONNAME === 'TTLC') {
				if (data?.TTFLAG) {
					const ttInfo = await TT.findOne({
						where: {
							PROCUREMENTID: data?.ID,
						},
						raw: true,
						transaction,
					});

					if ((ttInfo as any)?.SUBMITTED || (ttInfo as any)?.LOCKED) {
						await transaction.rollback();
						throw new ApiError(
							'Records are already submitted, So information cannot be altered',
							StatusCodes.BAD_REQUEST,
							res,
						);
					} else {
						await TT.destroy({
							where: {
								PROCUREMENTID: data?.ID,
							},
							transaction,
						});

						await TT.bulkCreate(
							data?.TT?.map((element) => {
								const d = { ...element };
								if (d.ID) {
									delete d.ID;
								}
								return {
									...d,
									PROCUREMENTID: data?.ID,
									SUBMITTED: data?.FLAG === 'COMPLETED',
									OUID,
								};
							}),
							{ transaction },
						);

						const attachments = [];
						const attachmentsData = [];

						if (data?.TTATTACHMENTFLAG) {
							attachments.push('TTATTACHMENT');
							data?.TTATTACHMENT.map((e) => {
								attachmentsData.push({
									DOCNAME: e,
									FIELDNAME: 'TTATTACHMENT',
									PROCUREMENTID: data?.ID,
								});
							});
						}

						if (attachmentsData?.length) {
							await Attachments.destroy({
								where: {
									PROCUREMENTID: data?.ID,
									FIELDNAME: {
										[Op.in]: attachments,
									},
								},
								transaction,
							});

							await Attachments.bulkCreate(
								attachmentsData.map((e) => {
									const d = { ...e };
									if (d.ID) {
										delete d.ID;
									}
									return d;
								}),
								{
									transaction,
								},
							);
						}
					}
				} else {
					const lcInfo = await LC.findOne({
						where: {
							PROCUREMENTID: data?.ID,
						},
						raw: true,
						transaction,
					});

					if ((lcInfo as any)?.SUBMITTED || (lcInfo as any)?.LOCKED) {
						await transaction.rollback();
						throw new ApiError(
							'Records are already submitted, So information cannot be altered',
							StatusCodes.BAD_REQUEST,
							res,
						);
					} else {
						if ((lcInfo as any)?.ID) {
							const x = { ...data };
							x.PROCUREMENTID = data.ID;
							delete x.ID;
							await LC.update(
								{
									...x,
									SUBMITTED: data?.FLAG === 'COMPLETED',
								},
								{
									where: {
										PROCUREMENTID: data?.ID,
									},
									transaction,
								},
							);
						} else {
							const x = { ...data };
							x.PROCUREMENTID = data.ID;
							delete x.ID;
							await LC.create(
								{
									...x,
									PROCUREMENTID: data?.ID,
									SUBMITTED: data?.FLAG === 'COMPLETED',
								},
								{ transaction },
							);
						}

						const attachments = [];
						const attachmentsData = [];

						if (data?.LCATTACHMENTFLAG) {
							attachments.push('LCATTACHMENT');
							data?.LCATTACHMENT.map((e) => {
								attachmentsData.push({
									DOCNAME: e,
									FIELDNAME: 'LCATTACHMENT',
									PROCUREMENTID: data?.ID,
								});
							});
						}

						if (attachmentsData?.length) {
							await Attachments.destroy({
								where: {
									PROCUREMENTID: data?.ID,
									FIELDNAME: {
										[Op.in]: attachments,
									},
									transaction,
								},
							});

							await Attachments.bulkCreate(attachmentsData, {
								transaction,
							});
						}
					}
				}
			} else if (SECTIONNAME === 'SHIPMENT') {
				const shipmentInfo = await Shipment.findOne({
					where: {
						PROCUREMENTID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if (
					(shipmentInfo as any)?.SUBMITTED ||
					(shipmentInfo as any)?.LOCKED
				) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((shipmentInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await Shipment.update(
							{ ...x, SUBMITTED: data?.FLAG === 'COMPLETED' },
							{
								where: {
									PROCUREMENTID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await Shipment.create(
							{
								...x,
								PROCUREMENTID: data?.ID,
								SUBMITTED: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					const attachments = [];
					const attachmentsData = [];

					if (data?.SHIPMENTATTACHMENTFLAG) {
						attachments.push('SHIPMENTATTACHMENT');
						data?.SHIPMENTATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'SHIPMENTATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.PAARATTACHMENTFLAG) {
						attachments.push('PAARATTACHMENT');
						data?.PAARATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'PAARATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.TRANSIRETTACHMENTFLAG) {
						attachments.push('TRANSIRETTACHMENT');
						data?.TRANSIRETTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'TRANSIRETTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (attachmentsData?.length) {
						await Attachments.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await Attachments.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}

				if (data?.CONTAINERFLAG) {
					await Container.destroy({
						where: {
							PROCUREMENTID: data?.ID,
						},
						transaction,
					});

					await Container.bulkCreate(
						data?.CONTAINER?.map((element) => {
							const d = { ...element };
							if (d.ID) {
								delete d.ID;
							}
							return {
								...d,
								PROCUREMENTID: data?.ID,
							};
						}),
						{ transaction },
					);
				}
			} else if (SECTIONNAME === 'CLEARANCE') {
				const clearanceInfo = await Clearance.findOne({
					where: {
						PROCUREMENTID: data?.ID,
					},
					raw: true,
					transaction,
				});

				if (
					(clearanceInfo as any)?.SUBMITTED ||
					(clearanceInfo as any)?.LOCKED
				) {
					await transaction.rollback();
					throw new ApiError(
						'Records are already submitted, So information cannot be altered',
						StatusCodes.BAD_REQUEST,
						res,
					);
				} else {
					if ((clearanceInfo as any)?.ID) {
						const x = { ...data };
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await Clearance.update(
							{ ...x, SUBMITTED: data?.FLAG === 'COMPLETED' },
							{
								where: {
									PROCUREMENTID: data?.ID,
								},
								transaction,
							},
						);
					} else {
						const x = { ...data };
						console.log('CLEARANCE', x);
						x.PROCUREMENTID = data.ID;
						delete x.ID;
						await Clearance.create(
							{
								...x,
								SUBMITTED: data?.FLAG === 'COMPLETED',
							},
							{ transaction },
						);
					}

					const attachments = [];
					const attachmentsData = [];

					if (data?.CLEARENCERELEASEFOUATTACHMENTFLAG) {
						attachments.push('CLEARENCERELEASEFOUATTACHMENT');
						data?.CLEARENCERELEASEFOUATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'CLEARENCERELEASEFOUATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.DUTYASSESMENTATTACHMENTFLAG) {
						attachments.push('DUTYASSESMENTATTACHMENT');
						data?.DUTYASSESMENTATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'DUTYASSESMENTATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (data?.ECDINVOICEATTACHMENTFLAG) {
						attachments.push('ECDINVOICEATTACHMENT');
						data?.ECDINVOICEATTACHMENT.map((e) => {
							attachmentsData.push({
								DOCNAME: e,
								FIELDNAME: 'ECDINVOICEATTACHMENT',
								PROCUREMENTID: data?.ID,
							});
						});
					}

					if (attachmentsData?.length) {
						await Attachments.destroy({
							where: {
								PROCUREMENTID: data?.ID,
								FIELDNAME: {
									[Op.in]: attachments,
								},
							},
							transaction,
						});

						await Attachments.bulkCreate(
							attachmentsData.map((e) => {
								const d = { ...e };
								if (d.ID) {
									delete d.ID;
								}
								return d;
							}),
							{
								transaction,
							},
						);
					}
				}
			}
			const x = await Polcsectionstatus.update(
				{
					STATUS: data.FLAG,
				},
				{
					where: {
						PROCUREMENTID: data?.ID,
						SECTIONAME: SECTIONNAME,
					},
					transaction,
				},
			);

			await ActivityLogs.create(
				{
					USERID,
					SECTIONNAME,
					DATA: data,
				},
				{ transaction },
			);

			await transaction.commit();
			res.locals.data = {
				message: 'Data updated successfully.',
				ID: data?.ID,
			};
			super.send(res);
			console.log('postPurchaseOrder API completed');
		} catch (err) {
			await transaction.rollback();
			logger.error(
				`Error in postPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getFactories(req: Request, res: Response, next: NextFunction) {
		try {
			console.log('getFactories Combo API Initiated');
			const factoriesList = await comboMaster.findAll({
				where: {
					FIELDID: 15,
				},
				raw: true,
			});

			res.locals.data = comboFormatter(factoriesList, 'LABEL', 'VALUE');

			super.send(res);
			console.log('getFactories Combo API Completed');
		} catch (err) {
			logger.error(
				`Error in getFactories : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getMaterialType(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getMaterialType Combo API Initiated');
			const materialTypeList = await comboMaster.findAll({
				where: {
					FIELDID: 18,
				},
				raw: true,
			});

			res.locals.data = comboFormatter(
				materialTypeList,
				'LABEL',
				'VALUE',
			);

			super.send(res);
			console.log('getMaterialType Combo API Completed');
		} catch (err) {
			logger.error(
				`Error in getMaterialType : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getPoNumber(req: Request, res: Response, next: NextFunction) {
		try {
			console.log('PurchaseOrder Combo API Initiated');
			const poNumber = await PurchaseOrder.findAll({
				raw: true,
			});

			res.locals.data = comboFormatter(poNumber, 'PONO', 'PONO', [
				'FACTORY',
				'PODATE',
				'ID',
			]);

			super.send(res);
			console.log('PurchaseOrder Combo API Completed');
		} catch (err) {
			logger.error(
				`Error in postPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async postLCEntry(req: Request, res: Response, next: NextFunction) {
		const transaction = await Database.getConnection().transaction();
		try {
			console.log('postIndividualLCEntries initalized');
			const { data } = req.body;
			const { OUID = 1, ROLEID = 1 } = req.query;

			const formMNo = await LCMain.findAll({
				where: {
					FORMMNO: data?.FORMMNO,
				},
				raw: true,
				transaction,
			});

			if (formMNo.length > 0) {
				logger.error(
					`Form M already exists against PO - ${(formMNo[0] as any)
						?.PONO}`,
				);
				throw new ApiError(
					`Form M already exists against PO - ${(formMNo[0] as any)
						?.PONO}`,
					StatusCodes.BAD_REQUEST,
					res,
				);
			}

			let lcInfo = await LCMain.create(data, {
				transaction,
			});

			lcInfo = JSON.parse(JSON.stringify(lcInfo));

			const formType = await FormConfigMapping.findOne({
				where: {
					VALUE: data.FACTORY,
					ACTIVE: true,
				},
				raw: true,
				transaction,
			});

			if ((formType as any)?.ACTIVE) {
				const distinctSectionIds = await FormFieldsMaster.findAll({
					attributes: ['SECTIONID'],
					include: [
						{
							model: SectionsMaster,
							attributes: ['SECTIONNAME', 'SECTIONSEQUENCE'], // Selecting SECTION from SectionsMaster
							as: 'section',
							where: {
								ACTIVE: true,
							},
						},
					],
					where: {
						FORMID: (formType as any).FORMID,
						ROLEID,
					},
					raw: true,
					transaction,
					group: [
						'SECTIONID',
						'section.SECTIONNAME',
						'section.SECTIONSEQUENCE',
					],
				});

				await Polcsectionstatus.bulkCreate(
					distinctSectionIds.map((element) => ({
						OUID,
						LCMAINID: (lcInfo as any)?.ID || 0,
						FORMMNO: data?.FORMMNO || '',
						FORMID: (formType as any).FORMID,
						SECTIONAME: element['section.SECTIONNAME'],
						SECTIONSEQUENCE: element['section.SECTIONSEQUENCE'],
						STATUS: 'NEW',
					})),
					{
						transaction,
					},
				);

				await transaction.commit();
				res.locals.data = {
					message: 'Form M entry has been created successfully.',
				};

				super.send(res);
				console.log('Form M entry API completed');
			} else {
				logger.error(
					'Error in Form M entry : No Form Configuration found',
				);
				throw new ApiError(
					'No Form Configuration found',
					StatusCodes.BAD_REQUEST,
					res,
				);
			}
		} catch (err) {
			transaction.rollback();
			logger.error(
				`Error in Form M entry : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async postPFI(req: Request, res: Response, next: NextFunction) {
		const transaction = await Database.getConnection().transaction();
		try {
			console.log('postPFIData initalized');
			const { data } = req.body;
			const { OUID = 1, ROLEID = 1 } = req.query;

			const { itemDetails = [] } = data;

			const pfiInfo = await Procurement.findAll({
				where: {
					PFINO: data?.PFINO,
				},
				raw: true,
				transaction,
			});

			if (pfiInfo.length) {
				logger.error('Error in postPFIData : PFI is already available');
				throw new ApiError(
					'PFI already exists',
					StatusCodes.BAD_REQUEST,
					res,
				);
			} else {
				// await PurchaseOrder.create(data, { transaction });

				let lcInfo = await Procurement.create(data, {
					transaction,
				});

				lcInfo = JSON.parse(JSON.stringify(lcInfo));

				if (itemDetails.length > 0) {
					const PFIItems = await Pfiitems.bulkCreate(
						itemDetails.map((e) => ({
							...e,
							OUID,
							PFINO: data.PFINO || '',
							PROCUREMENTID: (lcInfo as any)?.ID,
						})),
						{ transaction },
					);
				}

				const formType = await FormConfigMapping.findOne({
					where: {
						FACTORY: data.FACTORY,
						TYPEOFMATERIAL: data.TYPEOFMATERIAL,
						ACTIVE: true,
					},
					raw: true,
					transaction,
				});

				if ((formType as any)?.ACTIVE) {
					const distinctSectionIds = await FormFieldsMaster.findAll({
						attributes: ['SECTIONID'],
						include: [
							{
								model: SectionsMaster,
								attributes: ['SECTIONNAME', 'SECTIONSEQUENCE'], // Selecting SECTION from SectionsMaster
								as: 'section',
								where: {
									ACTIVE: true,
								},
							},
						],
						where: {
							FORMID: (formType as any).FORMID,
							ROLEID,
						},
						raw: true,
						transaction,
						group: [
							'SECTIONID',
							'section.SECTIONNAME',
							'section.SECTIONSEQUENCE',
						],
					});

					await Polcsectionstatus.bulkCreate(
						distinctSectionIds.map((element) => ({
							OUID,
							PROCUREMENTID: (lcInfo as any)?.ID || 0,
							PROCUREMENTSEQUENCE: (lcInfo as any)?.ID || 0,
							FORMMNO: data?.FORMMNO || '',
							FORMID: (formType as any).FORMID,
							SECTIONAME: element['section.SECTIONNAME'],
							SECTIONSEQUENCE: element['section.SECTIONSEQUENCE'],
							STATUS: 'NEW',
						})),
						{
							transaction,
						},
					);

					console.log('Form M entry API completed');
				} else {
					logger.error(
						'Error in Form M entry : No Form Configuration found',
					);
					throw new ApiError(
						'No Form Configuration found',
						StatusCodes.BAD_REQUEST,
						res,
					);
				}

				await transaction.commit();
				res.locals.data = {
					message: 'PFI created successfully.',
					// data: distinctSectionIds,
				};

				super.send(res);
				console.log('postPurchaseOrder API completed');
			}
		} catch (err) {
			transaction.rollback();
			logger.error(
				`Error in postPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async postPurchaseOrder(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		const transaction = await Database.getConnection().transaction();
		try {
			console.log('postPurchaseOrder initalized');
			const { data } = req.body;
			const { OUID = 1, ROLEID = 1 } = req.query;

			const poInfo = await PurchaseOrder.findAll({
				where: {
					PONO: data?.PONO,
				},
				raw: true,
				transaction,
			});

			if (poInfo.length) {
				logger.error(
					'Error in postPurchaseOrder : Po is already available',
				);
				throw new ApiError(
					'Po already exists',
					StatusCodes.BAD_REQUEST,
					res,
				);
			} else {
				await PurchaseOrder.create(data, { transaction });

				let lcInfo = await LCMain.create(data, {
					transaction,
				});

				lcInfo = JSON.parse(JSON.stringify(lcInfo));

				const formType = await FormConfigMapping.findOne({
					where: {
						VALUE: data.FACTORY,
						ACTIVE: true,
					},
					raw: true,
					transaction,
				});

				if ((formType as any)?.ACTIVE) {
					const distinctSectionIds = await FormFieldsMaster.findAll({
						attributes: ['SECTIONID'],
						include: [
							{
								model: SectionsMaster,
								attributes: ['SECTIONNAME', 'SECTIONSEQUENCE'], // Selecting SECTION from SectionsMaster
								as: 'section',
								where: {
									ACTIVE: true,
								},
							},
						],
						where: {
							FORMID: (formType as any).FORMID,
							ROLEID,
						},
						raw: true,
						transaction,
						group: [
							'SECTIONID',
							'section.SECTIONNAME',
							'section.SECTIONSEQUENCE',
						],
					});

					await Polcsectionstatus.bulkCreate(
						distinctSectionIds.map((element) => ({
							OUID,
							LCMAINID: (lcInfo as any)?.ID || 0,
							FORMMNO: data?.FORMMNO || '',
							FORMID: (formType as any).FORMID,
							SECTIONAME: element['section.SECTIONNAME'],
							SECTIONSEQUENCE: element['section.SECTIONSEQUENCE'],
							STATUS: 'NEW',
						})),
						{
							transaction,
						},
					);

					console.log('Form M entry API completed');
				} else {
					logger.error(
						'Error in Form M entry : No Form Configuration found',
					);
					throw new ApiError(
						'No Form Configuration found',
						StatusCodes.BAD_REQUEST,
						res,
					);
				}

				// const formType = await FormConfigMapping.findOne({
				// 	where: {
				// 		VALUE: data.FACTORY,
				// 	},
				// 	raw: true,
				// 	transaction,
				// });

				// const distinctSectionIds = await FormFieldsMaster.findAll({
				// 	attributes: ['SECTIONID'],
				// 	include: [
				// 		{
				// 			model: SectionsMaster,
				// 			attributes: ['SECTIONNAME'], // Selecting SECTION from SectionsMaster
				// 			as: 'section',
				// 		},
				// 	],
				// 	where: {
				// 		FORMID: (formType as any).FORMID,
				// 		ROLEID,
				// 	},
				// 	raw: true,
				// 	transaction,
				// 	group: ['SECTIONID', 'section.SECTIONNAME'],
				// });

				// await Polcsectionstatus.bulkCreate(
				// 	distinctSectionIds.map((element) => ({
				// 		OUID,
				// 		LCMAINID: data?.ID || 0,
				// 		FORMMNO: data?.FORMMNO || '',
				// 		SECTIONAME: element['section.SECTIONNAME'],
				// 		STATUS: 'NEW',
				// 	})),
				// 	{ transaction },
				// );

				await transaction.commit();
				res.locals.data = {
					message: 'Purchase order created successfully.',
					// data: distinctSectionIds,
				};

				super.send(res);
				console.log('postPurchaseOrder API completed');
			}
		} catch (err) {
			transaction.rollback();
			logger.error(
				`Error in postPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getPurchaseOrder(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getPurchaseOrder initalized');
			const { OUID = 1, ID } = req.query;

			const procurement = await Procurement.findOne({
				where: {
					ID,
				},
				raw: true,
			});

			const factory = await comboMaster.findOne({
				where: {
					FIELDID: 15,
					LABEL: (procurement as any)?.FACTORY,
				},
				raw: true,
			});

			// const poItems = await PoItems.findAll({
			// 	where: {
			// 		ID,
			// 	},
			// 	raw: true,
			// });
			const pfiItems = await Pfiitems.findAll({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});
			const tradeFinance = await Tradefinance.findOne({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});
			const lc = await LC.findOne({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const tt = await TT.findAll({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});
			const shipment = await Shipment.findOne({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const container = await Container.findAll({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});
			const clearance = await Clearance.findOne({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const attachments = await Attachments.findAll({
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
			});

			const attachmentsConsolidated = attachments.reduce((acc, curr) => {
				if (acc[(curr as any).FIELDNAME]) {
					acc[(curr as any).FIELDNAME].push(curr);
				} else {
					acc[(curr as any).FIELDNAME] = [curr];
				}
				return acc;
			}, {});

			const statusData = await Polcsectionstatus.findAll({
				attributes: [
					'FORMID',
					'PROCUREMENTID',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
				],
				where: {
					PROCUREMENTID: ID,
				},
				raw: true,
				group: [
					'FORMID',
					'PROCUREMENTID',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
				],
				order: [['SECTIONSEQUENCE', 'asc']],
			});

			const consolidatedData = statusData.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...acc[(curr as any).PROCUREMENTID],
					[(curr as any).SECTIONAME]: {
						STATUS: (curr as any).STATUS,
						SECTIONSEQUENCE: (curr as any).SECTIONSEQUENCE,
						SECTIONAME: (curr as any).SECTIONAME,
					},
					FORMID: (curr as any).FORMID,
				};
				return acc;
			}, {});

			console.log(
				'consolidatedData[(procurement as any).SEQUENCE]',
				consolidatedData,
				(procurement as any).ID,
			);

			const d = Object.values(
				consolidatedData[(procurement as any).ID],
			).reduce((acc, curr) => {
				console.log('curr==>', curr);
				if (isNaN(curr as any)) {
					acc[(curr as any).SECTIONSEQUENCE - 1] = {
						NAME: (curr as any).SECTIONAME,
						STATUS: (curr as any).STATUS,
					};
				}

				return acc;
			}, []);

			console.log(
				'consolidatedData[(procurement as any).SEQUENCE]',
				consolidatedData[(procurement as any).ID],
				d,
			);
			const formId =
				consolidatedData[(procurement as any).SEQUENCE]?.FORMID || 1;

			// delete d.FORMID;

			const finalData = {
				...clearance,
				...shipment,
				CONTAINER: container,
				...lc,
				...tradeFinance,
				TT: tt,
				STAGES: d,
				ITEMDETAILS: pfiItems,
				FORMID: formId,
				FACTORYNAME: (factory as any)?.LABEL || '',
				...procurement,
				...attachmentsConsolidated,
			};

			res.locals.data = {
				data: finalData,
			};
			super.send(res);
			console.log('getPurchaseOrder API completed');
		} catch (err) {
			logger.error(
				`Error in getPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getFormMEntries(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getFormMEntries initalized');
			const { OUID = 1 } = req.query;
			// const PoData = await LCMain.findAll({
			// 	raw: true,
			// });

			const factoriesList = await comboMaster.findAll({
				where: {
					FIELDID: 15,
				},
				raw: true,
			});

			const consolidatedFactories = factoriesList.reduce((acc, curr) => {
				acc[(curr as any).VALUE] = (curr as any).LABEL;
				return acc;
			}, {});

			const procurement = await Procurement.findAll({
				raw: true,
				order: [['createdAt', 'desc']],
			});

			console.log('procurement', procurement);

			const statusData = await Polcsectionstatus.findAll({
				attributes: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				// where: {
				// 	PROCUREMENTID: ID,
				// },
				raw: true,
				group: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				order: [['SECTIONSEQUENCE', 'asc']],
			});

			const consolidatedData = statusData.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...acc[(curr as any).PROCUREMENTID],
					[(curr as any).SECTIONAME]: {
						STATUS: (curr as any).STATUS,
						SECTIONSEQUENCE: (curr as any).SECTIONSEQUENCE,
						SECTIONAME: (curr as any).SECTIONAME,
					},
					FORMID: (curr as any).FORMID,
				};
				return acc;
			}, {});

			// const statusData = await Polcsectionstatus.findAll({
			// 	attributes: ['FORMID', 'FORMMNO', 'SECTIONAME', 'STATUS'],
			// 	raw: true,
			// 	group: [
			// 		'FORMID',
			// 		'FORMMNO',
			// 		'SECTIONAME',
			// 		'STATUS',
			// 		'SECTIONSEQUENCE',
			// 	],
			// 	order: [['SECTIONSEQUENCE', 'asc']],
			// });

			// const consolidatedData = statusData.reduce((acc, curr) => {
			// 	acc[(curr as any).FORMMNO] = {
			// 		...acc[(curr as any).FORMMNO],
			// 		[(curr as any).SECTIONAME]: (curr as any).STATUS,
			// 		FORMID: (curr as any).FORMID,
			// 	};
			// 	return acc;
			// }, {});

			res.locals.data = {
				data: procurement.map((e) => {
					// console.log(Object.values(consolidatedData[(e as any).ID]));
					// const d = { ...consolidatedData[(e as any).PROCUREMENTID] };
					const d = (
						Object.values(consolidatedData[(e as any).ID] || {}) 
					).reduce((acc, curr) => {
						acc[(curr as any).SECTIONSEQUENCE - 1] = {
							NAME: (curr as any).SECTIONAME,
							STATUS: (curr as any).STATUS,
						};
						return acc;
					}, []);
					// console.log(
					// 	'consolidatedData',
					// 	consolidatedData,
					// 	(e as any).ID,
					// );
					const formId = consolidatedData[(e as any).ID]?.FORMID || 1;
					// delete d.FORMID;
					e["STAGES"] = d;
					e["FORMID"] = formId;
					// console.log(
					// 	'consolidatedFactories[(e as any).FACTORY];',
					// 	consolidatedFactories,
					// 	(e as any).FACTORY,
					// );
					e["FACTORYNAME"] =
						consolidatedFactories[(e as any).FACTORY];
					return e;
				}),
			};
			super.send(res);
			console.log('postPurchaseOrder API completed');
		} catch (err) {
			logger.error(
				`Error in postPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getFormMEntriesOil(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getFormMEntriesOil initalized');
			const { OUID = 1 } = req.query;
			// const PoData = await LCMain.findAll({
			// 	raw: true,
			// });

			const factoriesList = await comboMaster.findAll({
				where: {
					FIELDID: 15,
				},
				raw: true,
			});

			const consolidatedFactories = factoriesList.reduce((acc, curr) => {
				acc[(curr as any).VALUE] = (curr as any).LABEL;
				return acc;
			}, {});

			const procurement = await ProcurementOil.findAll({
				raw: true,
				order: [['createdAt', 'desc']],
			});

			const statusData = await PolcsectionstatusOil.findAll({
				attributes: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				// where: {
				// 	PROCUREMENTID: ID,
				// },
				raw: true,
				group: [
					'FORMID',
					'PROCUREMENTSEQUENCE',
					'SECTIONAME',
					'STATUS',
					'SECTIONSEQUENCE',
					'PROCUREMENTID',
				],
				order: [['SECTIONSEQUENCE', 'asc']],
			});

			const consolidatedData = statusData.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...acc[(curr as any).PROCUREMENTID],
					[(curr as any).SECTIONAME]: {
						STATUS: (curr as any).STATUS,
						SECTIONSEQUENCE: (curr as any).SECTIONSEQUENCE,
						SECTIONAME: (curr as any).SECTIONAME,
					},
					FORMID: (curr as any).FORMID,
				};
				return acc;
			}, {});

			// const statusData = await Polcsectionstatus.findAll({
			// 	attributes: ['FORMID', 'FORMMNO', 'SECTIONAME', 'STATUS'],
			// 	raw: true,
			// 	group: [
			// 		'FORMID',
			// 		'FORMMNO',
			// 		'SECTIONAME',
			// 		'STATUS',
			// 		'SECTIONSEQUENCE',
			// 	],
			// 	order: [['SECTIONSEQUENCE', 'asc']],
			// });

			// const consolidatedData = statusData.reduce((acc, curr) => {
			// 	acc[(curr as any).FORMMNO] = {
			// 		...acc[(curr as any).FORMMNO],
			// 		[(curr as any).SECTIONAME]: (curr as any).STATUS,
			// 		FORMID: (curr as any).FORMID,
			// 	};
			// 	return acc;
			// }, {});

			res.locals.data = {
				data: procurement.map((e) => {
					console.log(Object.values(consolidatedData[(e as any).ID]));
					// const d = { ...consolidatedData[(e as any).PROCUREMENTID] };
					const d = Object.values(
						consolidatedData[(e as any).ID],
					).reduce((acc, curr) => {
						acc[(curr as any).SECTIONSEQUENCE - 1] = {
							NAME: (curr as any).SECTIONAME,
							STATUS: (curr as any).STATUS,
						};
						return acc;
					}, []);
					console.log(
						'consolidatedData',
						consolidatedData,
						(e as any).ID,
					);
					const formId = consolidatedData[(e as any).ID]?.FORMID || 1;
					// delete d.FORMID;
					e["STAGES"] = d;
					e["FORMID"] = formId;
					console.log(
						'consolidatedFactories[(e as any).FACTORY];',
						consolidatedFactories,
						(e as any).FACTORY,
					);
					e["FACTORYNAME"] =
						consolidatedFactories[(e as any).FACTORY];
					return e;
				}),
			};
			super.send(res);
			console.log('postPurchaseOrder API completed');
		} catch (err) {
			logger.error(
				`Error in postPurchaseOrder : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public static async updatePurchaseOrderInfo(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { OUID = 1 } = req.query;
			const { data } = req.body;
			const { ID } = data;
			delete data.ID;
			const poData = await LCMain.update(
				{
					...data,
				},
				{
					where: {
						ID,
					},
				},
			);

			//
			const items = data.ITEMDETAILS;
			if (items && items.length) {
				for (const item of items) {
					const [record, created] = await Pfiitems.findOrCreate({
						where: {
							ID: item?.ID || 0,
						},
						defaults: {
							...item,
						},
					});

					// // console.log(JSON.parse(JSON.stringify(record)), created);
					if (!created) {
						const updt = await Pfiitems.update(
							{
								...item,
							},
							{
								where: {
									ID: item?.ID || 0,
								},
							},
						);
					}
				}
			}

			return poData;
		} catch (error) {
			logger.error(
				`Error in postPurchaseOrder : ${error.message}\n${error.stack}`,
			);
			throw new ApiError(error.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * @param req
	 * @param res
	 * @param next
	 */
	public static async getPurchaseOrderKPI(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { OUID = 1 } = req.query;
			const { data } = req.body;
			const { ID } = data;
			delete data.ID;
			const poData = await LCMain.update(
				{
					...data,
				},
				{
					where: {
						ID,
					},
				},
			);

			//
			const items = data.ITEMDETAILS;
			if (items && items.length) {
				for (const item of items) {
					const [record, created] = await Pfiitems.findOrCreate({
						where: {
							ID: item?.ID || 0,
						},
						defaults: {
							...item,
						},
					});

					// // console.log(JSON.parse(JSON.stringify(record)), created);
					if (!created) {
						const updt = await Pfiitems.update(
							{
								...item,
							},
							{
								where: {
									ID: item?.ID || 0,
								},
							},
						);
					}
				}
			}

			return poData;
		} catch (error) {
			logger.error(
				`Error in postPurchaseOrder : ${error.message}\n${error.stack}`,
			);
			throw new ApiError(error.message, StatusCodes.BAD_REQUEST, res);
		}
	}
}
