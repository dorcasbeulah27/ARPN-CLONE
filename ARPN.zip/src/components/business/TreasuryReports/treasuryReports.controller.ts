import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import { Op, Sequelize } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import Forex from '../../../database/models/business/Forex/forex';
import BankAccount from '../../../database/models/business/bankMaster/bankAccount';
import BankMaster from '../../../database/models/business/bankMaster/bankMaster';
import LCComissionMaster from '../../../database/models/business/bankMaster/lcComissionMaster';
import PostNegMaster from '../../../database/models/business/bankMaster/postNegMaster';
import PreNegMaster from '../../../database/models/business/bankMaster/preNegMaster';
import iffPayable from '../../../database/models/business/iffPayable/iffPayable';
import LiquidationTreasuryInfo from '../../../database/models/business/liquidationTreasury/liquidationTreasuryInfo';
import Pfiitems from '../../../database/models/business/procurement/pfiItems';
import Procurement from '../../../database/models/business/procurement/procurement';
import Shipment from '../../../database/models/business/shipment/shipment';
import Tradefinance from '../../../database/models/business/tradeFinance/tradeFinance';
import LC from '../../../database/models/business/ttlc/lc';
import logger from '../../../lib/logger';
import dateFormatter from '../../../utils/dateFormatter';
import BaseApi from '../../BaseApi';
import comboFormatter from '../../../utils/comboFormatter';
import { getDateDifferenceInDays } from '../../../utils/dateCalculations';
import comboMaster from '../../../database/models/masters/comboMaster';
import { currencyConsolidator } from '../../../utils/currencyFormatter';

const moment = require('moment');
/**
 * BankMaster Controller
 */
export default class TreasuryReportController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 * Register API routes
	 */
	public register(): Router {
		this.router.get('/getIFFPayable', this.getIFFPayable.bind(this));
		this.router.post('/postIFFPayable', this.postIFFPayable.bind(this));

		return this.router;
	}

	/**
	 * Get BankMaster details
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getIFFPayable(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			console.log('getIFFPayable initialized');
			const { OUID = 1, BANKNAMES, DATE = new Date() } = req.query;

			const distinctCurrencies = {};

			const forexData = await Forex.findAll({
				where: {
					// SOURCECURRENCY: {
					// 	[Op.in]: [
					// 		...prData.map(
					// 			(element) => (element as any).CURRENCY,
					// 		),
					// 		'NGN',
					// 		'USD',
					// 	],
					// },
					TARGETCURRENCY: {
						[Op.in]: ['USD', 'NGN'],
					},
				},
				order: [['VALIDITYSTARTDATE', 'ASC']],
				raw: true,
			});

			const consolidatedForexData = forexData.reduce((acc, curr) => {
				if (
					acc[
						`${(curr as any).SOURCECURRENCY}-${
							(curr as any).TARGETCURRENCY
						}`
					]
				) {
					acc[
						`${(curr as any).SOURCECURRENCY}-${
							(curr as any).TARGETCURRENCY
						}`
					].push(curr);
				} else {
					acc[
						`${(curr as any).SOURCECURRENCY}-${
							(curr as any).TARGETCURRENCY
						}`
					] = [curr];
				}
				return acc;
			}, {});

			const newConsolidatedForexData = {};
			Object.keys(consolidatedForexData).map((element) => {
				newConsolidatedForexData[element] = currencyConsolidator(
					consolidatedForexData[element] || [],
				);
			});

			const shipmentData = await Shipment.findAll({
				where: {
					// ID: 1,
					COMMERCIALINVOICEDATE: {
						[Op.lt]: DATE,
					},
				},
				include: [
					{
						model: Procurement,
						attributes: ['ID'],
						where: {
							PFIMODEOFPAYMENT: 'LC',
						},
						as: 'PROCUREMENTINFO',
					},
				],
				raw: true,
			});

			const liquidationData = await LiquidationTreasuryInfo.findAll({
				where: {
					SELECTEDDATE: {
						[Op.lt]: DATE,
					},
				},
				raw: true,
				order: [['SELECTEDDATE', 'ASC']],
			});

			const consolidatedData = liquidationData.reduce((acc, curr) => {
				if (acc[(curr as any).PROCUREMENTID]) {
					acc[(curr as any).PROCUREMENTID].push(curr);
				} else {
					acc[(curr as any).PROCUREMENTID] = [curr];
				}
				return acc;
			}, {});

			const data = shipmentData.map((e) => {
				let remainingAmount = parseFloat(
					(e as any).COMMERCIALINVOICEAMOUNT,
				);
				let differnceDays = getDateDifferenceInDays(
					new Date(),
					(e as any).COMMERCIALINVOICEDATE,
				);
				const liqData = (
					consolidatedData[(e as any).PROCUREMENTID] || []
				).map((element, index) => {
					element.difference = getDateDifferenceInDays(
						new Date(DATE as any),
						(e as any).COMMERCIALINVOICEDATE,
					);
					differnceDays = getDateDifferenceInDays(
						new Date(DATE as any),
						(e as any).COMMERCIALINVOICEDATE,
					);
					element.amount =
						remainingAmount -
						parseFloat(element.LIQUIDATIONAMOUNT1);
					remainingAmount -= parseFloat(element.LIQUIDATIONAMOUNT1);
					return element;
				});
				e['liquidationDetails'] = liqData;
				e['remainingAmount'] = remainingAmount;
				e['differnceDays '] = differnceDays;
				return e;
			});

			const filteredData = data.filter(
				(e) => (e as any).remainingAmount > 0,
			);

			const factoriesList = await comboMaster.findAll({
				where: {
					FIELDID: 15,
				},
				raw: true,
			});

			const consolidatedFactories = factoriesList.reduce((acc, curr) => {
				acc[(curr as any).VALUE] = (curr as any).LABEL;
				return acc;
			}, {});

			const prData = await Procurement.findAll({
				attributes: ['FACTORY', 'ID', 'CURRENCY'],
				where: {
					ID: {
						[Op.in]: filteredData.map(
							(e) => (e as any).PROCUREMENTID,
						),
					},
				},
				raw: true,
			});

			const consolidatedProcurements = prData.reduce((acc, curr) => {
				acc[(curr as any).ID] = {
					...curr,
					FACTORYNAME: consolidatedFactories[(curr as any).FACTORY],
				};
				return acc;
			}, {});

			const lcData = await LC.findAll({
				attributes: ['LCNUMBER', 'PROCUREMENTID'],
				where: {
					PROCUREMENTID: {
						[Op.in]: filteredData.map(
							(e) => (e as any).PROCUREMENTID,
						),
					},
				},
				raw: true,
			});

			const consolidatedLCs = lcData.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...curr,
				};
				return acc;
			}, {});
			// console.log('lcData', consolidatedLCs);

			const formM = await Tradefinance.findAll({
				attributes: ['FORMMNO', 'PROCUREMENTID'],
				where: {
					PROCUREMENTID: {
						[Op.in]: filteredData.map(
							(e) => (e as any).PROCUREMENTID,
						),
					},
				},
				raw: true,
			});

			const consolidatedFormMs = formM.reduce((acc, curr) => {
				acc[(curr as any).PROCUREMENTID] = {
					...curr,
				};
				return acc;
			}, {});

			const pfiItems = await Pfiitems.findAll({
				where: {
					PROCUREMENTID: {
						[Op.in]: filteredData.map(
							(e) => (e as any).PROCUREMENTID,
						),
					},
				},
				raw: true,
			});

			const consolidatedPfiItems = pfiItems.reduce((acc, curr) => {
				if (acc[(curr as any).PROCUREMENTID]) {
					acc[(curr as any).PROCUREMENTID] = `${
						acc[(curr as any).PROCUREMENTID]
					},${(curr as any).ITEMDESCRIPTION}`;
				} else {
					acc[(curr as any).PROCUREMENTID] = (
						curr as any
					).ITEMDESCRIPTION;
				}
				return acc;
			}, {});

			const x = filteredData.map((element) => {
				let format = {
					'<30 Days': 0,
					'31-60 Days': 0,
					'61-90 Days': 0,
					'91-120 Days': 0,
					'121-150 Days': 0,
					'151-180 Days': 0,
					'181-210 Days': 0,
					'211-240 Days': 0,
					'241-270 Days': 0,
					'271-300 Days': 0,
					'301-330 Days': 0,
					'330-365 Days': 0,
					'>365 Days': 0,
				};
				format['COMMERCIALINVOICENUMBER'] =
					element['COMMERCIALINVOICENUMBER'];
				format['COMMERCIALINVOICEDATE'] =
					element['COMMERCIALINVOICEDATE'];
				format['COMMERCIALINVOICEAMOUNT'] = parseFloat(
					element['COMMERCIALINVOICEAMOUNT'],
				);
				const proInfo = {
					...consolidatedProcurements[
						(element as any)?.PROCUREMENTID
					],
				};
				console.log(proInfo);
				format = {
					...format,
					...proInfo,
					...consolidatedLCs[(element as any)?.PROCUREMENTID],
					...consolidatedFormMs[(element as any)?.PROCUREMENTID],
					ITEMDESCRIPTION:
						consolidatedPfiItems[(element as any)?.PROCUREMENTID],
				};
				format['CLOSINGBALANCE'] = (element as any)?.remainingAmount;

				const ngnConversion =
					newConsolidatedForexData[`${(format as any).CURRENCY}-NGN`];

				const currencyNgnConversion =
					newConsolidatedForexData[`NGN-${(format as any).CURRENCY}`];

				const documentCurrencyNGN = (
					currencyNgnConversion?.length ? currencyNgnConversion : []
				).find(
					(range) =>
						element['COMMERCIALINVOICEDATE'] >= range.STARTDATE &&
						element['COMMERCIALINVOICEDATE'] < range.ENDDATE,
				);

				const documentNGNCurrency = (
					ngnConversion?.length ? ngnConversion : []
				).find(
					(range) =>
						element['COMMERCIALINVOICEDATE'] >= range.STARTDATE &&
						element['COMMERCIALINVOICEDATE'] < range.ENDDATE,
				);

				const usdConversion =
					newConsolidatedForexData[`${(format as any).CURRENCY}-USD`];

				const documentUSDCurrency = (
					usdConversion?.length ? usdConversion : []
				).find(
					(range) =>
						element['COMMERCIALINVOICEDATE'] >= range.STARTDATE &&
						element['COMMERCIALINVOICEDATE'] < range.ENDDATE,
				);

				const ngnUsdConversion = newConsolidatedForexData['NGN-USD'];

				const ngnUSDCurrency = (
					ngnUsdConversion?.length ? ngnUsdConversion : []
				).find(
					(range) =>
						element['COMMERCIALINVOICEDATE'] >= range.STARTDATE &&
						element['COMMERCIALINVOICEDATE'] < range.ENDDATE,
				);
				// FOREX CONVERSION STARTS
				format['NIGERIANCONVERSION'] =
					(element as any)?.remainingAmount *
					((format as any).CURRENCY == 'NGN'
						? 1
						: documentNGNCurrency
						? documentNGNCurrency?.EXCHANGERATE
						: 1);
				format['USDCONVERSION'] =
					(element as any)?.remainingAmount *
					((element as any).CURRENCY == 'USD'
						? 1
						: documentUSDCurrency
						? documentUSDCurrency?.EXCHANGERATE
						: 1);
				format['NGNUSD'] = ngnUSDCurrency?.EXCHANGERATE;
				format['NGNTOCURRENCY'] = documentCurrencyNGN?.EXCHANGERATE;
				format['CURRENCYTONGN'] = documentNGNCurrency?.EXCHANGERATE;
				// format["currencyNgnConversion"] = currencyNgnConversion
				// format["documentNGNCurrency"] = documentNGNCurrency

				// FOREX CONVERSION ENDS
				distinctCurrencies[proInfo.CURRENCY] = proInfo.CURRENCY;
				(element as any).liquidationDetails.map((e) => {
					format['BANKNAME'] = e.BANKNAME;
					// format['CURRENCY'] = e['CURRENCY'];
					if (e.difference < 30) {
						format['<30 Days'] = e.amount;
					} else if (e.difference <= 60) {
						format['31-60 Days'] = e.amount;
					} else if (e.difference <= 90) {
						format['61-90 Days'] = e.amount;
					} else if (e.difference <= 120) {
						format['91-120 Days'] = e.amount;
					} else if (e.difference <= 150) {
						format['121-150 Days'] = e.amount;
					} else if (e.difference <= 180) {
						format['151-180 Days'] = e.amount;
					} else if (e.difference <= 210) {
						format['181-210 Days'] = e.amount;
					} else if (e.difference <= 240) {
						format['211-240 Days'] = e.amount;
					} else if (e.difference <= 270) {
						format['241-270 Days'] = e.amount;
					} else if (e.difference <= 300) {
						format['271-300 Days'] = e.amount;
					} else if (e.difference <= 330) {
						format['301-330 Days'] = e.amount;
					} else if (e.difference <= 365) {
						format['330-365 Days'] = e.amount;
					} else {
						format['>365 Days'] = e.amount;
					}
				});
				return format;
			});

			const sumValue = x.reduce(
				(acc, curr) => {
					acc['<30 Days'] += curr['<30 Days'];
					acc['31-60 Days'] += curr['31-60 Days'];
					acc['61-90 Days'] += curr['61-90 Days'];
					acc['91-120 Days'] += curr['91-120 Days'];
					acc['121-150 Days'] += curr['121-150 Days'];
					acc['151-180 Days'] += curr['151-180 Days'];
					acc['181-210 Days'] += curr['181-210 Days'];
					acc['211-240 Days'] += curr['211-240 Days'];
					acc['241-270 Days'] += curr['241-270 Days'];
					acc['271-300 Days'] += curr['271-300 Days'];
					acc['301-330 Days'] += curr['301-330 Days'];
					acc['330-365 Days'] += curr['330-365 Days'];
					acc['>365 Days'] += curr['>365 Days'];
					acc['NIGERIANCONVERSION'] += curr['NIGERIANCONVERSION'];
					acc['USDCONVERSION'] += curr['USDCONVERSION'];
					acc['COMMERCIALINVOICEAMOUNT'] +=
						curr['COMMERCIALINVOICEAMOUNT'];
					acc['CLOSINGBALANCE'] += curr['CLOSINGBALANCE'];
					acc.ID = 0;
					acc.BANKNAME = 'TOTAL';
					return acc;
				},
				{
					'<30 Days': 0,
					'31-60 Days': 0,
					'61-90 Days': 0,
					'91-120 Days': 0,
					'121-150 Days': 0,
					'151-180 Days': 0,
					'181-210 Days': 0,
					'211-240 Days': 0,
					'241-270 Days': 0,
					'271-300 Days': 0,
					'301-330 Days': 0,
					'330-365 Days': 0,
					'>365 Days': 0,
					COMMERCIALINVOICENUMBER: '',
					COMMERCIALINVOICEDATE: '',
					COMMERCIALINVOICEAMOUNT: 44600,
					FACTORY: '',
					ID: 0,
					CURRENCY: '',
					LCNUMBER: '',
					PROCUREMENTID: 0,
					FORMMNO: null,
					ITEMDESCRIPTION: '',
					CLOSINGBALANCE: 0,
					NIGERIANCONVERSION: 0,
					USDCONVERSION: 0,
					NGNUSD: 0,
				} as any,
			);
			res.locals.data = [...x, sumValue];
			super.send(res);
			console.log('getIFFPayable API completed');
		} catch (err) {
			logger.error(`Error in getBankList : ${err.message}\n${err.stack}`);
			throw new ApiError(err.message, StatusCodes.BAD_REQUEST, res);
		}
	}

	/**
	 * Get BankMaster details
	 * @param req
	 * @param res
	 * @param next
	 */
	public async postIFFPayable(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { DATA, MONTH } = req.body;

			const dataFetch = await iffPayable.findAll({
				where: {
					MONTH,
				},
				raw: true,
			});

			if (dataFetch.length) {
				logger.error(`Data already submitted for month - ${MONTH}`);
				throw new ApiError(
					`Data already submitted for month - ${MONTH}`,
					StatusCodes.BAD_REQUEST,
					res,
				);
			} else {
				const dataConversion = {
					'<30 Days': 'LESSTHAN30DAYS',
					'31-60 Days': 'DAYS31TO60',
					'61-90 Days': 'DAYS61TO90',
					'91-120 Days': 'DAYS91TO120',
					'121-150 Days': 'DAYS121TO150',
					'151-180 Days': 'DAYS151TO180',
					'181-210 Days': 'DAYS181TO210',
					'211-240 Days': 'DAYS211TO240',
					'241-270 Days': 'DAYS241TO270',
					'271-300 Days': 'DAYS271TO300',
					'301-330 Days': 'DAYS301TO330',
					'330-365 Days': 'DAYS330TO365',
					'>365 Days': 'MORETHAN365DAYS',
					COMMERCIALINVOICENUMBER: 'COMMERCIALINVOICENUMBER',
					COMMERCIALINVOICEDATE: 'COMMERCIALINVOICEDATE',
					COMMERCIALINVOICEAMOUNT: 'COMMERCIALINVOICEAMOUNT',
					FACTORY: 'FACTORY',
					CURRENCY: 'CURRENCY',
					LCNUMBER: 'LCNUMBER',
					PROCUREMENTID: 'PROCUREMENTID',
					FORMMNO: 'FORMMNO',
					ITEMDESCRIPTION: 'ITEMDESCRIPTION',
					CLOSINGBALANCE: 'CLOSINGBALANCE',
					NIGERIANCONVERSION: 'NIGERIANCONVERSION',
					USDCONVERSION: 'USDCONVERSION',
					NGNUSD: 'NGNUSD',
					BANKNAME: 'TOTAL',
				};

				let hh = DATA.map((el) => {
					const newData = {};
					newData['MONTH'] = MONTH;
					Object.keys(dataConversion).map((element) => {
						newData[dataConversion[element]] = el[element];
					});
					return newData;
				});

				console.log('newData', hh);
				await iffPayable.bulkCreate(hh);
				res.locals.data = {
					message: 'Data Submitted successfully',
				};
				super.send(res);
			}
		} catch (error) {
			logger.error(
				`Error while submitting IFF Payable Data Simulatoin: ${error}`,
			);
			throw new ApiError(
				`Error while submitting IFF Payable Data Simulatoin: ${error}`,
				StatusCodes.BAD_REQUEST,
				error,
			);
		}
	}
}
