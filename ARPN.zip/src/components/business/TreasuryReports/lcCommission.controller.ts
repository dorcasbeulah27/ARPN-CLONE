import { NextFunction, Request, Response, Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import ApiError from '../../../abstractions/ApiError';
import BankMaster from '../../../database/models/business/bankMaster/bankMaster';
import LCComissionMaster from '../../../database/models/business/bankMaster/lcComissionMaster';
import PostNegMaster from '../../../database/models/business/bankMaster/postNegMaster';
import PreNegMaster from '../../../database/models/business/bankMaster/preNegMaster';
import logger from '../../../lib/logger';
import dateFormatter from '../../../utils/dateFormatter';
import BaseApi from '../../BaseApi';
import BankAccount from '../../../database/models/business/bankMaster/bankAccount';
import { Op, Sequelize } from 'sequelize';
import comboFormatter from '../../../utils/comboFormatter';
import Shipment from '../../../database/models/business/shipment/shipment';
import LiquidationTreasuryInfo from '../../../database/models/business/liquidationTreasury/liquidationTreasuryInfo';
import { getDateDifferenceInDays } from '../../../utils/dateCalculations';
import Procurement from '../../../database/models/business/procurement/procurement';
import LC from '../../../database/models/business/ttlc/lc';
import Tradefinance from '../../../database/models/business/tradeFinance/tradeFinance';
import Pfiitems from '../../../database/models/business/procurement/pfiItems';
import comboMaster from '../../../database/models/masters/comboMaster';
import Forex from '../../../database/models/business/Forex/forex';
import iffPayable from '../../../database/models/business/iffPayable/iffPayable';
import { currencyConsolidator } from '../../../utils/currencyFormatter';
import LcCommissionReports from '../../../database/models/business/lcCommission/lcCommission'
import transaction from 'sequelize/types/transaction';
import Database from '../../../database';

/**
 * LCCOMM Controller
 */
export default class LcCommissionController extends BaseApi {
    constructor() {
        super();
    }

    /**
     * Register API routes
     */
    public register(): Router {
        this.router.get('/getLcCommissionReport', this.getLcCommissionReport.bind(this));
        this.router.post('/postActualLcCommission', this.actualLcCommission.bind(this));
        this.router.get('/getAllActualLcData', this.getAllActualLcData.bind(this));

        return this.router;
    }

    public async getLcCommissionReport(req: Request, res: Response, next: NextFunction) {
        try {
            const transaction = await Database.getConnection().transaction();
            const { TYPE } = req.query
            const lcDt: any = await LC.findAll({
                where: {
                    LCDATE: { [Op.not]: null }
                },
                attributes: ['PROCUREMENTID', 'BANK', 'LCDATE', 'LCNUMBER', 'LCAMOUNT', 'LCAMOUNTWITHTOLERANCE'],
                raw: true
            });
            console.log('lcDt: ', lcDt);

            const bankDt: any = await BankMaster.findAll({
                attributes: ['BANKNAME', 'LCCOMMISSION', 'LCCOMMISSIONINCLUDINGVAT'],
                raw: true
            });

            const procDt: any = await Procurement.findAll({
                attributes: ['CURRENCY', 'ID'],
                where: {
                    ID: lcDt.map((e) => e.PROCUREMENTID)
                },
                raw: true
            })

            const bankDataArray: any = bankDt.map((bank: any) => ({
                BANKNAME: (bank.BANKNAME).toLowerCase(),
                LCCOMMISSION: parseFloat(bank.LCCOMMISSION),
                LCCOMMISSIONINCLUDINGVAT: parseFloat(bank.LCCOMMISSIONINCLUDINGVAT),
            }));

            let consolidatedBanks = bankDataArray.reduce((acc, curr) => {
                acc[curr.BANKNAME] = curr;
                return acc;
            }, {});

            let lcComm
            let commissioninDollar;
            const matchedBank = lcDt.map((item: any) => {
                let lowerConv = item.BANK ? item.BANK.toLowerCase() : null;
                let bank = lowerConv ? consolidatedBanks[lowerConv] : null;
                if (!bank) {
                    return { bank: bank, lcComm: 0.00 }
                } else {
                    const calculateLcCommission = parseFloat(item.LCAMOUNTWITHTOLERANCE) * bank.LCCOMMISSIONINCLUDINGVAT;
                    console.log('calculateLcCommission: ', calculateLcCommission);
                    return { bank: bank, lcComm: calculateLcCommission };
                }
            })
            if (matchedBank.length > 0) {
                lcComm = matchedBank.map(item => item?.lcComm);
            }

            // commissioninDollar = lcComm.map(item => item?.lcComm);
            const forexData = await Forex.findAll({
                where: {
                    SOURCECURRENCY: {
                        [Op.in]: ['USD', 'NGN', 'EUR'],
                    },
                    TARGETCURRENCY: {
                        [Op.in]: ['USD', 'NGN', 'EUR'],
                    },
                },
                order: [['VALIDITYSTARTDATE', 'ASC']],
                raw: true,
            });

            const consolidatedForexData = forexData.reduce((acc, curr) => {
                if (
                    acc[
                    `${(curr as any).SOURCECURRENCY}-${(curr as any).TARGETCURRENCY
                    }`
                    ]
                ) {
                    acc[
                        `${(curr as any).SOURCECURRENCY}-${(curr as any).TARGETCURRENCY
                        }`
                    ].push(curr);
                } else {
                    acc[
                        `${(curr as any).SOURCECURRENCY}-${(curr as any).TARGETCURRENCY
                        }`
                    ] = [curr];
                }
                return acc;
            }, {});

            const newConsolidatedForexData = {};
            Object.keys(consolidatedForexData).forEach((element) => {
                newConsolidatedForexData[element] = currencyConsolidator(
                    consolidatedForexData[element] || [],
                );
            });
            const finalReport = []
            const finalCommResults = await Promise.all(lcDt.map(async (lcItem, index) => {
                const lcDate = new Date(lcItem.LCDATE);
                const currency = procDt.find(proc => proc.ID === lcItem.PROCUREMENTID)?.CURRENCY;
                const ngnConversion = newConsolidatedForexData[`${currency}-NGN`];
                console.log('newConsolidatedForexData[`${currency}-NGN`]: ', `${currency}`);

                const documentNGNCurrency = (ngnConversion?.length ? ngnConversion : []).find(
                    (range) =>
                        new Date(range.STARTDATE) <= lcDate &&
                        lcDate < new Date(range.ENDDATE),
                );
                console.log('documentNGNCurrency: ', documentNGNCurrency);

                const exchangeRate = documentNGNCurrency ? parseFloat(documentNGNCurrency.EXCHANGERATE) : 1;
                const commission = lcComm[index] !== 'Unknown Bank' ? lcComm[index] * exchangeRate : 'Unknown Bank';
                console.log('lcComm[index] * exchangeRat: ', lcComm[index]);

                
                return {
                    lcItem,
                    commission,
                    currency,
                };
            }));
            finalReport.push(finalCommResults)

            // const report = finalReport.map(item => ({
            //     lcItem: item.lcItem,
            //     commission: item.commission,
            //     currency: item.currency,
            //     lcComm: item.currency
            // }))

        
            res.locals.data = { data: finalCommResults };

            super.send(res);
        } catch (error) {
            throw new ApiError(
                `Error while saving estimated lc calculation: ${error}`,
                StatusCodes.BAD_REQUEST,
                error,
            );
        }
    }

    public async actualLcCommission(req: Request, res: Response, next: NextFunction) {
        const transaction = await Database.getConnection().transaction();
        try {
            const { data } = req.body;
            console.log('data: ', data);

            const modifiedData = data.map(item => {
                if (item.LCVALUE && item.LCCOMMISSIONWITHVAT && item.EXCHANGERATE) {
                    const LCCOMMISSIONINDOLLAR = item.LCVALUE * item.LCCOMMISSIONWITHVAT;
                    const LCCOMMISSIONINNAIRA = LCCOMMISSIONINDOLLAR * item.EXCHANGERATE;
                    return { ...item, LCCOMMISSIONINDOLLAR, LCCOMMISSIONINNAIRA };
                } else {
                    throw new Error('Missing required fields: LCAMOUNT, LCCOMMISSIONWITHVAT, or EXCHANGERATE');
                }
            });

            const lcCommData = await LcCommissionReports.bulkCreate(modifiedData, { transaction });
            console.log('lcCommData: ', lcCommData);

            await transaction.commit();
            res.locals.data = { data: lcCommData };
            super.send(res);
        } catch (error) {
            if (transaction) await transaction.rollback();
            console.error('Error while updating actual lc commission:', error);
            res.status(StatusCodes.BAD_REQUEST).json({ error: `Error while updating actual lc commission: ${error.message}` });
        }
    }

    public async getAllActualLcData(req: Request, res: Response, next: NextFunction) {
        const transaction = await Database.getConnection().transaction();
        try {
            const getAllActual = await LcCommissionReports.findAll({
                where: {
                    LCNUMBER: { [Op.not]: null },
                },

                raw: true
            })

            await transaction.commit();
            res.locals.data = { data: getAllActual }
            super.send(res)
        } catch (error) {
           await transaction.rollback();
            console.error('Error while updating actual lc commission:', error);
            res.status(StatusCodes.BAD_REQUEST).json({ error: `Error while updating actual lc commission: ${error.message}` });
        }
    }

}