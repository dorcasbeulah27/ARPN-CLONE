import { NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';

import BaseApi from '../../BaseApi';
import ApiError from '../../../abstractions/ApiError';
import logger from '../../../lib/logger';
import workplan_Emp_Contractor from '../../../database/models/business/WorkPlan/workPlanMapToConEmp';

/**
 * User Management controller
 */
export default class EmpContWorkPlan extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.post(
			'/defaultWorkplanCndE',
			this.defaultWorkPlanContEmp.bind(this),
		);

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	public async getAllUsers(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllUsers api has been invoked');
			const users = await workplan_Emp_Contractor.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	async defaultWorkPlanContEmp(req: Request, res: Response) {
		try {
			await workplan_Emp_Contractor.bulkCreate([
				{ WORKPLAN_ID: 1, EMP_ID: 3, CONTRACTOR_ID: 1 },
				{ WORKPLAN_ID: 1, EMP_ID: 4, CONTRACTOR_ID: 1 },
				{ WORKPLAN_ID: 2, EMP_ID: 1, CONTRACTOR_ID: 1 },
				{ WORKPLAN_ID: 3, EMP_ID: 2, CONTRACTOR_ID: 1 },
				{ WORKPLAN_ID: 4, EMP_ID: 5, CONTRACTOR_ID: 1 },
			]);
			// Seed UsersWorkplan

			res.status(200).json({ message: 'Courses inserted successfully' });
		} catch (error) {
			console.error('Error inserting Courses:', error);
			res.status(500).json({
				message: 'Failed to insert courses',
				error,
			});
		}
	}
}
