import { NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';

import BaseApi from '../../BaseApi';
import ApiError from '../../../abstractions/ApiError';
import logger from '../../../lib/logger';
import Users from '../../../database/models/business/Users/Users';

/**
 * User Management controller
 */
export default class UserController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/getAllUsers', this.getAllUsers.bind(this));
		this.router.post('/defaultUsers', this.defaultUsers.bind(this));

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	public async getAllUsers(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllUsers api has been invoked');
			const users = await Users.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	async defaultUsers(req: Request, res: Response) {
		try {
			await Users.bulkCreate([
				{ NAME: 'Beulah' },
				{ NAME: 'Jency' },
				{ NAME: 'Sneha' },
				{ NAME: 'Tisha' },
				{ NAME: 'Thani' },
			]);

			// Seed UsersWorkplan

			res.status(200).json({ message: 'Courses inserted successfully' });
		} catch (error) {
			console.error('Error inserting Courses:', error);
			res.status(500).json({
				message: 'Failed to insert courses',
				error,
			});
		}
	}
}
