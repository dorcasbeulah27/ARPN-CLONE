import { NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';

import BaseApi from '../../BaseApi';
import ApiError from '../../../abstractions/ApiError';
import logger from '../../../lib/logger';
import Contractor from '../../../database/models/business/Contractors/contractors';

/**
 * User Management controller
 */
export default class ContractorController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.post(
			'/defaultContractors',
			this.defaultContractors.bind(this),
		);

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	public async getAllUsers(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllUsers api has been invoked');
			const users = await Contractor.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	async defaultContractors(req: Request, res: Response) {
		try {
			await Contractor.bulkCreate([
				{ NAME: 'Sathesh', TOTALEMPLOYEES: 5, AVAILEMPLOYEES: 4 },
				{ NAME: 'Dhanush', TOTALEMPLOYEES: 4, AVAILEMPLOYEES: 3 },
				{ NAME: 'Neha', TOTALEMPLOYEES: 4, AVAILEMPLOYEES: 2 },
				{ NAME: 'Taufic', TOTALEMPLOYEES: 3, AVAILEMPLOYEES: 2 },
				{ NAME: 'Gobiha', TOTALEMPLOYEES: 2, AVAILEMPLOYEES: 3 },
			]);

			// Seed UsersWorkplan

			res.status(200).json({ message: 'Courses inserted successfully' });
		} catch (error) {
			console.error('Error inserting Courses:', error);
			res.status(500).json({
				message: 'Failed to insert courses',
				error,
			});
		}
	}
}
