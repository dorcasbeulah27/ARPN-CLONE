import { NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';

import BaseApi from '../../BaseApi';
import ApiError from '../../../abstractions/ApiError';
import logger from '../../../lib/logger';
import UsersWorkPlan from '../../../database/models/business/WorkPlan/workPlanMapToUsers';
import workplan_Emp_Contractor from '../../../database/models/business/WorkPlan/workPlanMapToConEmp';
import Users from '../../../database/models/business/Users/Users';
import Employee from '../../../database/models/business/Employees/employees';
import Contractor from '../../../database/models/business/Contractors/contractors';
import { col, Sequelize, where } from 'sequelize';

/**
 * User Management controller
 */
export default class UsersWorkplan extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.post('/defaultWorkplan', this.defaultWorkplan.bind(this));
		this.router.post('/startWork', this.assignWorkPlan.bind(this));

		// this.router.put('/startDate', this.startDate.bind(this));

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	public async getAllUsers(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllUsers api has been invoked');
			const users = await UsersWorkPlan.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	public;
	async assignWorkPlan(req: Request, res: Response) {
		try {
			const { JOBNAME, EMP_NAME, CONTRACTOR_NAME } = req.query;
			if (!JOBNAME || !EMP_NAME || !CONTRACTOR_NAME) {
				throw new ApiError(
					ReasonPhrases.BAD_REQUEST,
					StatusCodes.BAD_REQUEST,
					res,
					'Missing required fields. Please provide JOBNAME, EMP_NAME, and CONTRACTOR_NAME.',
				);
			}
			const job = await UsersWorkPlan.findOne({
				where: { JOBNAME: JOBNAME },
				attributes: ['ID'],
			});
			if (!job) {
				throw new ApiError(
					ReasonPhrases.NOT_FOUND,
					StatusCodes.NOT_FOUND,
					res,
					`JOB with name ${JOBNAME} not found.`,
				);
			}
			const emp = await Employee.findOne({
				where: { NAME: EMP_NAME },
				attributes: ['ID'],
			});
			if (!emp) {
				throw new ApiError(
					ReasonPhrases.NOT_FOUND,
					StatusCodes.NOT_FOUND,
					res,
					`Employee with name ${EMP_NAME} not found.`,
				);
			}
			const contractor = await Contractor.findOne({
				where: { NAME: CONTRACTOR_NAME },
				attributes: ['ID'],
			});
			if (!contractor) {
				throw new ApiError(
					ReasonPhrases.NOT_FOUND,
					StatusCodes.NOT_FOUND,
					res,
					`Contractor with name ${CONTRACTOR_NAME} not found.`,
				);
			}

			const job_id = job.dataValues.ID;
			const emp_id = emp.dataValues.ID;
			const contractor_id = contractor.dataValues.ID;

			if (contractor.dataValues.AVAILEMPLOYEES <= 0) {
				throw new ApiError(
					ReasonPhrases.BAD_REQUEST,
					StatusCodes.BAD_REQUEST,
					res,
					`No employees available for contractor ${CONTRACTOR_NAME}.`,
				);
			}

			if (emp.dataValues.STATUS !== 'AVAILABLE') {
				throw new ApiError(
					ReasonPhrases.BAD_REQUEST,
					StatusCodes.BAD_REQUEST,
					res,
					`Employee ${EMP_NAME} is not available for assignment.`,
				);
			}

			if (job.dataValues.STATUS === 'ACTIVE') {
				throw new ApiError(
					ReasonPhrases.CONFLICT,
					StatusCodes.CONFLICT,
					res,
					`Job ${JOBNAME} is already active and cannot be reassigned.`,
				);
			}

			console.log(job_id);
			console.log(emp_id);
			console.log(contractor_id);

			const newWorkPlan = await UsersWorkPlan.update(
				{
					STARTDATE: new Date(),
					STATUS: 'ACTIVE',
				},
				{ where: { ID: job_id } },
			);
			console.log(newWorkPlan);
			const workplanEC = await workplan_Emp_Contractor.create({
				WORKPLAN_ID: job_id,
				EMP_ID: emp_id,
				CONTRACTOR_ID: contractor_id,
			});
			console.log(workplanEC);

			const empStatusUpdate = await Employee.update(
				{ STATUS: 'UNAVAILABLE' },
				{ where: { ID: emp_id } },
			);
			const updateAvailability = await contractor.update(
				{
					AVAILEMPLOYEES: Sequelize.literal('"AVAILEMPLOYEES" - 1'),
				},
				{
					where: { ID: contractor_id },
				},
			);

			console.log(empStatusUpdate);
			console.log(updateAvailability);

			res.status(StatusCodes.OK).json({
				message: 'Workplan updated and assigned successfully',
			});
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in assigning WorkPlan: ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.INTERNAL_SERVER_ERROR,
				StatusCodes.INTERNAL_SERVER_ERROR,
				res,
				'Failed to update work plan.',
			);
		}
	}

	async defaultWorkplan(req: Request, res: Response) {
		try {
			await UsersWorkPlan.bulkCreate([
				{
					SUPERVISOR: 1,
					JOBNAME: 'Project Alpha',
					STARTDATE: null,
					ENDDATE: null,
					COSTOFWORK: 15000,
					STATUS: 'ACTIVE',
				},
				{
					SUPERVISOR: 2,
					JOBNAME: 'Renovation Task',
					STARTDATE: null,
					ENDDATE: null,
					COSTOFWORK: 5000,
					STATUS: 'INACTIVE',
				},
				{
					SUPERVISOR: 3,
					JOBNAME: 'Software Upgrade',
					STARTDATE: null,
					ENDDATE: null,
					COSTOFWORK: 20000,
					STATUS: 'ACTIVE',
				},
				{
					SUPERVISOR: 4,
					JOBNAME: 'Marketing Launch',
					STARTDATE: null,
					ENDDATE: null,
					COSTOFWORK: 8000,
					STATUS: 'INACTIVE',
				},
				{
					SUPERVISOR: 5,
					JOBNAME: 'New Office Setup',
					STARTDATE: null,
					ENDDATE: null,
					COSTOFWORK: 12000,
					STATUS: 'ACTIVE',
				},
			]);
			// Seed UsersWorkplan

			res.status(200).json({ message: 'Courses inserted successfully' });
		} catch (error) {
			console.error('Error inserting Courses:', error);
			res.status(500).json({
				message: 'Failed to insert courses',
				error,
			});
		}
	}
}
