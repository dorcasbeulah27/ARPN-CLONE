import { NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';

import BaseApi from '../../BaseApi';
import ApiError from '../../../abstractions/ApiError';
import logger from '../../../lib/logger';
import Employee from '../../../database/models/business/Employees/employees';

/**
 * User Management controller
 */
export default class EmployeeController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.post('/defaultEmployees', this.defaultEmployees.bind(this));

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	public async getAllUsers(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllUsers api has been invoked');
			const users = await Employee.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */

	async defaultEmployees(req: Request, res: Response) {
		try {
			await Employee.bulkCreate([
				{ NAME: 'sherlina', STATUS: 'AVAILABLE', CONTRACTORID: 1 },
				{ NAME: 'jyo', STATUS: 'AVAILABLE', CONTRACTORID: 1 },
				{ NAME: 'mercy', STATUS: 'AVAILABLE', CONTRACTORID: 1 },
				{ NAME: 'reji', STATUS: 'AVAILABLE', CONTRACTORID: 1 },
				{ NAME: 'joy', STATUS: 'AVAILABLE', CONTRACTORID: 1 },
				{ NAME: 'sre', STATUS: 'AVAILABLE', CONTRACTORID: 2 },
				{ NAME: 'trisha', STATUS: 'AVAILABLE', CONTRACTORID: 2 },
				{ NAME: 'imman', STATUS: 'AVAILABLE', CONTRACTORID: 2 },
				{ NAME: 'christo', STATUS: 'AVAILABLE', CONTRACTORID: 2 },
				{ NAME: 'hema', STATUS: 'AVAILABLE', CONTRACTORID: 3 },
				{ NAME: 'arul', STATUS: 'AVAILABLE', CONTRACTORID: 3 },
				{ NAME: 'angel', STATUS: 'AVAILABLE', CONTRACTORID: 3 },
				{ NAME: 'nancy', STATUS: 'AVAILABLE', CONTRACTORID: 3 },
				{ NAME: 'mani', STATUS: 'AVAILABLE', CONTRACTORID: 4 },
				{ NAME: 'felina', STATUS: 'AVAILABLE', CONTRACTORID: 4 },
				{ NAME: 'suriya', STATUS: 'AVAILABLE', CONTRACTORID: 4 },
				{ NAME: 'naveen', STATUS: 'AVAILABLE', CONTRACTORID: 5 },
				{ NAME: 'jordan', STATUS: 'AVAILABLE', CONTRACTORID: 5 },
			]);
			// Seed UsersWorkplan

			res.status(200).json({ message: 'Courses inserted successfully' });
		} catch (error) {
			console.error('Error inserting Courses:', error);
			res.status(500).json({
				message: 'Failed to insert courses',
				error,
			});
		}
	}
}
