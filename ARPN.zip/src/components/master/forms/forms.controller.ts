import { Application, NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import { Op, Sequelize } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import Database from '../../../database';
import comboMaster from '../../../database/models/masters/comboMaster';
import FormFieldsMaster from '../../../database/models/masters/formFieldsMaster';
import FormTableMapping from '../../../database/models/masters/formTableMapping';
import FormMaster from '../../../database/models/masters/formsMaster';
import GroupsMaster from '../../../database/models/masters/groupsMaster';
import ModuleMaster from '../../../database/models/masters/moduleMaster';
import SectionsMaster from '../../../database/models/masters/sectionsMaster';
import logger from '../../../lib/logger';
import BaseApi from '../../BaseApi';
import PurchaseOrderController from '../../business/PurchaseOrder/purchaseOrder.controller';

const { QueryTypes } = require('sequelize');

/**
 * Status controller
 */
export default class FormInfoController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/', this.getAllFields.bind(this));
		this.router.get('/getData', this.getDataForForms.bind(this));
		this.router.post('/postData', this.postDataForms.bind(this));

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getAllFields(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllModules api has been invoked');

			const { OUID, FORMID, ROLEID } = req.query;

			const formDetails = await FormMaster.findOne({
				where: {
					ID: FORMID,
					ACTIVE: true,
				},
				raw: true,
			});

			const sectionDetails = await SectionsMaster.findAll({
				where: {
					FORMID,
					ACTIVE: true,
				},
				raw: true,
				order: [['SECTIONSEQUENCE', 'ASC']],
			});

			const groupDetails = await GroupsMaster.findAll({
				where: {
					FORMID,
					ACTIVE: true,
				},
				raw: true,
				order: [['GROUPSEQUENCE', 'ASC']],
			});

			console.log('groupDetails', groupDetails);
			const fieldDetails = await FormFieldsMaster.findAll({
				where: {
					FORMID,
					ROLEID: ROLEID || 5,
					ACTIVE: true,
				},
				raw: true,
				order: [['FIELDSEQUENCE', 'ASC']],
			});

			const consolidatedCombos = fieldDetails.reduce(
				(acc: any, curr: any) => {
					if (curr.FIELDTYPE === 'COMBO') {
						acc.push(curr.ID);
					}
					return acc;
				},
				[],
			);

			const comboMasterData = await comboMaster.findAll({
				where: {
					FIELDID: {
						[Op.in]: consolidatedCombos,
					},
					ACTIVE: true,
				},
				attributes: [
					'FIELDID',
					[Sequelize.col('LABEL'), 'label'], // Aggregate LABEL column into an array
					[Sequelize.col('VALUE'), 'value'],
					'SEQUENCE',
				],
				// group: ['FIELDID'],
				order: [
					['FIELDID', 'ASC'],
					['SEQUENCE', 'ASC'],
				],
				raw: true,
			});

			const consolidatedCmbdata = comboMasterData.reduce((acc, curr) => {
				if (acc[(curr as any).FIELDID]) {
					acc[(curr as any).FIELDID].push(curr);
				} else {
					acc[(curr as any).FIELDID] = [curr];
				}
				return acc;
			}, {});

			const consolidatedSections = sectionDetails.reduce((acc, curr) => {
				acc[(curr as any).ID] = curr;
				return acc;
			}, {});

			const consolidatedGroup = groupDetails.reduce((acc, curr) => {
				acc[(curr as any).ID] = curr;
				return acc;
			}, {});

			const grpFieldDictionary = {};
			fieldDetails.map((element) => {
				const data = { ...element };
				// console.log((data as any));
				if ((element as any).FIELDTYPE === 'COMBO') {
					(data as any).VALUELISTS =
						consolidatedCmbdata[(element as any).ID];
				}
				if ((data as any).CONFIGCHILD) {
					if (
						consolidatedGroup[(data as any).GROUPID].CONFIGURATIONS
					) {
						if (
							consolidatedGroup[(data as any).GROUPID]
								.CONFIGURATIONS[(data as any).CONFIGPARENTNAME]
						) {
							if (
								consolidatedGroup[(data as any).GROUPID]
									.CONFIGURATIONS[
									(data as any).CONFIGPARENTNAME
								][(data as any).CONFIGVALUE]
							) {
								consolidatedGroup[
									(data as any).GROUPID
								].CONFIGURATIONS[
									(data as any).CONFIGPARENTNAME
								][(data as any).CONFIGVALUE].push(data);
							} else {
								consolidatedGroup[
									(data as any).GROUPID
								].CONFIGURATIONS[
									(data as any).CONFIGPARENTNAME
								][(data as any).CONFIGVALUE] = [data];
							}
						} else {
							consolidatedGroup[
								(data as any).GROUPID
							].CONFIGURATIONS[(data as any).CONFIGPARENTNAME] = {
								[(data as any).CONFIGVALUE]: [data],
							};
						}
					} else {
						consolidatedGroup[
							(data as any).GROUPID
						].CONFIGURATIONS = {
							[(data as any).CONFIGPARENTNAME]: {
								[(data as any).CONFIGVALUE]: [data],
							},
						};
					}
				}

				if (consolidatedGroup[(data as any)?.GROUPID]?.FIELDS) {
					if (!(data as any).CONFIGCHILD) {
						if (consolidatedGroup[(data as any)?.GROUPID]) {
							consolidatedGroup[
								(data as any).GROUPID
							].FIELDS.push(data);
						}
					}
					if (
						consolidatedGroup[(data as any)?.GROUPID].SECTIONID == 3
					) {
						console.log(
							'',
							consolidatedSections[
								consolidatedGroup[(data as any)?.GROUPID]
									.SECTIONID
							].SECTIONNAME,
							(data as any).FIELDNAME,
							grpFieldDictionary[
								consolidatedSections[
									consolidatedGroup[(data as any)?.GROUPID]
										.SECTIONID
								].SECTIONNAME
							],
						);
					}

					if (
						consolidatedGroup[(data as any)?.GROUPID]?.GROUPTYPE ===
						'TABLE'
					) {
						grpFieldDictionary[
							consolidatedSections[
								consolidatedGroup[(data as any)?.GROUPID]
									.SECTIONID
							].SECTIONNAME
						].push(
							consolidatedGroup[(data as any)?.GROUPID]?.GROUPNAME,
							`${consolidatedGroup[(data as any)?.GROUPID]
								?.GROUPNAME}FLAG`,
						);
					} else {
						grpFieldDictionary[
							consolidatedSections[
								consolidatedGroup[(data as any)?.GROUPID]
									.SECTIONID
							].SECTIONNAME
						].push((data as any).FIELDNAME);
					}
				} else {
					if (!(data as any).CONFIGCHILD) {
						if (consolidatedGroup[(data as any)?.GROUPID]) {
							consolidatedGroup[(data as any)?.GROUPID].FIELDS = [
								data,
							];
						}
					}

					if (
						consolidatedGroup[(data as any)?.GROUPID]?.GROUPTYPE ===
						'TABLE'
					) {
						// grpFieldDictionary[
						// 	consolidatedSections[
						// 		consolidatedGroup[(data as any).GROUPID].SECTIONID
						// 	].SECTIONNAME
						// ].push(consolidatedGroup[(data as any).GROUPID]?.GROUPNAME);
						if (consolidatedGroup[(data as any)?.GROUPID]) {
							grpFieldDictionary[
								consolidatedSections[
									consolidatedGroup[
										(data as any).GROUPID
									].SECTIONID
								].SECTIONNAME
							] = grpFieldDictionary[
								consolidatedSections[
									consolidatedGroup[(data as any)?.GROUPID]
										.SECTIONID
								].SECTIONNAME
							]
								? [
										...grpFieldDictionary[
											consolidatedSections[
												consolidatedGroup[
													(data as any)?.GROUPID
												]?.SECTIONID
											].SECTIONNAME
										],
										consolidatedGroup[(data as any)?.GROUPID]
											?.GROUPNAME,
										`${consolidatedGroup[
											(data as any).GROUPID
										]?.GROUPNAME}FLAG`,
								  ]
								: [
										consolidatedGroup[(data as any)?.GROUPID]
											?.GROUPNAME,
										`${consolidatedGroup[
											(data as any)?.GROUPID
										]?.GROUPNAME}FLAG`,
								  ];
						}
					} else if (consolidatedGroup[(data as any)?.GROUPID]) {
							grpFieldDictionary[
								consolidatedSections[
									consolidatedGroup[
										(data as any)?.GROUPID
									].SECTIONID
								].SECTIONNAME
							] = grpFieldDictionary[
								consolidatedSections[
									consolidatedGroup[(data as any)?.GROUPID]
										?.SECTIONID
								].SECTIONNAME
							]
								? [
										...grpFieldDictionary[
											consolidatedSections[
												consolidatedGroup[
													(data as any)?.GROUPID
												]?.SECTIONID
											].SECTIONNAME
										],
										(data as any).FIELDNAME,
								  ]
								: [(data as any).FIELDNAME];
						}
				}
			});

			Object.values(consolidatedGroup).map((element) => {
				if (consolidatedSections[(element as any).SECTIONID]?.GROUPS) {
					consolidatedSections[(element as any).SECTIONID].GROUPS[
						(element as any).GROUPSEQUENCE - 1
					] = element;
				} else {
					consolidatedSections[(element as any).SECTIONID].GROUPS =
						[];
					consolidatedSections[(element as any).SECTIONID].GROUPS[
						(element as any).GROUPSEQUENCE - 1
					] = element;
				}
			});

			// const fieldDetails = await FormFieldsMaster.findAll({
			// 	include: [
			// 		{ model: FormMaster, as: 'form' },
			// 		{ model: SectionsMaster, as: 'section' },
			// 	],
			// 	// raw: true,
			// });

			res.locals.data = {
				formInfo: formDetails,
				groupWiseData: grpFieldDictionary,
				data: Object.values(consolidatedSections),
			};
			// res.locals.data = { data: comboMasterData };
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getAllModules : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 * Deprecated
	 */
	public async getDataForForms(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('getAllModules api has been invoked');

			const data = req.query;

			const formTables = await FormTableMapping.findAll({
				where: {
					FORMID: 1,
					ACTIVE: true,
				},
				raw: true,
			});

			const selectQueries = formTables.map((element) => {
				const query = `SELECT * FROM "${(element as any).TABLENAME}"`;
				let fields = (element as any).FIELDS.split(',');
				fields = [];
				if (fields.length > 0) {
					fields.reduce((acc, curr, index) => {
						if (index != 0) {
							acc += ' and ';
						}
						acc += `"${curr}" = '${data[curr]}' `;
					}, ' where ');
				}
				return {
					QUERY: query,
					GROUPTYPE: (element as any).GROUPTYPE,
					GROUPNAME: (element as any).GROUPNAME,
				};
			});

			let totalData = {};

			for (const queryformed of selectQueries) {
				console.log('queryformed.GROUPTYPE', queryformed);
				const queryData = await Database.getConnection().query(
					queryformed.QUERY,
					{
						type: QueryTypes.SELECT,
					},
				);
				if (queryformed.GROUPNAME == 'ALL') {
					totalData = { ...totalData, ...(queryData as any)[0] };
				} else if (queryformed.GROUPTYPE == 'OBJECT') {
					totalData[queryformed.GROUPNAME] = queryData[0];
				} else if (queryformed.GROUPTYPE == 'ARRAY') {
					console.log('queryformed.GROUPTYPE', queryformed.GROUPTYPE);
					totalData[queryformed.GROUPNAME] = queryData;
				}
			}

			res.locals.data = {
				data: totalData,
			};
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getAllModules : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 * Deprecated
	 */
	public async postDataForms(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { FORMID = 1 } = req.query;
			switch (FORMID.toString()) {
				case '1':
					const data =
						await PurchaseOrderController.updatePurchaseOrderInfo(
							req,
							res,
							next,
						);
					res.locals.data = { data };
					break;
				default:
					console.log('Unknown fruit.');
			}
			super.send(res);
		} catch (error) {
			logger.error(
				`Error in post forms : ${error.message}\n${error.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
}
