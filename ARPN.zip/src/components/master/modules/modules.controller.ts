import { Application, NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import ApiError from '../../../abstractions/ApiError';
import ModuleMaster from '../../../database/models/masters/moduleMaster';
import logger from '../../../lib/logger';
import BaseApi from '../../BaseApi';

/**
 * Status controller
 */
export default class ModuleInfoController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/', this.getAllModules.bind(this));
		this.router.post('/', this.createModules.bind(this));
		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getAllModules(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('getAllModules api has been invoked');
			const ous = await ModuleMaster.findAll();
			res.locals.data = JSON.parse(JSON.stringify(ous));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getAllModules : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createModules(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { data } = req.body;
			logger.info(
				`createModules api has been invoked, data : ${JSON.stringify(
					data,
				)}`,
			);
			const modules = await ModuleMaster.bulkCreate(data);
			res.locals.data = JSON.parse(JSON.stringify(modules));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in createModules : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
}
