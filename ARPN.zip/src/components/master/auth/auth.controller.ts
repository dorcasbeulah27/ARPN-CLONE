import { Application, NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import jwt from 'jsonwebtoken';
import ApiError from '../../../abstractions/ApiError';
import ModuleMaster from '../../../database/models/masters/moduleMaster';
import OuInfo from '../../../database/models/masters/ouMaster';
import RoleModuleConfigurationMaster from '../../../database/models/masters/relations/roleModuleMapping';
import UserOuMaster from '../../../database/models/masters/relations/userOuMapping';
import UserRoleConfigurationMaster from '../../../database/models/masters/relations/userRoleMapping';
import RoleMaster from '../../../database/models/masters/roleMaster';
import UserMaster from '../../../database/models/masters/userMaster';
import Environment from '../../../environments/environment';
import hash from '../../../lib/hash';
import logger from '../../../lib/logger';
import BaseApi from '../../BaseApi';

/**
 * Status controller
 */
export default class AuthController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.post('/login', this.loginUser.bind(this));
		// this.router.get('/', this.createModule.bind(this));
		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async loginUser(req: Request, res: Response, next: NextFunction) {
		try {
			const { EMAIL, PASSWORD } = req.body;
			logger.info('loginUser api has been invoked, EMAIL : ', EMAIL);
			const User = await UserMaster.findOne({
				where: {
					EMAIL,
				},
			});
			const userInfo = JSON.parse(JSON.stringify(User));
			if (!userInfo?.ID) {
				logger.error('Error in loginUser : Incorrect Email/Password');
				throw new ApiError(
					'Incorrect Email/Password',
					StatusCodes.BAD_REQUEST,
					res,
				);
			}
			const userPass = hash.compareHash(PASSWORD, userInfo.PASSWORD);

			if (userPass) {
				const UserOuMapping = await UserOuMaster.findAll({
					include: [
						{
							model: OuInfo, // Reference to the foreign key model
							as: 'ouInfo', // Alias for the joined data (you can choose your own alias)
						},
					],
					where: {
						USERID: userInfo.ID,
					},
				});
				const userOuMapping = JSON.parse(JSON.stringify(UserOuMapping));
				if (userOuMapping.length === 0) {
					logger.error('No OUs are mapped to the user');

					throw new ApiError(
						'No Ous are mapped to the user',
						StatusCodes.BAD_REQUEST,
						res,
					);
					return;
				}
				const defaultOu =
					userOuMapping.find((element) => element.default) ||
					userOuMapping[0];

				const userRoleMapping =
					await UserRoleConfigurationMaster.findAll({
						include: [
							{
								model: RoleMaster, // Reference to the foreign key model
								as: 'roleInfo', // Alias for the joined data (you can choose your own alias)
							},
						],
						where: {
							USERID: userInfo.ID,
						},
					});
				const userRole = JSON.parse(JSON.stringify(userRoleMapping));
				if (userRole.length === 0) {
					logger.error('No Roles are mapped to the user');

					throw new ApiError(
						'No Roles are mapped to the user',
						StatusCodes.BAD_REQUEST,
						res,
					);
					return;
				}
				const defaultRole =
					userRole.find((element) => element.default) || userRole[0];
				const roleModuleMappings =
					await RoleModuleConfigurationMaster.findAll({
						include: [
							{
								model: ModuleMaster, // Reference to the foreign key model
								as: 'moduleInfo', // Alias for the joined data (you can choose your own alias)
								order: [['SEQUENCE', 'ASC']], // ASC for ascending order, DESC for descending
							},
						],
						where: {
							ROLEID: defaultRole.ROLEID,
						},
					});

				let defaultRoleModules = JSON.parse(
					JSON.stringify(roleModuleMappings),
				);

				defaultRoleModules = defaultRoleModules.sort((a, b) => {
					if (a?.moduleInfo && b?.moduleInfo) {
						return (
							(a.moduleInfo?.SEQUENCE || 0) -
							(b.moduleInfo?.SEQUENCE || 0)
						);
					}
					return 1;
				});
				const env = new Environment();
				const token = jwt.sign(
					{
						USERID: userInfo.ID,
						EMAIL,
						ROLE: defaultRole?.roleInfo
							? defaultRole?.roleInfo.ROLENAME
							: '',
					},
					env.secretKey,
					{ expiresIn: '9h' },
				);

				res.locals.data = {
					message: 'Login Successful',
					email: req.body.email,
					userInfo,
					userOuMapping,
					defaultOu,
					userRole,
					defaultRole,
					defaultRoleModules,
					token,
				};
				super.send(res);
			} else {
				logger.error('Error in loginUser : Incorrect Email/Password');

				throw new ApiError(
					'Incorrect Email/Password',
					StatusCodes.BAD_REQUEST,
					res,
				);
			}
		} catch (err) {
			logger.error(`Error in loginUser : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createModule(req: Request, res: Response, next: NextFunction) {
		try {
			const { data } = req.body;
			logger.info(
				`createModule api has been invoked, data : ${JSON.stringify(
					data,
				)}`,
			);
			const modules = await ModuleMaster.bulkCreate(data);
			res.locals.data = JSON.parse(JSON.stringify(modules));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in createModule : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
}
