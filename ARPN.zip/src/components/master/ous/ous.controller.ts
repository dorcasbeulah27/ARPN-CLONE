import { Application, NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import { Op } from 'sequelize';
import ApiError from '../../../abstractions/ApiError';
import OuInfo from '../../../database/models/masters/ouMaster';
import UserOuMaster from '../../../database/models/masters/relations/userOuMapping';
import logger from '../../../lib/logger';
import comboFormatter from '../../../utils/comboFormatter';
import BaseApi from '../../BaseApi';

/**
 * Status controller
 */
export default class OuInfoController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/', this.getAllOrganizations.bind(this));
		this.router.post('/', this.createOrganization.bind(this));
		this.router.get(
			'/getUserOuMapping',
			this.getUserOrganizations.bind(this),
		);
		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getAllOrganizations(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('getAllOrganizations api has been invoked');
			const ous = await OuInfo.findAll();
			res.locals.data = JSON.parse(JSON.stringify(ous));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getAllOrganizations : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createOrganization(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { data } = req.body;
			logger.info(
				`createOrganization api has been invoked, data : ${JSON.stringify(
					data,
				)}`,
			);
			const ouInfo = await OuInfo.bulkCreate(data);
			res.locals.data = JSON.parse(JSON.stringify(ouInfo));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in createOrganization : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getUserOrganizations(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { USER = 0 } = req.query;
			logger.info(`getUserOrganizations api has been invoked - ${USER}`);
			const userOUMapping = await UserOuMaster.findAll({
				where: {
					USERID: USER,
				},
			});
			const puserOUMapping = JSON.parse(JSON.stringify(userOUMapping));
			const ouInfo = await OuInfo.findAll({
				where: {
					ID: {
						[Op.in]: puserOUMapping.map((e) => e.OUID),
					},
				},
			});
			const pOuInfo = comboFormatter(
				JSON.parse(JSON.stringify(ouInfo)),
				'NAME',
				'ID',
			);
			res.locals.data = pOuInfo;
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getUserOrganizations : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
}
