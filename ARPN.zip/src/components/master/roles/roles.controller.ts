import { Application, NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import ApiError from '../../../abstractions/ApiError';
import RoleModuleConfigurationMaster from '../../../database/models/masters/relations/roleModuleMapping';
import RoleMaster from '../../../database/models/masters/roleMaster';
import logger from '../../../lib/logger';
import BaseApi from '../../BaseApi';

/**
 * Status controller
 */
export default class RolesInfoController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/', this.getAllRoles.bind(this));
		this.router.post('/', this.createRoles.bind(this));
		this.router.get(
			'/roleModuleMapping',
			this.getAllRoleModuleConfigurations.bind(this),
		);
		this.router.post(
			'/roleModuleMapping',
			this.createRoleModuleConfigurations.bind(this),
		);
		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getAllRoles(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllRoles api has been invoked');
			const roles = await RoleMaster.findAll();
			res.locals.data = JSON.parse(JSON.stringify(roles));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllRoles : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createRoles(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('createRoles api has been invoked');
			const { data } = req.body;
			const roles = await RoleMaster.bulkCreate(data);
			res.locals.data = JSON.parse(JSON.stringify(roles));
			super.send(res);
		} catch (err) {
			logger.error(`Error in createRoles : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getAllRoleModuleConfigurations(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('getRoleModuleConfigurator api has been invoked');
			const roles = await RoleModuleConfigurationMaster.findAll();
			res.locals.data = JSON.parse(JSON.stringify(roles));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getRoleModuleConfigurator : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createRoleModuleConfigurations(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { data } = req.body;
			logger.info(
				'createRoleModuleConfigurations api has been invoked, data : ',
				JSON.stringify(data),
			);
			const roles = await RoleModuleConfigurationMaster.bulkCreate(data);
			res.locals.data = JSON.parse(JSON.stringify(roles));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in createRoleModuleConfigurations : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
}
