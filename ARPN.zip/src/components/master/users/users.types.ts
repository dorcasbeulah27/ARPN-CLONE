export interface UserInformation {
	ID: number;
	OUID: number;
	USERID: number;
	USERNAME: string;
	PHONENO: string;
	EMAIL: string;
	PASSWORD: string;
	ACTIVE: boolean;
}
