import { Application, NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import ApiError from '../../../abstractions/ApiError';
import OuInfo from '../../../database/models/masters/ouMaster';
import UserOuMaster from '../../../database/models/masters/relations/userOuMapping';
import UserRoleConfigurationMaster from '../../../database/models/masters/relations/userRoleMapping';
import UserMaster from '../../../database/models/masters/userMaster';
import Hash from '../../../lib/hash';
import logger from '../../../lib/logger';
import BaseApi from '../../BaseApi';

/**
 * Status controller
 */
export default class UserInfoController extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/', this.getAllUsers.bind(this));
		this.router.post('/', this.createUsers.bind(this));
		this.router.get('/userOuMapping', this.getUserOuMapping.bind(this));
		this.router.post('/userOuMapping', this.createUserOuMapping.bind(this));
		this.router.get('/userRoleMapping', this.getAllUserRoles.bind(this));
		this.router.post(
			'/userRoleMapping',
			this.createUserRoleMapping.bind(this),
		);
		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getAllUsers(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllUsers api has been invoked');
			const users = await UserMaster.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createUsers(req: Request, res: Response, next: NextFunction) {
		try {
			let { data } = req.body;
			logger.info(
				`createUsers api has been invoked, data : ${JSON.stringify(
					data,
				)}`,
			);
			data = data.map((element) => ({
				...element,
				PASSWORD: Hash.hash(element.PASSWORD),
			}));
			const users = await UserMaster.bulkCreate(data);
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in createUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				'An Error occured while bulk creating users, Kindly contact Support team',
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getUserOuMapping(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { USERID } = req.query;
			logger.info(
				'getUserOuMapping api has been invoked, USERID :',
				USERID,
			);
			const users = await UserOuMaster.findAll({
				where: { USERID },
				include: [
					{
						model: OuInfo,
						as: 'ouInfo',
						attributes: [
							'ID',
							'TYPE',
							'NAME',
							'DESCRIPTION',
							'ADDRESS',
							'CITY',
							'STATE',
							'COUNTRY',
							'PINCODE',
							'ACTIVE',
						],
					},
				],
			});
			const data = JSON.parse(JSON.stringify(users));
			res.locals.data = data.map((element) => ({
				id: element.OUID,
				label: element?.ouInfo?.DESCRIPTION,
				data: element?.ouInfo,
			}));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getUserOuMapping : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createUserOuMapping(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { data } = req.body;
			logger.info(
				'createUserOuMapping api has been invoked, data :',
				JSON.stringify(data),
			);
			const ouInfo = await UserOuMaster.bulkCreate(data);
			res.locals.data = JSON.parse(JSON.stringify(ouInfo));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getUserOuMapping : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getAllUserRoles(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			logger.info('getAllUserRoles api has been invoked:');
			const users = await UserRoleConfigurationMaster.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in getAllUserRoles : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createUserRoleMapping(
		req: Request,
		res: Response,
		next: NextFunction,
	) {
		try {
			const { data } = req.body;
			logger.info(
				`createUserRoleMapping api has been invoked:${JSON.stringify(
					data,
				)}`,
			);
			const users = await UserRoleConfigurationMaster.bulkCreate(data);
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(
				`Error in createUserRoleMapping : ${err.message}\n${err.stack}`,
			);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
}
