import http from 'http';
import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import swaggerUi from 'swagger-ui-express';
import swaggerDocument from '../swagger.json';
import auth from './middleware/auth';
import addErrorHandler from './middleware/error-handler';
import registerRoutes from './postAuthRoutes';
import preAuthRoutes from './preAuthRoutes';
import SOFRMaster from './database/models/business/bankMaster/sofrMaster';
import PRENEGSOFRMaster from './database/models/business/bankMaster/preNegSOFRMaster';
import POSTNEGSOFRMaster from './database/models/business/bankMaster/postNegSOFRMaster';
import testTable from './database/models/business/bankMaster/testTable';
import { Op } from 'sequelize';
// import Database from './database';

export default class App {
	public express: express.Application;

	public httpServer: http.Server;

	public connection: void;

	public async init(): Promise<void> {
		this.express = express();
		this.httpServer = http.createServer(this.express);

		// add all global middleware like cors
		this.middleware();
		this.preAuthRoutes();

		this.customMiddlewares();

		// register the all routes
		this.routes();

		// add the middleware to handle error, make sure to add if after registering routes method
		this.express.use(addErrorHandler);
		// comboMaster.findAll({});
		// In a development/test environment, Swagger will be enabled.
		if (environment.isDevEnvironment() || environment.isTestEnvironment()) {
			this.setupSwaggerDocs();
		}
		// POSTNEGSOFRMaster.findAll()
		// this.connection = Database.setEnvironmentalVar(environment);
	}

	/**
	 * here register your all routes
	 */
	private preAuthRoutes(): void {
		this.express.use('/', preAuthRoutes());
	}

	private routes(): void {
		this.express.get('/', this.basePathRoute);
		this.express.get('/web', this.parseRequestHeader, this.basePathRoute);
		this.express.use('/', registerRoutes());
	}

	/**
	 * here you can apply your middlewares
	 */
	private middleware(): void {
		// support application/json type post data
		// support application/x-www-form-urlencoded post data
		// Helmet can help protect your app from some well-known web vulnerabilities by setting HTTP headers appropriately.
		this.express.use(helmet({ contentSecurityPolicy: false }));
		this.express.use(express.json({ limit: '10000mb' }));
		this.express.use(
			express.urlencoded({ limit: '10000mb', extended: true }),
		);
		// add multiple cors options as per your use
		console.log(environment.applicationUri);
		const corsOptions = {
			origin: ['http://localhost:8080', environment.applicationUri],
		};
		this.express.use(cors(corsOptions));
	}

	private customMiddlewares(): void {
		this.express.use(auth);
	}

	private parseRequestHeader(
		req: express.Request,
		res: express.Response,
		next: any,
	): void {
		// parse request header
		// console.log(req.headers.access_token);
		next();
	}

	private basePathRoute(
		request: express.Request,
		response: express.Response,
	): void {
		response.json({ message: 'base path' });
	}

	private setupSwaggerDocs(): void {
		this.express.use(
			'/docs',
			swaggerUi.serve,
			swaggerUi.setup(swaggerDocument),
		);
	}
}
