import { Router } from 'express';
import SAPIntegrationController from './components/business/@external/sapIntegration.controller';
import FilesController from './components/business/files.controller';
import AuthController from './components/master/auth/auth.controller';
import TestGetControllers from './components/testPreAuth/testGetController';
/**
 * Here, you can register routes by instantiating the controller.
 *
 */
export default function preAuthRoutes(): Router {
	const router = Router();

	const authController: AuthController = new AuthController();
	const filesController: FilesController = new FilesController();
	const sapIntegrationController: SAPIntegrationController =
		new SAPIntegrationController();
	const testGet:TestGetControllers=new TestGetControllers()


	router.use('/auth', authController.register());
	router.use('/attachments', filesController.register());
	router.use('/api/sapIntegration', sapIntegrationController.register());
	router.use('/api/test', testGet.register())

	return router;
}
