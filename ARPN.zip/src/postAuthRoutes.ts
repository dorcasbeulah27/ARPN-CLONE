import { Router } from 'express';
// import AuthController from './components/master/auth/auth.controller';
import BankMasterController from './components/business/BankMaster/bankMaster.controller';
import OrderTrackerKPIController from './components/business/KPI/orderTrackerKPI.controller';
import tradeFinanceDashboardKPIController from './components/business/KPI/tradeFinanceKPI.controller';
import OilBulksController from './components/business/OilBulk/oilBulk.controller';
import PurchaseOrderController from './components/business/PurchaseOrder/purchaseOrder.controller';
import ScmReportsController from './components/business/SCMReports/scmReports.controller';
import liquidationTreasuryController from './components/business/Treasury/liquidationTreasury.controller';
import TreasuryReportController from './components/business/TreasuryReports/treasuryReports.controller';
import WheatBulksController from './components/business/WheatBulk/wheatBulk.controller';
import FormInfoController from './components/master/forms/forms.controller';
import ModuleInfoController from './components/master/modules/modules.controller';
import OuInfoController from './components/master/ous/ous.controller';
import RolesInfoController from './components/master/roles/roles.controller';
import UserInfoController from './components/master/users/users.controller';
import SystemStatusController from './components/system-status/system-status.controller';
import AirShipmentController from './components/business/AirShipment/airShipment.controller';
import LcCommissionController from './components/business/TreasuryReports/lcCommission.controller';
import PaymentController from './components/business/Payment/payment.controller';
import MaterialMasterController from './components/business/Material/material.controller';
import NonOverdueReport from './components/business/TreasuryReports/nonOverDueReport.controller';
import PreNegReport from './components/business/TreasuryReports/preNegReport.controller';
import PostNegReport from './components/business/TreasuryReports/postNegReport.controller';
import testControllers from './beulahTest/testControllers';
import TestPostController from './components/testPostAuth/testPostController';
import courseController from './components/business/CourseController/courseController';
import studentController from './components/StudentController/studentController';
import teacherController from './components/TeacherController/teacherController';
import mapToTeacher from './components/business/CourseController/mapToTeacher';
import StudentMapToCourse from './components/StudentController/studentMapToCourse';
import StudentMapToTeacher from './components/StudentController/studentMapToTeacher';
import geolocController from './components/business/BlocksController/geolocController';
import BlockController from './components/business/BlocksController/blockControll';
import SectorController from './components/business/SectorController/sectorControll';

import UserController from './components/business/arpnControllers/userController';
import EmployeeController from './components/business/arpnControllers/employeeController';
import ContractorController from './components/business/arpnControllers/contractorController';
import UsersWorkplan from './components/business/arpnControllers/usersWorkplan';
import EmpContWorkPlan from './components/business/arpnControllers/empContractorWorkplan';
/**
/**
 * Here, you can register routes by instantiating the controller.
 *
 */
export default function registerRoutes(): Router {
	const router = Router();

	const systemStatusController: SystemStatusController =
		new SystemStatusController();
	const userInfoController: UserInfoController = new UserInfoController();
	const ouInfoController: OuInfoController = new OuInfoController();
	const rolesInfoController: RolesInfoController = new RolesInfoController();
	const moduleInfoController: ModuleInfoController =
		new ModuleInfoController();
	const formInfoController: FormInfoController = new FormInfoController();
	const purchaseOrderController: PurchaseOrderController =
		new PurchaseOrderController();
	const bankMasterController: BankMasterController =
		new BankMasterController();
	const scmReportController: ScmReportsController =
		new ScmReportsController();

	const wheatBulkController: WheatBulksController =
		new WheatBulksController();
	const oilBulkController: OilBulksController = new OilBulksController();
	const orderTrackerKPI: OrderTrackerKPIController =
		new OrderTrackerKPIController();

	const liquidationTreasury: liquidationTreasuryController =
		new liquidationTreasuryController();
	const tradefinanceDashboardKPIController: tradeFinanceDashboardKPIController =
		new tradeFinanceDashboardKPIController();
	const treasuryReportController: TreasuryReportController =
		new TreasuryReportController();
	const airShipmentController: AirShipmentController =
		new AirShipmentController();
	const lcCommissionReportController: LcCommissionController =
		new LcCommissionController();
	const nonOverdueReportController: NonOverdueReport = new NonOverdueReport();
	const preNegReportController: PreNegReport = new PreNegReport();
	const postNegReportController: PostNegReport = new PostNegReport();

	const paymentController: PaymentController = new PaymentController();
	const materialController: MaterialMasterController =
		new MaterialMasterController();
	const testController1: testControllers = new testControllers();
	const testPost: TestPostController = new TestPostController();
	const courses: courseController = new courseController();
	const student: studentController = new studentController();
	const teacher: teacherController = new teacherController();
	const mapingToTeacher: mapToTeacher = new mapToTeacher();
	const StudentMapingToCourse: StudentMapToCourse = new StudentMapToCourse();
	const StudentMapingToTeacher: StudentMapToTeacher =
		new StudentMapToTeacher();
	const blockcontroller: BlockController = new BlockController();
	const sectorcontroller: SectorController = new SectorController();
	const geoLatLogs: geolocController = new geolocController();

	const UserControl: UserController = new UserController();
	const EmployeeControl: EmployeeController = new EmployeeController();
	const contractControl: ContractorController = new ContractorController();
	const userWorkplan: UsersWorkplan = new UsersWorkplan();
	const empContWorkplan: EmpContWorkPlan = new EmpContWorkPlan();

	router.use('/api/status', systemStatusController.register());
	router.use('/api/user', userInfoController.register());
	router.use('/api/ou', ouInfoController.register());
	router.use('/api/roles', rolesInfoController.register());
	router.use('/api/modules', moduleInfoController.register());
	router.use('/api/purchaseOrder', purchaseOrderController.register());
	router.use('/api/wheatBulk', wheatBulkController.register());
	router.use('/api/oilBulk', oilBulkController.register());
	router.use('/api/bankMaster', bankMasterController.register());
	router.use('/api/forms', formInfoController.register());
	router.use('/api/scmReports', scmReportController.register());
	router.use('/api/orderTrackerKPI', orderTrackerKPI.register());
	router.use('/api/liquidationTreasury', liquidationTreasury.register());
	router.use(
		'/api/tradefinanceKPI',
		tradefinanceDashboardKPIController.register(),
	);
	router.use('/api/treasuryReports', treasuryReportController.register());
	router.use('/api/airShipment', airShipmentController.register());
	router.use('/api/lcCommission', lcCommissionReportController.register());
	router.use('/api/nonOverdueReport', nonOverdueReportController.register());
	router.use('/api/preNegReport', preNegReportController.register());
	router.use('/api/postNegReport', postNegReportController.register());
	router.use('/api/payment', paymentController.register());
	router.use('/api/material', materialController.register());
	router.use('/api/test', testController1.register());
	router.use('/api/test', testPost.register());
	router.use('/api/course', courses.register());
	router.use('/api/student', student.register());
	router.use('/api/teacher', teacher.register());
	router.use('/api/map', mapingToTeacher.register());

	router.use('/api/mapcourse', StudentMapingToCourse.register());
	router.use('/api/mapteacher', StudentMapingToTeacher.register());
	router.use('/api/blocks', blockcontroller.register());
	router.use('/api/sector', sectorcontroller.register());
	router.use('/api/latlogs', geoLatLogs.register());
	router.use('/api/users', UserControl.register());
	router.use('/api/employee', EmployeeControl.register());
	router.use('/api/contractor', contractControl.register());
	router.use('/api/userWorkplan', userWorkplan.register());
	router.use('/api/empConWorkplan', empContWorkplan.register());

	return router;
}
