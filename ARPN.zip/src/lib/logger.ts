import { existsSync, mkdirSync } from 'fs';
import { Logger } from 'winston';
import winston = require('winston');

import DailyRotateFile from 'winston-daily-rotate-file';

const logDir = './logs';

if (!existsSync(logDir)) {
	mkdirSync(logDir);
}

const transport = new DailyRotateFile({
	filename: `${logDir}/%DATE%.log`,
	datePattern: 'YYYY-MM-DD',
	zippedArchive: false,
	maxFiles: '7d', // Rotate logs after 7 days
	maxSize: '20m', // Set a maximum file size
	// level: "error", // Specify the log level (info, debug, error, etc.)
	format: winston.format.combine(
		winston.format.json(),
		winston.format.timestamp(),
		winston.format.metadata(),
		winston.format.errors({ stack: true }),
		winston.format.prettyPrint(),
	),
});

const logger: Logger = winston.createLogger({
	format: winston.format.combine(
		winston.format.json(),
		winston.format.timestamp(),
		winston.format.metadata(),
		winston.format.errors({ stack: true }),
		winston.format.prettyPrint(),
	),
	transports: [new winston.transports.Console(), transport],
	// statusLevels: true,
	exceptionHandlers: [new winston.transports.Console(), transport],
});

export default logger;
