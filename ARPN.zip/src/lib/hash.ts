import bcrypt from 'bcryptjs';

export default class Hash {
	private static salt: string = bcrypt.genSaltSync(10);

	public static hash(plainText: string): string {
		const hashedValue = bcrypt.hashSync(plainText, this.salt);
		return hashedValue;
	}

	public static compareHash(plainText: string, existingHash: string): string {
		const result = bcrypt.compareSync(plainText, existingHash);
		return result;
	}
}
