import * as dotenv from 'dotenv';
import { Transporter } from 'nodemailer';
import Environment from '../environments/environment';

const fs = require('fs');
const ejs = require('ejs');
const nodemailer = require('nodemailer');

dotenv.config(); // Load environment variables from .env file

export default class Mail {
	private static mailInstance: Transporter<{}> | null = null;

	private static env: Environment | null = null;

	private static mailOption: any;

	private static fromMail: string;

	private static mailEnv(): Environment {
		if (!this.env) {
			return new Environment();
		} 
			return this.env;
		
	}

	private static establishMailInstance(): void {
		if (!this.mailInstance) {
			const mail = this.mailEnv();
			console.log('establishMailInstance', mail.dbIp, mail.emailId);
			this.fromMail = mail.emailId;
			this.mailOption = {
				from: mail.emailId,
				to: mail.maintenanceMails, // Recipient's email address
				subject: `${mail.applicationName} has crashed!`,
				text: `${mail.applicationName} is facing some issue can you please check!!`,
			};

			this.mailInstance = nodemailer.createTransport({
				service: mail.mailService, // Use the Outlook service
				auth: {
					user: mail.emailId, // Your Outlook email address
					pass: mail.emailPassword, // Your Outlook email password
				},
			});
		}
	}

	public static transporter(): Transporter {
		this.establishMailInstance();
		if (!this.mailInstance) {
			throw new Error('Mail connection not established.');
		}
		return this.mailInstance;
	}

	public static async sendErrorMailFunc(): Promise<void> {
		console.log('Inside email', this.mailOption);
		// const mailOptions = {
		// 	from: this.emailId,
		// 	to: this.maintenanceMails, // Recipient's email address
		// 	subject: `${this.applicationName} has crashed!`,
		// 	text: `${this.applicationName} is facing some issue can you please check!!`,
		// };
		const info = await this.transporter().sendMail(
			this.mailOption,
			(error, info) => {
				if (error) {
					console.log(`Error sending email: ${error}`);
					return false;
				}
				console.log(`Email sent: ${info.response}`);
				return true;
			},
		);
		return info;
	}

	// Example for sending EJS mail
	// public static async sendFinanceEntryMailFunc(
	// 	toEmails: string,
	// 	subject: string,
	// 	template: any,
	// ): Promise<void> {
	// 	fs.readFile(
	// 		'./src/mailTemplates/financeEntryMailer.ejs',
	// 		'utf8',
	// 		async (err, data) => {
	// 			if (err) {
	// 				console.error('Error reading template:', err);
	// 				return;
	// 			}

	// 			// Compile the EJS template
	// 			const compiledTemplate = ejs.compile(data);
	// 			const mail = this.mailEnv();
	// 			// Generate dynamic HTML content
	// 			const htmlContent = compiledTemplate({ ...template,APPURI : mail.applicationUri });

	// 			// Mail content
	// 			const datas = {
	// 				from: mail.emailId,
	// 				to: toEmails,
	// 				subject,
	// 				// text : "hi"
	// 				html: htmlContent,
	// 				attachments: [
	// 					{
	// 						filename: 'WarrantyHdr.png', // Change the filename as per your image
	// 						path: './src/mailTemplates/images/warrantyMailer/WarrantyHdr.png', // Path to your image file
	// 						cid: 'WarrantyHdr', // Unique identifier for the image
	// 					},
	// 					{
	// 						filename: 'Hero.svg', // Change the filename as per your image
	// 						path: './src/mailTemplates/images/logos/Hero.svg', // Path to your image file
	// 						cid: 'Hero', // Unique identifier for the image
	// 					},
	// 					{
	// 						filename: 'Metayb.png', // Change the filename as per your image
	// 						path: './src/mailTemplates/images/logos/Metayb.png', // Path to your image file
	// 						cid: 'Metayb', // Unique identifier for the image
	// 					},
	// 				],
	// 			};
	// 			const info = await this.transporter().sendMail(
	// 				datas,
	// 				(error, info) => {
	// 					if (error) {
	// 						console.log(`Error sending email: ${error}`);
	// 						return false;
	// 					}
	// 					console.log(`Email sent: ${info.response}`);
	// 					return true;
	// 				},
	// 			);
	// 			return info;
	// 		},
	// 	);
	// }

}
