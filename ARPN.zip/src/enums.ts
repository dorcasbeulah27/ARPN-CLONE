export enum OUTYPE {
  WARRANTY = 'Warranty',
  DEALER = 'Dealer',
  WAREHOUSE = 'Warehouse',
}

export enum WARRANTYSTATUS {
  NEW = 'NEW',
  APPROVED = 'APPROVED',
  DENIED = 'DENIED',
}

export enum MAILTYPE {
  WARRANTY = 'Warranty',
  FINANCE = 'Finance',
}

export enum WAYBILLSTATUS {
  PENDING = 'pending',
  ALL = 'all',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  RECENT = 'recent',
}

export enum CRUDSTATUS {
  CREATE = 'c',
  DELETE = 'd',
  UPDATE = 'u',
}

export enum ROLES {
  ADMIN = 'admin',
  FLEETMANAGER = 'fleetmanager',
}
