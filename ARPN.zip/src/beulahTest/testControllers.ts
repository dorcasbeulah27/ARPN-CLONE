import { Application, NextFunction, Request, Response, Router } from 'express';
import { ReasonPhrases, StatusCodes } from 'http-status-codes';
import ApiError from '../abstractions/ApiError';
import UserMaster from '../database/models/masters/userMaster';
import logger from '../lib/logger';
import BaseApi from '../components/BaseApi';

/**
 * User Management controller
 */
export default class testControllers extends BaseApi {
	constructor() {
		super();
	}

	/**
	 *
	 */
	public register(): Router {
		this.router.get('/', this.getAllUsers.bind(this));
		this.router.post('/', this.createUser.bind(this));
		this.router.put('/:id', this.updateUser.bind(this));
		this.router.delete('/:id', this.deleteUser.bind(this));

		return this.router;
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async getAllUsers(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('getAllUsers api has been invoked');
			const users = await UserMaster.findAll();
			res.locals.data = JSON.parse(JSON.stringify(users));
			super.send(res);
		} catch (err) {
			logger.error(`Error in getAllUsers : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async createUser(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('createUser api has been invoked');
			const { data } = req.body;
			const user = await UserMaster.create(data);
			res.locals.data = JSON.parse(JSON.stringify(user));
			super.send(res);
		} catch (err) {
			logger.error(`Error in createUser : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	/**
	 *
	 * @param req
	 * @param res
	 * @param next
	 */
	public async updateUser(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('updateUser api has been invoked');
			const { id } = req.params;
			const { data } = req.body;
			const user = await UserMaster.update(data, { where: { id } });
			res.locals.data = JSON.parse(JSON.stringify(user));
			super.send(res);
		} catch (err) {
			logger.error(`Error in updateUser : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}

	public async deleteUser(req: Request, res: Response, next: NextFunction) {
		try {
			logger.info('deleteUser api has been invoked');
			const { id } = req.params;
			console.log("id", id)
			const { data } = req.body;
			const user = await UserMaster.destroy({ where: { ID: id } });
			res.locals.data = {user};
			super.send(res);
		} catch (err) {
			logger.error(`Error in deleteUser : ${err.message}\n${err.stack}`);
			throw new ApiError(
				ReasonPhrases.BAD_REQUEST,
				StatusCodes.BAD_REQUEST,
				res,
			);
		}
	}
}
