export interface IStandardResponse {
	success: boolean;
}
