import { StatusCodes } from 'http-status-codes';
import Database from '../database';
import logger from '../lib/logger';
import ApiError from './ApiError';

export const dataFormmSubmittedGrtThan10 = async () => {
    try {
        const sequelize = Database.getConnection();

        const FORMMSUBMITTEDDATEGRT10 = await sequelize.query(`
        SELECT *
        FROM "TRADEFINANCE" t
        JOIN "PROCUREMENT" p ON t."PROCUREMENTID" = p."ID"
        WHERE t."FORMMSUBMITTEDDATE" IS NOT NULL 
        AND p."PFIDATE" IS NOT NULL
        AND t."FORMMSUBMITTEDDATE" >= p."PFIDATE" + interval '10 days'; 
    `);
        return FORMMSUBMITTEDDATEGRT10[0];
    } catch (error) {
        console.log('error: ', error);
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }

};

export const dataFormmRegisteredGrt12 = async () => {
    try {
        const sequelize = Database.getConnection();

        const FORMMREGISTEREDDATEGRT12 = await sequelize.query(`
        SELECT *
    FROM "TRADEFINANCE" t
    JOIN "PROCUREMENT" p ON t."PROCUREMENTID" = p."ID"
    WHERE t."FORMMREGISTEREDDATE" IS not NULL 
    AND p."PFIDATE" IS NOT NULL
    AND t."FORMMREGISTEREDDATE" >= p."PFIDATE" + interval '12 days'  
    `);
        return FORMMREGISTEREDDATEGRT12[0];
    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};

export const dataLcClosure = async () => {
    try {
        const sequelize = Database.getConnection();

        const LCCLOSURE = await sequelize.query(`
    SELECT *
    FROM "TRADEFINANCE" t
    JOIN "PROCUREMENT" p ON t."PROCUREMENTID" = p."ID"
    WHERE t."FORMMREGISTEREDDATE" IS NOT NULL 
    AND p."PFIDATE" IS NOT NULL
    AND t."FORMMREGISTEREDDATE" <= p."PFIDATE" + interval '12 days';
    `);

        return LCCLOSURE[0];
    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};

export const dataLcOngoing = async () => {
    try {
        const sequelize = Database.getConnection();

        const LCONGOING = await sequelize.query(`
        SELECT *
        FROM "LC" AS "LC"
        JOIN "PROCUREMENT" as "P" on "LC"."PROCUREMENTID" = "P"."ID" 
        WHERE "P"."PFIMODEOFPAYMENT" = 'LC'
        GROUP BY "P"."ID", "LC"."ID", COALESCE("LC"."LCRECEIVEDBYSUPPLIER");
            `);

        return LCONGOING[0];


    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};

export const dataLcOngoingGrtThan20 = async () => {
    try {
        const sequelize = Database.getConnection();

        const LCONGOINGGRTTHAN20 = await sequelize.query(`
        SELECT *
        FROM "LC" AS "LC"
        JOIN "PROCUREMENT" "P" ON "LC"."PROCUREMENTID" = "P"."ID" 
        WHERE "P"."PFIMODEOFPAYMENT" = 'LC'
          AND DATE_TRUNC('day', "P"."PFIDATE" + INTERVAL '20 days') > CURRENT_DATE
        GROUP BY "P"."ID", "LC"."ID", COALESCE("LC"."LCRECEIVEDBYSUPPLIER");
    `);

        return LCONGOINGGRTTHAN20[0];

    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};

export const dataOrgDocsGrtThan20 = async () => {
    try {
        const sequelize = Database.getConnection();

        const orgDocsGrtThan20: any = await sequelize.query(`
        SELECT *
        FROM "LC" l
        JOIN "SHIPMENT" s ON l."PROCUREMENTID" = s."PROCUREMENTID"
        WHERE l."SCANNEDDOCSRECEIVED" = false
        AND s."BLDATE" > CURRENT_DATE - INTERVAL '20 days';
    `);

        return orgDocsGrtThan20[0];
    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};

export const dataPaarPending = async () => {
    try {
        const sequelize = Database.getConnection();

        const paarPending: any = await sequelize.query(`
        SELECT
        *
    FROM 
        "SHIPMENT" s 
    LEFT JOIN 
        "PROCUREMENT" p ON s."PROCUREMENTID" = p."ID" AND s."APPLIEDFORPAAR" = false
    WHERE 
        p."FACTORY" = 'NG10';
        `);

        return paarPending[0];
    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};

export const countLcClosure = async () => {
    try {
        const sequelize = Database.getConnection();

        const lcClousreCount: any = await sequelize.query(`
    SELECT count(*)
    FROM "TRADEFINANCE" t
    JOIN "PROCUREMENT" p ON t."PROCUREMENTID" = p."ID"
    WHERE t."FORMMREGISTEREDDATE" IS NOT NULL 
    AND p."PFIDATE" IS NOT NULL
    AND t."FORMMREGISTEREDDATE" <= p."PFIDATE" + interval '12 days';
    `);

        const lcClousreCon = parseInt(lcClousreCount[0][0]?.count);
        console.log('returned from func lcClousreCount: ', lcClousreCon);
        return lcClousreCon;
    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};

export const countPaar = async () => {
    try {
        const sequelize = Database.getConnection();

        const paarCount: any = await sequelize.query(`
        SELECT
        count(*)
    FROM 
        "SHIPMENT" s 
    LEFT JOIN 
        "PROCUREMENT" p ON s."PROCUREMENTID" = p."ID" AND s."APPLIEDFORPAAR" = false
    WHERE 
        p."FACTORY" = 'NG10';
        `);
        paarCount[0][0]?.count;
        const paarCon = parseInt(paarCount[0][0]?.count);
        console.log('returned from func paarCon: ', paarCon);
        return paarCon;
    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};

export const countLcOngoingGrt20 = async () => {
    try {
        const sequelize = Database.getConnection();

        const lcOngoingCountLess: any = await sequelize.query(`
        SELECT
        COUNT(*) AS count
    FROM
        "LC" AS "LC"
    JOIN
        "PROCUREMENT" "P" on "LC"."PROCUREMENTID" = "P"."ID" 
    WHERE
        "P"."PFIMODEOFPAYMENT" = 'LC'
        AND DATE_TRUNC('day', "P"."PFIDATE" + INTERVAL '20 days') > CURRENT_DATE
    GROUP BY
        "LC"."LCRECEIVEDBYSUPPLIER" IS NULL OR NOT NULL, "LC"."LCRECEIVEDBYSUPPLIER";
       
        `);

        const lcOngoingLess20Con = parseInt(lcOngoingCountLess[1]?.rows[0]?.count);
        console.log('returned from func lcOngoingCon: ', lcOngoingLess20Con);
        return lcOngoingLess20Con;
    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};

export const countLcOngoing = async () => {
    try {
        const sequelize = Database.getConnection();

        const lcOngoingCount: any = await sequelize.query(`
        SELECT
        "LC"."LCRECEIVEDBYSUPPLIER",
        COUNT(*) AS count
        FROM
        "LC" AS "LC"
        JOIN
        "PROCUREMENT" "P" ON "LC"."PROCUREMENTID" = "P"."ID"
        WHERE
        "P"."PFIMODEOFPAYMENT" = 'LC'
        GROUP BY
        "LC"."LCRECEIVEDBYSUPPLIER" IS NULL OR NOT NULL, "LC"."LCRECEIVEDBYSUPPLIER";
        `);

        const lcOngoingCon = parseInt(lcOngoingCount[0][0].count);
        console.log('returned from func lcOngoingCon: ', lcOngoingCon);
        return lcOngoingCon;
    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};

export const countFormmRegisGrtThan12 = async () => {
    try {
        const sequelize = Database.getConnection();

        const formMRegisterLessThan12Count: any = await sequelize.query(`
        SELECT count(*)
        FROM "TRADEFINANCE" t
        JOIN "PROCUREMENT" p ON t."PROCUREMENTID" = p."ID"
        WHERE t."FORMMREGISTEREDDATE" IS NOT NULL 
        AND p."PFIDATE" IS NOT NULL
        AND t."FORMMREGISTEREDDATE" >= p."PFIDATE" + interval '12 days';
        `);

        const formRegLessThan12Con = parseInt(formMRegisterLessThan12Count[0][0].count);
        console.log('returned from func formRegLessThan12Con: ', formRegLessThan12Con);
        return formRegLessThan12Con;
    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};

export const countFormmSubmGrtThan10 = async () => {
    try {
        const sequelize = Database.getConnection();

        const formMSubmLessThan10Count: any = await sequelize.query(`
        SELECT count(*)
        FROM "TRADEFINANCE" t
        JOIN "PROCUREMENT" p ON t."PROCUREMENTID" = p."ID"
        WHERE t."FORMMSUBMITTEDDATE" IS NOT NULL 
        AND p."PFIDATE" IS NOT NULL
        AND t."FORMMSUBMITTEDDATE" >= p."PFIDATE" + interval '10 days';  
    `);

        const formSubLessThan10Con = parseInt(formMSubmLessThan10Count[0][0].count);
        console.log('returned from func formSubLessThan10Con: ', formSubLessThan10Con);
        return formSubLessThan10Con;
    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};

export const countOrgDocsGrtThan20 = async () => {
    try {
        const sequelize = Database.getConnection();

        const orgDocsGrtThan20: any = await sequelize.query(`
        SELECT count(*)
        FROM "LC" l
        JOIN "SHIPMENT" s ON l."PROCUREMENTID" = s."PROCUREMENTID"
        WHERE l."SCANNEDDOCSRECEIVED" = false
        AND s."BLDATE" > CURRENT_DATE - INTERVAL '20 days';
    `);

        const orgDocsGrtThan20Con = parseInt(orgDocsGrtThan20[0][0].count);
        console.log('returned from func orgDocsGrtThan20: ', orgDocsGrtThan20Con);
        return orgDocsGrtThan20Con;
    } catch (error) {
        logger.error(
            `Error in while retriveing data: ${error.message}\n${error.stack}`,
        );
        throw new ApiError(error.message, StatusCodes.BAD_REQUEST, error);
    }
};