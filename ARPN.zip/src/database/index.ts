import { DotenvParseOutput } from 'dotenv';
import { Sequelize } from 'sequelize';
import Environment from '../environments/environment';

export default class Database {
	private static connectionInstance: Sequelize | null = null;

	private static establishConnection(): void {
		if (!this.connectionInstance) {
			const db = new Environment();
			console.log('DB Connection has been established - ', db.dbIp);
			this.connectionInstance = new Sequelize(
				db.dbDatabase || '',
				db.dbUser || '',
				db.dbPassword || '',
				{
					host: db.dbIp || 'localhost',
					port: db.dbPort || 5432,
					dialect: 'postgres' as const,
				},
			);
		}
	}

	public static getConnection(): Sequelize {
		this.establishConnection();
		if (!this.connectionInstance) {
			throw new Error('Database connection not established.');
		}
		return this.connectionInstance;
	}

	public static async testConnection(): Promise<void> {
		try {
			await this.getConnection().authenticate();
			console.log('Connection has been established successfully.');
		} catch (error) {
			console.error('Unable to connect to the database:', error);
		}
	}
}
