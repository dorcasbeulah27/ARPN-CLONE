import { DataTypes } from 'sequelize';
import Database from '../../..';
import LCMAIN from '../purchaseOrder/lcMain';

const ttList = Database.getConnection().define(
	'ttList',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
        LCMAINID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
        FORMMNO:{
			type: DataTypes.TEXT,
			allowNull: true,
		}, 
		TTPAYMENTAMOUNT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		TTPAYMENTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		}
	},
	{
		timestamps: true,
		tableName: 'TTLIST',
	},
);


ttList.belongsTo(LCMAIN, {
	foreignKey: 'LCMAINID',
	as: 'lcmain',
});

// LiquidationList.sync({ force: true });

export default ttList;
