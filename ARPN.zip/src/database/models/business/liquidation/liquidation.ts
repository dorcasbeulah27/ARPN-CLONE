import { DataTypes } from 'sequelize';
import Database from '../../..';
import LCMAIN from '../purchaseOrder/lcMain';

const LiquidationList = Database.getConnection().define(
	'liquidationList',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
        LCMAINID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
        FORMMNO:{
			type: DataTypes.TEXT,
			allowNull: true,
		}, 
		LIQUIDATIONAMOUNT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		LIQUIDATIONDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		UNREALISEDFOREXGAINLOSS: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		REALISEDFOREXGAINLOSS: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
	},
	{
		timestamps: true,
		tableName: 'LIQUIDATIONLIST',
	},
);


LiquidationList.belongsTo(LCMAIN, {
	foreignKey: 'LCMAINID',
	as: 'lcmain',
});

// LiquidationList.sync({ force: true });

export default LiquidationList;
