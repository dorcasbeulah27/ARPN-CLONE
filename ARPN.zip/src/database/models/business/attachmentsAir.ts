import Database from '../../index';

// Import Sequelize and the sequelize instance
const { DataTypes } = require('sequelize');

// Define the Procurement model
const AttachmentsAir = Database.getConnection().define(
	'AttachmentsAir',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
			allowNull: false,
		},
		DOCNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FIELDNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
	},
	{
		tableName: 'ATTACHMENTSAIR', 
		timestamps: true, 
	},
);

// AttachmentsAir.sync({ force: true });
export default AttachmentsAir;
