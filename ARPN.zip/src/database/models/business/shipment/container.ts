import Database from '../../..';
import Procurement from '../procurement/procurement';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Shipment model
const Container = Database.getConnection().define(
	'Container',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: true,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		CONTAINERNO: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
        CONTAINERSIZE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		tableName: 'CONTAINERS', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

Container.belongsTo(Procurement, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});


// Container.sync({ force: true });
// Export the Shipment model
export default Container;
