import Database from '../../..';
import Procurement from '../procurement/procurement';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Shipment model
const Shipment = Database.getConnection().define(
	'Shipment',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: true,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		TENATIVESHIPMENTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SCANDOCSRECEIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		COMMERCIALINVOICENUMBER: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		COMMERCIALINVOICEDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		COMMERCIALINVOICEAMOUNT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		BLDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		BLNO: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		SCANNEDDOCUMENTSSHAREDTOIMPORTTEAMDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SCANNEDDOCUMENTSSHAREDTOIMPORTTEAM: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		IBDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		IBDNUMBER: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		SONCAPIPAPPLIEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SONCAPIPRECEIVEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SHIPMENTPLANNINGANDEXECUTIONMIRODATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SHIPMENTPLANNINGANDEXECUTIONMIRONO: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		MIROPOSTINGONSAP: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		FURTHERSHIPMENTS: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SHIPMENTPLANNINGANDEXECUTIONMODEOFPAYMENT: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		BLQTY: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		BLWEIGHT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		WEIGHTUSED: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		QTYUSED: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		VALUEUSED: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		SENDMAILTOBANKFORCLOSINGLC: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SENDMAILTOBANKFFORCLOSINGLCDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ORIGINALDOCSRECEIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		ORIGINALDOCSRECEIVEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ACTUALSHIPMENTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		EXPETAPORT: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SHIPPINGLINE: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		TERMINAL: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		VESSESLNAME: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		CONTAINERNO: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		CONTAINERSIZE: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		TOCHECKUPLOADEDINGOCOMET: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SHIPMENTPLANNINGANDEXECUTIONAGENT: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		SHIPMENTPLANNINGANDEXECUTIONDOCSTOFACTORY: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		ORIGINALDOCSSENTTOBANKORNOT: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SHIPMENTPLANNINGANDEXECUTIONLATESTSHIPMENTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		MAILTOINSURANCE: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		MAILTOINSURANCEDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		APPLIEDFORTRANSIRE: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		TRANSIRERECEIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		APPLIEDFORPAAR: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		PAARRECEIVEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		PAARSENTTOIMPORTTEAM: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		DEBITNOTEDATEFORINSURANCE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		DEBITNOTENOFORINSURANCE: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		DEBITNOTEPAYMENTCOMPLETEDFORINSURANCE: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		DEBITNOTEPAYMENTCOMPLETEDFORINSURANCEDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SONCAPIPAPPLIED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SONCAPIPRECEIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		APPLIEDFORPAARDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		PAARRECEIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		tableName: 'SHIPMENT', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

Shipment.belongsTo(Procurement, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});


// Shipment.sync({ force: true });
// Export the Shipment model
export default Shipment;
