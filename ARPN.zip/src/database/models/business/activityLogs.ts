import Database from '../../index';

// Import Sequelize and the sequelize instance
const { DataTypes } = require('sequelize');

// Define the Procurement model
const ActivityLogs = Database.getConnection().define(
	'ActivityLogs',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
			allowNull: false,
		},
		USERID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		SECTIONNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		DATA: {
			type: DataTypes.JSON,
			allowNull: true,
		},
	},
	{
		tableName: 'ACTIVITYLOGS', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

// ActivityLogs.sync({ force: true });
// Export the Procurement model
export default ActivityLogs;
