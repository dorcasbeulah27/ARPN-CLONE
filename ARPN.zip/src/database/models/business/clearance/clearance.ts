import Database from '../../..';
import Procurement from '../procurement/procurement';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Clearance model
const Clearance = Database.getConnection().define(
	'Clearance',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: true,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		DUTYASSESSMENT: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		DUTYASSESSMENTNO: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		MANIFESTNOBERTHNO: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		CNUMBER: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		ANUMBER: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		DUTYASSESMENTDOCSTOFACTORY: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		DUTYASSESMENTDOCSTOFACTORYDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		DUTYRECEIPTNEPZACOLLECTION: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		DUTYRECEIPTNEPZACOLLECTIONDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		CUSTOMRELEASE: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SHIPPINGLINECHARGES: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		SHIPPINGLINEDEMMURAGE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		FOU3: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		EXIT1: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SDO1: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		TDO: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		GATEOUT: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		FACTORYIN: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		FACTORYOFFLOADANDRETURNMIRODATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		FACTORYOFFLOADANDRETURNMIRONO: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		FACTORYOFFLOADANDRETURNMIRONODATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		FACTORYOUT: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		EMPTYRETURN: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		IM4059: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		ASSESSMENT: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		DUTYRECEIPT: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		CLEARANCE: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		DUTYAMOUNT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		FACTORYOFFLOADANDRETURNVAT: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		IM5900: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		IM5900AGENT: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		IM5900ASSESMENT: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		IM5900CLEARANCE: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		FACTORYOFFLOADINGANDRETURNAGENT: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		ECDRECEIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		ECDSUBMISSION: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		ECDACKNOWLEDGEMENT: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		AGENCYFEE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		DEMURRAGEONTRUCK: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		ECDANDINVOICEVAT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		CONTAINERDEPOSIT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		TERMINALREFUND: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		SHIPPINGLINEREFUND: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		CONTAINERDEPOSITREFUND: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		DNAMOUNT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		FINALPCACLOSURE: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		TRANSPORT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		FINALNAFDAC: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		TERMINALCHARGES: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		TERMINALSTORAGE: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		ADVANCE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		NAFDAC: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		SON: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		DUTYASSESSMENTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		FOU3DATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		EXIT1DATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SDO1DATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		TDODATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		GATEOUTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		FACTORYINDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		FACTORYOFFLOADANDRETURNMIROAPPLIED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		FACTORYOUTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		EMPTYRETURNDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		FINALPCACLOSUREDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		FINALNAFDACDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		tableName: 'CLEARANCE', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

Clearance.belongsTo(Procurement, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});
// Clearance.sync({ force: true });

// Export the Clearance model
export default Clearance;
