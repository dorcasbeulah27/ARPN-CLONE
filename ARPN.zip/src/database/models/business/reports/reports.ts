import Database from '../../..';
import Procurement from '../procurement/procurement';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Shipment model
const Reports = Database.getConnection().define(
	'Reports',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: true,
		},
		REPORTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		REPORTNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FIELDNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FIELDDESCRIPTION: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FIELDSEQUENCE: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		ACTIVE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
	},
	{
		tableName: 'REPORTS', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

// Reports.sync({ force: true });
// Export the Shipment model
export default Reports;
