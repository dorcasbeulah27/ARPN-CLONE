
import { DataTypes } from 'sequelize';
import Database from '../../..';
import BankMaster from './bankMaster';

const SOFRMaster = Database.getConnection().define(
	'SOFRMaster',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
        BANKID: {
            type: DataTypes.INTEGER, 
            allowNull: true,
            // references: {
            //     model: BankMaster,
            //     key: 'ID'
            // }
        },
		SOFRPERCENTAGE: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		STARTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ENDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
	},
	{
		timestamps: true,
		tableName: 'SOFRMASTER',
	},
);
SOFRMaster.belongsTo(BankMaster, { foreignKey: 'BANKID' });
BankMaster.hasMany(SOFRMaster, { foreignKey: 'BANKID' });

// SOFRMaster.sync({ force: true });

export default SOFRMaster;
