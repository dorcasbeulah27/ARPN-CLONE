import { DataTypes } from 'sequelize';
import Database from '../../..';
import BankMaster from './bankMaster';

const LCComissionMaster = Database.getConnection().define(
	'lcComissionMaster',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		BANKID: {
			type: DataTypes.INTEGER,
			allowNull: true,
			// references: {
			// 	model: BankMaster,
			// 	key: 'ID',
			// },
		},
		COMISSIONPERCENTAGE: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		STARTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ENDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
	},
	{
		timestamps: true,
		tableName: 'LCCOMISSIONMASTER',
	},
);
LCComissionMaster.belongsTo(BankMaster, { foreignKey: 'BANKID' });
BankMaster.hasMany(LCComissionMaster, { foreignKey: 'BANKID' });

// LCComissionMaster.sync({ force: true });

export default LCComissionMaster;
