import { DataTypes } from 'sequelize';
import Database from '../../..';


const testTable = Database.getConnection().define(
	'TEST_TABLE',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
        NAME:{
            type: DataTypes.STRING,
            allowNull: false,
        },
        EMAIL:{
            type: DataTypes.STRING,
            allowNull:false,
        },
        AGE:{
            type: DataTypes.INTEGER,
            allowNull:true,
        },
        OCCUPATION:{
            type: DataTypes.STRING,
            allowNull: true,
        },
    },
	{
		timestamps: true,
		tableName: 'TEST_TABLE',
	},
);


// testTable.sync({ force: true });

export default testTable;
