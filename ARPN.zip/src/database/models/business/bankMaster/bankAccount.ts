import { DataTypes } from 'sequelize';
import Database from '../../..';

const BankAccount = Database.getConnection().define(
	'BankAccount',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
		},
		METAID: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		METAURI: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		METATYPE: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		ACCOUNTID: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		GLACCOUNT: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		GLACCOUNTDESCRIPTION: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		ACCOUNTNUMBER: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		ACCOUNTCURRENCY: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		ACCOUNTSTATUS: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		ACCOUNTTYPE: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		BANKKEY: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		SWIFT: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		HOUSEBANKID: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		HOUSEBANKACCOUNT: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		COUNTRY: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		COMPANYCODE: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		COMPANYNAME: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		IBAN: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		createdAt: {
			type: DataTypes.DATE,
			defaultValue: DataTypes.NOW,
			allowNull: false,
		},
		updatedAt: {
			type: DataTypes.DATE,
			defaultValue: DataTypes.NOW,
			allowNull: false,
		},
	},
	{
		tableName: 'BANKACCOUNT',
		timestamps: true,
	},
);

// BankMaster.sync({ force: true });

export default BankAccount;
