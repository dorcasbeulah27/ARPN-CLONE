import { DataTypes } from 'sequelize';
import Database from '../../..';
import Procurement from '../procurement/procurement';

const BankMaster = Database.getConnection().define(
	'bankMaster',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true
		},
		BANKNAME: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		ODFL: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		STFFL: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		IIFFL: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		TOTALFL: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		ODFU: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		STFFU: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		IIFFU: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		NONOVERDUELC: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		LTL: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		TOTALFU: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		TOTAL: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		AVAILABLELINE: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		BANKIMAGE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		LCCOMMISSION: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: '0.00'
		},
		LCCOMMISSIONINCLUDINGVAT: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: '0.00'
		},

	},
	{
		timestamps: true,
		tableName: 'BANKMASTER',
	},
);

BankMaster.belongsTo(Procurement, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO'
})
// BankMaster.sync({ force: true });

export default BankMaster;
