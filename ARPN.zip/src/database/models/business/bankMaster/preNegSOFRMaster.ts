
import { DataTypes } from 'sequelize';
import Database from '../../..';
import BankMaster from './bankMaster';

const PRENEGSOFRMaster = Database.getConnection().define(
	'PRENEGSOFRMaster',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
        BANKID: {
            type: DataTypes.INTEGER, 
            allowNull: true,
            // references: {
            //     model: BankMaster,
            //     key: 'ID'
            // }
        },
		PRENEGSOFRPERCENTAGE: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		STARTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ENDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
	},
	{
		timestamps: true,
		tableName: 'PRENEGSOFRMaster',
	},
);

PRENEGSOFRMaster.belongsTo(BankMaster, {
    foreignKey: 'BANKID',
    as: 'BANKINFO'
});

// PRENEGSOFRMaster.sync({ force: true });

export default PRENEGSOFRMaster;
