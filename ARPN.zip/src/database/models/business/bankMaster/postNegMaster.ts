
import { DataTypes } from 'sequelize';
import Database from '../../..';
import BankMaster from './bankMaster';

const PostNegMaster = Database.getConnection().define(
	'postNegMaster',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
        BANKID: {
            type: DataTypes.INTEGER, 
            allowNull: true,
            // references: {
            //     model: BankMaster,
            //     key: 'ID'
            // }
        },
		POSTNEGPERCENTAGE: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		STARTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ENDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
	},
	{
		timestamps: true,
		tableName: 'POSTNEGMASTER',
	},
);
PostNegMaster.belongsTo(BankMaster, { foreignKey: 'BANKID' });
BankMaster.hasMany(PostNegMaster, { foreignKey: 'BANKID' });

// PostNegMaster.sync({ force: true });

export default PostNegMaster;
