import { DataTypes, Model } from 'sequelize';
import Database from '../../..';
import BankMaster from './bankMaster';

const PreNegMaster = Database.getConnection().define(
	'preNegMaster',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		BANKID: {
			type: DataTypes.INTEGER,
			allowNull: true,
			// references: {
			//     model: BankMaster,
			//     key: 'ID'
			// }
		},
		PRENEGPERCENTAGE: {
			type: DataTypes.FLOAT,
			allowNull: true,
		},
		STARTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ENDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
	},
	{
		timestamps: true,
		tableName: 'PRENEGMASTER',
	},
);

PreNegMaster.belongsTo(BankMaster, { foreignKey: 'BANKID' });
BankMaster.hasMany(PreNegMaster, { foreignKey: 'BANKID' });

// PreNegMaster.sync({ force: true });
export default PreNegMaster;
