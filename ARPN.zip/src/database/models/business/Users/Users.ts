import Database from '../../..';

const { Sequelize, DataTypes, Model } = require('sequelize');
const Users = Database.getConnection().define(
	'USERS',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		NAME: {
			type: DataTypes.STRING,
			allowNull: false,
		},
		// Role: {
		// 	type: DataTypes.STRING,
		// 	allowNull: false,
		// },
	},
	{
		tableName: 'USERS',
		timestamps: false, // Disable timestamps if not needed
	},
);
// Users.sync({ force: true });
export default Users;
