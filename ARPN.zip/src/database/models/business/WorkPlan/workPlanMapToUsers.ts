import Database from '../../..';
import Users from '../Users/Users';

const { Sequelize, DataTypes, Model } = require('sequelize');
const UsersWorkPlan = Database.getConnection().define(
	'WORKPLAN_USERS',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		SUPERVISOR: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: Users, // Reference to User model
				key: 'ID',
			},
		},
		JOBNAME: {
			type: DataTypes.STRING,
			allowNull: false,
		},
		STARTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ENDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		COSTOFWORK: {
			type: DataTypes.DECIMAL(10, 2),
			allowNull: false,
		},
		STATUS: {
			type: DataTypes.ENUM('ACTIVE', 'INACTIVE'),
			allowNull: false,
		},
	},
	{
		tableName: 'USERS_WORKPLAN',
		timestamps: false,
	},
);
Users.hasMany(UsersWorkPlan, {
	foreignKey: 'SUPERVISOR',
	as: 'workplans',
});
UsersWorkPlan.belongsTo(Users, {
	foreignKey: 'SUPERVISOR',
	as: 'supervisor',
});
// UsersWorkPlan.sync({ force: true });
export default UsersWorkPlan;
