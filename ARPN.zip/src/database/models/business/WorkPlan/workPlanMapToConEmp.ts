import Database from '../../..';
import Contractor from '../Contractors/contractors';
import Employee from '../Employees/employees';
import UsersWorkPlan from './workPlanMapToUsers';

const { Sequelize, DataTypes, Model } = require('sequelize');
const workplan_Emp_Contractor = Database.getConnection().define(
	'WORKPLAN_EMP_CONTRACTOR',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		WORKPLAN_ID: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: UsersWorkPlan,
				key: 'ID',
			},
		},
		EMP_ID: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: Employee,
				key: 'ID',
			},
		},
		CONTRACTOR_ID: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: Contractor,
				key: 'ID',
			},
		},
	},

	{
		tableName: 'WORKPLAN_EMP_CONTRACTOR',
		timestamps: false,
	},
);
UsersWorkPlan.hasMany(workplan_Emp_Contractor, {
	foreignKey: 'WORKPLAN_ID',
	as: 'workplanId',
});
workplan_Emp_Contractor.belongsTo(UsersWorkPlan, {
	foreignKey: 'WORKPLAN_ID',
	as: 'workplanId',
});
Employee.hasMany(workplan_Emp_Contractor, {
	foreignKey: 'EMP_ID',
	as: 'empId',
});
workplan_Emp_Contractor.belongsTo(Employee, {
	foreignKey: 'EMP_ID',
	as: 'empId',
});
Contractor.hasMany(workplan_Emp_Contractor, {
	foreignKey: 'CONTRACTOR_ID',
	as: 'contractorId',
});
workplan_Emp_Contractor.belongsTo(Contractor, {
	foreignKey: 'CONTRACTOR_ID',
	as: 'contractorId',
});
// workplan_Emp_Contractor.sync({ force: true });

export default workplan_Emp_Contractor;
