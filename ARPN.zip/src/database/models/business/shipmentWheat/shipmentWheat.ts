import Database from '../../..';
import ProcurementWheat from '../procurementWheat/procurement';
const { DataTypes } = require('sequelize');

const ShipmentWheat = Database.getConnection().define(
	'ShipmentWheat',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
			allowNull: false,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		SHIPMENTWINDOWEND: {
			type: DataTypes.DATE,
		},
		ATS: {
			type: DataTypes.STRING,
		},
		AGREEMENTDATE: {
			type: DataTypes.DATE,
		},
		SHIPMENTWINDOWSTART: {
			type: DataTypes.DATE,
		},
		ARRIVALMONTH: {
			type: DataTypes.STRING,
		},
		PORTOFLOADING: {
			type: DataTypes.STRING,
		},
		BLDATE: {
			type: DataTypes.DATE,
		},
		VESSELNAME: {
			type: DataTypes.STRING,
		},
		VESSELNUMBER: {
			type: DataTypes.STRING,
		},
		BLNO: {
			type: DataTypes.STRING,
		},
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		tableName: 'SHIPMENTAIR',
		timestamps: true,
	},
);

ShipmentWheat.belongsTo(ProcurementWheat, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});

// ShipmentWheat.sync({ force: true });

export default ShipmentWheat;
