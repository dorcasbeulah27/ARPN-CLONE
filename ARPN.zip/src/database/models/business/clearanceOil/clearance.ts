import Database from '../../..';
import Procurement from '../procurement/procurement';
import ProcurementOil from '../procurementOil/procurement';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Clearance model
const ClearanceOil = Database.getConnection().define(
	'ClearanceOil',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: true,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		APPLIEDFORTRANSIRE: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		TRANSIRERECEIVED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		TOCHECKIFNEPZAHASBEENAPPLIED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		TOCHECKTHEDRAFTTOBEMENTIONEDZERODUTY: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		ASSESSMENTDATE: {
			type: DataTypes.DATE,
			defaultValue: false,
		},
		ASSESSMENTNUMBER: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		DUTYNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		NPAAPPLIED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		NIMASAAPPLIED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		PORT: {
			type: DataTypes.TEXT,
			defaultValue: false,
		},
		TERMINALOFDISCHARGE: {
			type: DataTypes.TEXT,
			defaultValue: false,
		},
		BERTHNO: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		AGENT: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		SHIPMENTCOMPLETIONDATEATA: {
			type: DataTypes.DATE,
			defaultValue: false,
		},
		DEMURRAGE: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		ECDRECEIVED: {
			type: DataTypes.DATE,
			defaultValue: false,
		},
		ECDSUBMISSION: {
			type: DataTypes.DATE,
			defaultValue: false,
		},
		ECDACKNOWLEDGEMENT: {
			type: DataTypes.DATE,
			defaultValue: false,
		},
		FOFSA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		INTRESTCALCULATION: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		ARMEDGAURDS: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		DEMURRAGEINNCURED: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		SECUIRTYCHARGES: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		NPA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		NPAINNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		NIMISAIMPORTLEVY: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		NIMISASEAPROTECTIONONLEVY: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		TERMINALCHARGES: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		TERMINALCHARGESINNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		ADJUSTMENT: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		ADJUSTMENTINNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		HARBOURANDPILOTHANDINGCHARGES: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		FOREIGNNATIONALIMMIGRATIONINNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		HANDINGCHARGESINAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		OTHERCHARGES: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		SCLSURVEYORCHARGESINNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		DISCHARGEHOSERENTALCHARGESINNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		DISCHARGEPIPESRENTALCHARGESINNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		OTHERMISCINNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		OTHEREXPENCES: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		OTHEREXPENCESINNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		CONTINGENTDEPOSIT: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		DOCUMENTS: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		SRNO: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		IM4059: {
			type: DataTypes.DECIMAL(17, 2),
			defaultValue: false,
		},
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		tableName: 'CLEARANCEOIL', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

ClearanceOil.belongsTo(ProcurementOil, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});
// ClearanceOil.sync({ force: true });

// Export the Clearance model
export default ClearanceOil;
