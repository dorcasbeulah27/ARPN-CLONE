import Database from '../../..';
import Procurement from '../procurement/procurement';
import ProcurementOil from '../procurementOil/procurement';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Clearance model
const ClearanceOil = Database.getConnection().define(
	'ClearanceOil',
	{
		ID: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        IM4059: {
            type: DataTypes.TEXT,
        },
        SRNO: {
            type: DataTypes.TEXT,
        },
        DOCUMENTS: {
            type: DataTypes.TEXT,
        },
        CONTINGENTDEPOSIT: {
            type: DataTypes.DECIMAL(17, 2),
        },
        OTHEREXPENCESINNAIRA: {
            type: DataTypes.DECIMAL(17, 2),
        },
        OTHEREXPENCES: {
            type: DataTypes.DECIMAL(17, 2),
        },
        OTHERMISCINNAIRA: {
            type: DataTypes.DECIMAL(17, 2),
        },
        DISCHARGEPIPESRENTALCHARGESINNAIRA: {
            type: DataTypes.DECIMAL(17, 2),
        },
        DISCHARGEHOSERENTALCHARGESINNAIRA: {
            type: DataTypes.DECIMAL(17, 2),
        },
        SCLSURVEYORCHARGESINNAIRA: {
            type: DataTypes.DECIMAL(17, 2),
        },
        OTHERCHARGES: {
            type: DataTypes.TEXT,
        },
        HANDINGCHARGESINAIRA: {
            type: DataTypes.DECIMAL(17, 2),
        },
        FOREIGNNATIONALIMMIGRATIONINNAIRA: {
            type: DataTypes.DECIMAL(17, 2),
        },
        HARBOURANDPILOTHANDINGCHARGES: {
            type: DataTypes.DECIMAL(17, 2),
        },
        ADJUSTMENTINNAIRA: {
            type: DataTypes.DECIMAL(17, 2),
        },
        ADJUSTMENT: {
            type: DataTypes.TEXT,
        },
        TERMINALCHARGESINNAIRA: {
            type: DataTypes.DECIMAL(17, 2),
        },
        TERMINALCHARGES: {
            type: DataTypes.TEXT,
        },
        NIMISASEAPROTECTIONONLEVY: {
            type: DataTypes.TEXT,
        },
        NIMISAIMPORTLEVY: {
            type: DataTypes.TEXT,
        },
        NPAINNAIRA: {
            type: DataTypes.DECIMAL(17, 2),
        },
        NPA: {
            type: DataTypes.TEXT,
        },
        SECUIRTYCHARGES: {
            type: DataTypes.TEXT,
        },
        DEMURRAGEINNCURED: {
            type: DataTypes.TEXT,
        },
        ARMEDGAURDS: {
            type: DataTypes.TEXT,
        },
        INTRESTCALCULATION: {
            type: DataTypes.TEXT,
        },
        FOFSA: {
            type: DataTypes.TEXT,
        },
        ECDACKNOWLEDGEMENT: {
            type: DataTypes.TEXT,
        },
        ECDSUBMISSION: {
            type: DataTypes.TEXT,
        },
        ECDRECEIVED: {
            type: DataTypes.TEXT,
        },
        DEMURRAGE: {
            type: DataTypes.TEXT,
        },
        SHIPMENTCOMPLETIONDATEATA: {
            type: DataTypes.DATE,
        },
        AGENT: {
            type: DataTypes.TEXT,
        },
        BERTHNO: {
            type: DataTypes.TEXT,
        },
        TERMINALOFDISCHARGE: {
            type: DataTypes.TEXT,
        },
        PORT: {
            type: DataTypes.TEXT,
        },
        NIMASAAPPLIED: {
            type: DataTypes.TEXT,
        },
        NPAAPPLIED: {
            type: DataTypes.TEXT,
        },
        DUTYNAIRA: {
            type: DataTypes.DECIMAL(17, 2),
        },
        ASSESSMENTNUMBER: {
            type: DataTypes.TEXT,
        },
        ASSESSMENTDATE: {
            type: DataTypes.DATE,
        },
        TOCHECKTHEDRAFTTOBEMENTIONEDZERODUTY: {
            type: DataTypes.TEXT,
        },
        TOCHECKIFNEPZAHASBEENAPPLIED: {
            type: DataTypes.TEXT,
        },
        TRANSIRERECEIVED: {
            type: DataTypes.TEXT,
        },
        APPLIEDFORTRANSIRE: {
            type: DataTypes.TEXT,
        },
        // TRANSIREATTACHMENT: {
        //     type: DataTypes.TEXT,
        // },
        // NEPZAATTACHMENTS: {
        //     type: DataTypes.TEXT,
        // },
        // DUTYASSESMENTATTACHMENT: {
        //     type: DataTypes.TEXT,
        // },
        // NPAANDNIMASAATTACHMENT: {
        //     type: DataTypes.TEXT,
        // },
        // ECDATTACHMENT: {
        //     type: DataTypes.TEXT,
        // },
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		tableName: 'CLEARANCEOIL', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

ClearanceOil.belongsTo(ProcurementOil, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});
// ClearanceOil.sync({ force: true });

// Export the Clearance model
export default ClearanceOil;
