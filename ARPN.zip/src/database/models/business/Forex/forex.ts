import { DataTypes } from 'sequelize';
import Database from '../../..';

const Forex = Database.getConnection().define(
	'Forex',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		METAID: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		METAURI: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		METATYPE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		EXCHANGERATETYPE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		SOURCECURRENCY: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		TARGETCURRENCY: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		VALIDITYSTARTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		EXCHANGERATE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		FROMFACTOR: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		TOFACTOR: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
	},
	{
		timestamps: true,
		tableName: 'FOREX',
	},
);

// Forex.sync({ force: true });

export default Forex;
