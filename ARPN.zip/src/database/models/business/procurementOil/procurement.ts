import Database from '../../..';

// Import Sequelize and the sequelize instance
const { DataTypes } = require('sequelize');

// Define the Procurement model
const ProcurementOil = Database.getConnection().define(
	'ProcurementOil',
	{
		ID: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        INFINITYINVOICEVALUE: {
            type: DataTypes.DECIMAL(17, 2),
        },
        SUPPLIERINVOICEVALUE: {
            type: DataTypes.DECIMAL(17, 2),
        },
        BLDATE: {
            type: DataTypes.DATE,
        },
        NORDATE: {
            type: DataTypes.DATE,
        },
        SHIPMENTMONTH: {
            type: DataTypes.DATE,
        },
        PORTOFLOADING: {
            type: DataTypes.TEXT,
        },
        ATS: {
            type: DataTypes.DATE,
        },
        SHIPMENTWINDOWEND: {
            type: DataTypes.DATE,
        },
        BLNO: {
            type: DataTypes.TEXT,
        },
        SHIPMENTWINDOWSTART: {
            type: DataTypes.DATE,
        },
        VESSELNAME: {
            type: DataTypes.TEXT,
        },
        AGREEMENTDATE: {
            type: DataTypes.DATE,
        },
        PFINO: {
            type: DataTypes.TEXT,
        },
        FACTORY: {
            type: DataTypes.TEXT,
        },
        PFIDATE: {
            type: DataTypes.DATE,
        },
        TOTALVALUE: {
            type: DataTypes.DECIMAL(17, 2),
        },
        UOM: {
            type: DataTypes.TEXT,
        },
        QTY: {
            type: DataTypes.DECIMAL(17, 2),
        },
        CNF: {
            type: DataTypes.DECIMAL(17, 2),
        },
        FREIGHT: {
            type: DataTypes.DECIMAL(17, 2),
        },
        FOB: {
            type: DataTypes.DECIMAL(17, 2),
        },
        PONO: {
            type: DataTypes.TEXT,
        },
        COS: {
            type: DataTypes.TEXT,
        },
        COO: {
            type: DataTypes.TEXT,
        },
        SUPPLIERNAME: {
            type: DataTypes.TEXT,
        },
        VESSELNO: {
            type: DataTypes.DECIMAL(17, 2),
        },
        PFIATTACHMENT: {
            type: DataTypes.TEXT,
        },
        SHIPMENTPLANNINGANDEXECUTIONATTACHMENT: {
            type: DataTypes.TEXT,
        },
        POATTACHMENT: {
            type: DataTypes.TEXT,
        },
		SEQUENCE: {
			type: DataTypes.INTEGER,
			defaultValue: 1,
		},
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		tableName: 'PROCUREMENTOIL', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

// ProcurementOil.sync({ force: true });	

export default ProcurementOil;
