import { DataTypes } from 'sequelize';
import Database from '../../..';
import ProcurementOil from './procurement';

const PfiitemsOil = Database.getConnection().define(
	'pfiItemsOil',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		PFINO: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		ITEMCODE: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		ITEMDESCRIPTION: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		ITEMQUANTITY: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		ITEMHSCODE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		UOM: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		MOREUOM: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		PONO: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		PFIVALUE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
	},
	{
		timestamps: true,
		tableName: 'PFIITEMSOIL',
	},
);

PfiitemsOil.belongsTo(ProcurementOil, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});

// PfiitemsOil.sync({ force: true });

export default PfiitemsOil;
