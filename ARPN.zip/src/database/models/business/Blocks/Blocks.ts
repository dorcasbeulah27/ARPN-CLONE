import Database from '../../..';
import Geolocation from '../Geolocation/Geolocation';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Shipment model
const Blocks = Database.getConnection().define(
	'BLOCKS',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
		},
		BLOCK_NAME: {
			type: DataTypes.STRING,
			allowNull: false,
		},
	},
	{
		tableName: 'BLOCKS',
		timestamps: false,
	},
);

// Blocks.sync({ force: true });
export default Blocks;
