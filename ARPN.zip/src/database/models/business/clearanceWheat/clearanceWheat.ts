import Database from '../../..';
import ProcurementWheat from '../procurementWheat/procurement';

const { DataTypes } = require('sequelize');

const ClearanceWheat = Database.getConnection().define(
	'ClearanceWheat',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		ASSESMENTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ASSESMENTNUMBER: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		DUTYNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		NPAAPPLIED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		NPARECEIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		NIMASAAPPLIED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		NIMASARECEIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		ABUJAAPPROVALAPPLIED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		ABUJAAPPROVALRECEIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		ABUJAAPPROVALCHANGES: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		NPAAPPLIEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		NPARECEIVEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		NIMASAAPPLIEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		NIMASARECEIVEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ABUJAAPPROVALAPPLIEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ABUJAAPPROVALRECEIVEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ACTUALTIMEOFSAILING: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ACTUALTIMEOFARRIVALAPAPA: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ACTUALTIMEOFARRIVALPHC: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		RECEIVEDQUANTITYAPAPAMT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		RECEIVEDQTYPHCMT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		TOTALRECEIVEDQTYMT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		TOTALVALUE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		NOR: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		SHIPMENTCOMPLETION: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		PORT: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		AGENT: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		DEMURRAGEDAY: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		DEMURRAGEDESPATCH: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		DEMURRAGEDESPATCHAPAPA: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		DEMURRAGEDESPATCHPHC: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		GAFTAAPPADOLLAR: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		GAFTAPHCDOLLAR: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		GAFTAREFUNDSDOLLAR: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		NAQSNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		MANIFESTNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		NPADOLLAR: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		NPANAIRADOLLAR: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		NIMASAIMPORTLEVY: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		NIMASASEAPROTECTIONLEVY: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		TERMINALCHARGES: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		TERMINALCHARGESNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		AGENCYFEE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		NAFDACCHARGES: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		DISCHARGEHOLDANDSEAL: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		PRIORITYBERTHINGDOLLAR: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		FINALADJUSTMENTDOLLAR: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		FINALADJUSTMENTNAIRADOLLAR: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		NETADJUSTMENTAEAF: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		MARITIMEUNIONCHARGES: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		OTHEREXPENSESDOLLAREURO: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		OTHEREXPENSESNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		SURVEYORCHARGESNAIRA: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		CONTINGENTDEPOSITDOLLARNPAANDPTOL: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		RELEASE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		EXIT: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ECDRECEIVEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ECDSUBMISSIONDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ECDACKNOWLEDGEMENT: {
			type: DataTypes.DATE,
			allowNull: true,
		},
	},
	{
		tableName: 'CLEARANCEWHEAT',
		timestamps: false, // Assuming you don't want createdAt and updatedAt fields
	},
);

ClearanceWheat.belongsTo(ProcurementWheat, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});

// ClearanceWheat.sync({ force: true });

export default ClearanceWheat;
