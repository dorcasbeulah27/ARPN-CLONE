import Database from '../../index';

// Import Sequelize and the sequelize instance
const { DataTypes } = require('sequelize');

// Define the Procurement model
const Attachments = Database.getConnection().define(
	'Attachments',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
			allowNull: false,
		},
		DOCNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FIELDNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
	},
	{
		tableName: 'ATTACHMENTS', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

// Attachments.sync({ force: true });
// Export the Procurement model
export default Attachments;
