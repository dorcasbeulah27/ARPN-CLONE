import Database from '../../..';
import Courses from '../coursesTable/courses';
import Students from './students';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Shipment model
const StudentMapToCourse = Database.getConnection().define(
	'StudentMapToCourse',
	{
		id: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
		},
		studentId: {
			type: DataTypes.INTEGER,
			references: {
				model: Students,
				key: 'id',
			},
			allowNull: false,
		},
		courseId: {
			type: DataTypes.INTEGER,
			references: {
				model: Courses,
				key: 'id',
			},
			allowNull: false,
		},
	},
	{
		tableName: 'STUDENTMAPTOCOURSES',
		timestamps: false,
	},
);
StudentMapToCourse.belongsTo(Students, {
	foreignKey: 'studentId',
	as: 'student',
});
StudentMapToCourse.belongsTo(Courses, { foreignKey: 'courseId', as: 'course' });

// StudentMapToCourse.sync({ force: true });
// Export the Shipment model
export default StudentMapToCourse;
