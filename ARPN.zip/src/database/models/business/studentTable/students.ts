import Database from '../../..';
import studentController from '../../../../components/StudentController/studentController';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Shipment model
const Students = Database.getConnection().define(
	'Students',
	{
		id: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
		},
		studentName: {
			type: DataTypes.STRING,
			allowNull: false,
		},
		REGNO: {
			type: DataTypes.STRING,
			allowNull: false,
		},
	},
	{
		tableName: 'STUDENTS',
		timestamps: false,
	},
);

// Students.sync({ force: true });
// Export the Shipment model
export default Students;
