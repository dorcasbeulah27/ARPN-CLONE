import Database from '../../..';
import Teachers from '../teachersTable/teachers';
import Students from './students';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Shipment model
const StudentMapToTeacher = Database.getConnection().define(
	'StudentMapToTeacher',
	{
		id: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
		},
		studentId: {
			type: DataTypes.INTEGER,
			references: {
				model: Students,
				key: 'id',
			},
			allowNull: false,
		},
		teacherId: {
			type: DataTypes.INTEGER,
			references: {
				model: Teachers,
				key: 'id',
			},
			allowNull: false,
		},
	},
	{
		tableName: 'STUDENTMAPTOTEACHER',
		timestamps: false,
	},
);
StudentMapToTeacher.belongsTo(Students, {
	foreignKey: 'studentId',
	as: 'student',
});
StudentMapToTeacher.belongsTo(Teachers, {
	foreignKey: 'teacherId',
	as: 'teacher',
});
// StudentMapToTeacher.sync({ force: true });
// Export the Shipment model
export default StudentMapToTeacher;
