import Database from '../../..';

import { DataTypes } from 'sequelize';

const Payment = Database.getConnection().define(
	'Payment',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
			allowNull: false,
		},
		PFINO: {
			type: DataTypes.TEXT,
		},
		DATE: {
			type: DataTypes.DATE,
		},
		BENEFICIARYNAME: {
			type: DataTypes.TEXT,
		},
		AMOUNT: {
			type: DataTypes.DECIMAL,
		},
		AMOUNTATTACHEMENT: {
			type: DataTypes.TEXT,
		},
		CURRENCY: {
			type: DataTypes.TEXT,
		},
		BANK: {
			type: DataTypes.TEXT,
		},
		ACCOUNTNUMBER: {
			type: DataTypes.INTEGER,
		},
		DEBIT: {
			type: DataTypes.TEXT,
		},
		STATUS: {
			type: DataTypes.BOOLEAN,
			defaultValue: false
		},
		PURPOSE: {
			type: DataTypes.TEXT,
		},
		PONO: {
			type: DataTypes.TEXT,
		},
		REMARKS: {
			type: DataTypes.TEXT,
		},
		REMARKSATTACHMENT: {
			type: DataTypes.TEXT,
		},
	},
	{
		tableName: 'PAYMENT', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

// Payment.sync({ force: true });

export default Payment;
