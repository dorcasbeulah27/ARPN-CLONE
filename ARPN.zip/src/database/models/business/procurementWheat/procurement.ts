import Database from '../../..';

// Import Sequelize and the sequelize instance
const { DataTypes } = require('sequelize');

// Define the Procurement model
const ProcurementWheat = Database.getConnection().define(
	'ProcurementWheat',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
			allowNull: false,
		},
		PFINO: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		PONO: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FACTORY: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		ARRIVALMONTH: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		PORTOFLOADING: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		BLNO: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		BLDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		VESSELNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		VESSELNUMBER: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		AGREEMENTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		ATS: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SHIPMENTWINDOWEND: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SHIPMENTWINDOWSTART: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		TOTALVALUE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		TOTALORDEREDQTYMT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		ORDEREDQTYAPAPAMT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		ORDEREDQTYPHCMT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		CNFMT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		FREIGHTMT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		FOBMT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		PROTEINPERCENT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		PROTEINLEVEL: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		ORIGIN: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		SUPPLIER: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		SEQUENCE: {
			type: DataTypes.INTEGER,
			defaultValue: 1,
		},
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		tableName: 'PROCUREMENTWHEAT', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

// ProcurementWheat.sync({ force: true });

export default ProcurementWheat;
