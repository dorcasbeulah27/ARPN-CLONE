import Database from '../../..';

// Import Sequelize and the sequelize instance
const { DataTypes } = require('sequelize');

// Define the Procurement model
const ProcurementAir = Database.getConnection().define(
	'ProcurementAir',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
			allowNull: false,
		},
		PFINO: {
			type: DataTypes.TEXT,
		},
		ITEMTYPE: {
			type: DataTypes.TEXT,
		},
		ORDERPLACEDBY: {
			type: DataTypes.TEXT,
		},
		PICKUPLOCATION: {
			type: DataTypes.TEXT,
		},
		DROPLOCATION: {
			type: DataTypes.TEXT,
		},
		OPERATIONS: {
			type: DataTypes.TEXT,
		},
		PONO: {
			type: DataTypes.TEXT,
		},
		BOOKINGDATE: {
			type: DataTypes.DATE,
		},
		SUPPLIERNAME: {
			type: DataTypes.TEXT,
		},
		SUBJECTOFMAIL: {
			type: DataTypes.TEXT,
		},
		ITEMNAME: {
			type: DataTypes.TEXT,
		},
		SHIPMENTTYPE: {
			type: DataTypes.TEXT,
		},
		TOTALVALUE: {
			type: DataTypes.DECIMAL,
		},
		// PAYMENTRECEIPT: {
		// 	type: DataTypes.TEXT,
		// },
		SEQUENCE: {
			type: DataTypes.INTEGER,
			defaultValue: 1,
		},
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		tableName: 'PROCUREMENTAIR', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

// ProcurementAir.sync({ force: true });

export default ProcurementAir;
