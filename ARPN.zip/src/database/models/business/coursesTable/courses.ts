import Database from '../../..';
import courseMapToTeacher from './courseMapToTeacher';

const { DataTypes } = require('sequelize');

const Courses = Database.getConnection().define(
	'Courses',
	{
		id: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
		},
		courseName: {
			type: DataTypes.STRING,
			allowNull: false,
		},
	},
	{
		tableName: 'COURSES',
		timestamps: false,
	},
);

// Courses.sync({ force: true });
export default Courses;
