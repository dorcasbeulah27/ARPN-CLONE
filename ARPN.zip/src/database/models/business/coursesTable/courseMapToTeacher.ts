import Database from '../../..';
import Teachers from '../teachersTable/teachers';
import Courses from './courses';

const { DataTypes } = require('sequelize');

const courseMapToTeacher = Database.getConnection().define(
	'courseMapToTeacher',
	{
		id: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
		},
		courseId: {
			type: DataTypes.INTEGER,
			references: {
				model: Courses,
				key: 'id',
			},
			allowNull: false,
		},
		TeacherId: {
			type: DataTypes.INTEGER,
			references: {
				model: Teachers,
				key: 'id',
			},
			allowNull: false,
		},
	},
	{
		tableName: 'COURSEMAPTOTEACHER',
		timestamps: false,
	},
);
courseMapToTeacher.belongsTo(Courses, { foreignKey: 'courseId', as: 'course' });
courseMapToTeacher.belongsTo(Teachers, {
	foreignKey: 'TeacherId',
	as: 'teacher',
});
// courseMapToTeacher.sync({ force: true });
export default courseMapToTeacher;
