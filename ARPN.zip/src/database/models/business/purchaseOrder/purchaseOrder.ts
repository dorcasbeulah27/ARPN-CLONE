import { DataTypes } from 'sequelize';
import Database from '../../..';

const PurchaseOrder = Database.getConnection().define(
	'purchaseOrder',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		STATUS: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		FACTORY: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		DEBIT: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		ORDERTYPE: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		PODATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		PONO: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		HSCODE: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		ITEMCODE: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		QUANTITY: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		SHORTTEXT: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		CURRENCY: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		VENDOR: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		REMARKS: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
	},
	{
		timestamps: true,
		tableName: 'PURCHASEORDER',
	},
);

// PurchaseOrder.sync({ force: true });

export default PurchaseOrder;
