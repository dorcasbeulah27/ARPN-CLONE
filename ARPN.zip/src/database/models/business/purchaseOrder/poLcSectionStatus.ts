import { DataTypes } from 'sequelize';
import Database from '../../..';

const Polcsectionstatus = Database.getConnection().define(
	'POLCSECTIONSTATUS',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		OUID: DataTypes.INTEGER,
		PROCUREMENTID: DataTypes.INTEGER,
		PROCUREMENTSEQUENCE: DataTypes.INTEGER,
		LCMAINID: DataTypes.INTEGER,
		SECTIONSEQUENCE: DataTypes.INTEGER,
		FORMID: DataTypes.INTEGER,
		FORMMNO: DataTypes.TEXT,
		SECTIONAME: DataTypes.TEXT,
		STATUS: DataTypes.TEXT,
		ACTIVE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		createdAt: {
			type: DataTypes.DATE,
			allowNull: false,
		},
		updatedAt: {
			type: DataTypes.DATE,
			allowNull: false,
		},
	},
	{
		tableName: 'POLCSECTIONSTATUS', // specify the table name if different from the model name
	},
);

// Polcsectionstatus.sync({ force: true });
export default Polcsectionstatus;
