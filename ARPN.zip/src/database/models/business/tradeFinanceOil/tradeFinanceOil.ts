import Database from '../../..';
import Procurement from '../procurementOil/procurement';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the TRADEFINANCE model
const TradefinanceOil = Database.getConnection().define(
	'TRADEFINANCEOIL',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		INSURANCERATE: {
			type: DataTypes.DECIMAL(17, 2),
		},
	},
	{
		tableName: 'TRADEFINANCEOIL', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

TradefinanceOil.belongsTo(Procurement, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});

// TradefinanceOil.sync({ force: true });
// Export the TRADEFINANCE model
export default TradefinanceOil;
