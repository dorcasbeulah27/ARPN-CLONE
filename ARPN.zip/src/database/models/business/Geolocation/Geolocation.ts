import Database from '../../..';
import Blocks from '../Blocks/Blocks';
import Sectors from '../Sector/Sector';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Shipment model
const Geolocation = Database.getConnection().define(
	'Geolocation',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
		},
		BLOCK_ID: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: Blocks,
				key: 'ID',
			},
		},

		LATITUDE: {
			type: DataTypes.DECIMAL,
			allowNull: false,
		},
		LONGITUDE: {
			type: DataTypes.DECIMAL,
			allowNull: false,
		},
		SECTOR_ID: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: Sectors,
				key: 'ID',
			},
		},
	},
	{
		tableName: 'GEOLOCATION',
		timestamps: false,
	},
);

Geolocation.belongsTo(Blocks, {
	foreignKey: 'BLOCK_ID',
	as: 'blockInfo',
});
Geolocation.belongsTo(Sectors, {
	foreignKey: 'SECTOR_ID',
	as: 'sectorInfo',
});

Blocks.hasMany(Geolocation, { foreignKey: 'BLOCK_ID', as: 'geolocations' });
Sectors.hasMany(Geolocation, {
	foreignKey: 'SECTOR_ID',
	as: 'sectorGeolocations',
});
// Geolocation.sync({ force: true });
// Export the Shipment model
export default Geolocation;
