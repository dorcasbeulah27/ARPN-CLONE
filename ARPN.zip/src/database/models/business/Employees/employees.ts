import Database from '../../..';
import Contractor from '../Contractors/contractors';

const { Sequelize, DataTypes, Model } = require('sequelize');
const Employee = Database.getConnection().define(
	'EMPLOYEES',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		NAME: {
			type: DataTypes.STRING,
			allowNull: false,
		},
		STATUS: {
			type: DataTypes.ENUM('AVAILABLE', 'UNAVAILABLE'),
			allowNull: false,
		},
		CONTRACTORID: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: Contractor, // Reference to Contractor model
				key: 'ID',
			},
		},
	},
	{
		tableName: 'EMPLOYEES',
		timestamps: false,
	},
);

Contractor.hasMany(Employee, {
	foreignKey: 'CONTRACTORID',
	as: 'contractInfo',
});
Employee.belongsTo(Contractor, {
	foreignKey: 'CONTRACTORID',
	as: 'contractInfo',
});
// Employee.sync({ force: true });
export default Employee;
