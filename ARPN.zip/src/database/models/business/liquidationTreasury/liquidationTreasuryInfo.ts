import { DataTypes } from 'sequelize';
import Database from '../../..';
import Procurement from '../procurement/procurement';

const LiquidationTreasuryInfo = Database.getConnection().define(
    'LiquidationTreasuryInfo',
    {
        
        ID: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
            allowNull: false,
        },
        SELECTEDDATE: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        LIQUIDATIONAMOUNT1: {
            type: DataTypes.DECIMAL(17, 2),
            allowNull: true,
        },
        SOURCEOFFUNDS: {
            type: DataTypes.STRING(500),
            allowNull: true,
        },
        EXCHANGERATE: {
            type: DataTypes.DECIMAL(17, 2),
            allowNull: true,
        },
        BANKLIST: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
        },
		BANKNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},

    },
    {
        timestamps: true,
        tableName: 'LIQUIDATIONTREASURYINFO',
    },
);

LiquidationTreasuryInfo.belongsTo(Procurement, {
    foreignKey: 'PROCUREMENTID',
    as: 'PROCUREMENTINFO'
});

// LiquidationTreasuryInfo.sync({ force: true });

export default LiquidationTreasuryInfo;
