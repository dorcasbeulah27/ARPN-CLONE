import { DataTypes } from 'sequelize';
import Database from '../../..';
import Procurement from '../procurement/procurement';

const LiquidationTreasuryPayment = Database.getConnection().define(
    'LiquidationTreasuryPayment',
    {
        ID: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
            allowNull: false,
        },
        MODEOFPAYMENT: {
            type: DataTypes.STRING(500),
            allowNull: true,
        },
        BANKNAME: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        ISPAYMENTDONE : {
            type: DataTypes.BOOLEAN,
            allowNull: true,
        }, 
         ISLIQUIDATIONDONE : {
            type: DataTypes.BOOLEAN,
            allowNull: true,
        },
        PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},

    },
    {
        timestamps: true,
        tableName: 'LIQUIDATIONTREASURYPAYMENT',
    },
);

LiquidationTreasuryPayment.belongsTo(Procurement, {
    foreignKey: 'PROCUREMENTID',
    as: 'PROCUREMENTINFO'
});

// LiquidationTreasuryPayment.sync({ force: true });

export default LiquidationTreasuryPayment;
