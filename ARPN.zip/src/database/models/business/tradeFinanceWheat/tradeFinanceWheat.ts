import Database from '../../..';
import ProcurementWheat from '../procurementWheat/procurement';

// Import Sequelize and the sequelize instance
const { DataTypes } = require('sequelize');

// Define the Procurement model
const TradeFinanceWheat = Database.getConnection().define(
	'TradeFinanceWheat',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		INSURANCERATE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		PFIVERIFIED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		FORMMNO: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FORMMSENTFORVALIDATION: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FORMMSTATUS: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		BANUMBER: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		HSCODE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		PFIVERIFIEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		FORMMSENTFORVALIDATIONDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		LCBANK: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		LCNUMBER: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		LCINVOICEAMOUNT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		PAARAPPLIED: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		PAARRECEIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
	},
	{
		tableName: 'TRADEFINANCEWHEAT',
		timestamps: false, // Assuming you don't want createdAt and updatedAt fields
	},
);

TradeFinanceWheat.belongsTo(ProcurementWheat, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});

// TradeFinanceWheatModel.sync({ force: true });

export default TradeFinanceWheat;
