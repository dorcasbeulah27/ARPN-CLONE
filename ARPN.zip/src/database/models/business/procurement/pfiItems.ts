import { DataTypes } from 'sequelize';
import Database from '../../..';
import Procurement from './procurement';

const Pfiitems = Database.getConnection().define(
	'pfiItems',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		PFINO: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		ITEMCODE: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		ITEMDESCRIPTION: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		ITEMQUANTITY: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		ITEMHSCODE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		UOM: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		MOREUOM: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		PONO: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		PFIVALUE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
	},
	{
		timestamps: true,
		tableName: 'PFIITEMS',
	},
);

Pfiitems.belongsTo(Procurement, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});

// Pfiitems.sync({ force: true });

export default Pfiitems;
