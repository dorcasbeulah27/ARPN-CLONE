import Database from '../../..';
import LC from '../ttlc/lc';

// Import Sequelize and the sequelize instance
const { DataTypes } = require('sequelize');


// Define the Procurement model
const Procurement = Database.getConnection().define(
	'Procurement',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
			allowNull: false,
		},
		PONO: {
			type: DataTypes.TEXT,
		},
		SEQUENCE: {
			type: DataTypes.INTEGER,
			defaultValue : 1
		},
		// POATTACHMENT: {
		//     type: DataTypes.STRING // Assuming ATTACHMENT is a string (file path or URL)
		// },
		PFINO: {
			type: DataTypes.TEXT,
		},
		PFIDATE: {
			type: DataTypes.DATE,
		},
		PFIAMOUNT: {
			type: DataTypes.DECIMAL(17, 2),
		},
		FOB: {
			type: DataTypes.DECIMAL(17, 2),
		},
		FREIGHT: {
			type: DataTypes.DECIMAL(17, 2),
		},
		CURRENCY: {
			type: DataTypes.STRING, // Assuming COMBO is represented as a string (e.g., dropdown value)
		},
		CFR: {
			type: DataTypes.DECIMAL(17, 2),
		},
		PFIMODEOFPAYMENT: {
			type: DataTypes.STRING, // Assuming COMBO is represented as a string
		},
		PAYMENTTERMS: {
			type: DataTypes.STRING, // Assuming COMBO is represented as a string
		},
		FACTORY: {
			type: DataTypes.STRING, // Assuming COMBO is represented as a string
		},
		MONTH: {
			type: DataTypes.DATE,
		},
		SUPPLIERNAME: {
			type: DataTypes.TEXT,
		},
		TYPEOFMATERIAL: {
			type: DataTypes.TEXT,
		},
		PORTOFDISHACRGE: {
			type: DataTypes.TEXT,
		},
		PORTOFLOADING: {
			type: DataTypes.TEXT,
		},
		APPROXWEIGHTOFSHIPMENT: {
			type: DataTypes.DECIMAL(17, 2),
		},
		MAILIDOFSUPPLIER: {
			type: DataTypes.TEXT,
		},
		PFIHSCODE: {
			type: DataTypes.TEXT,
		},
		PHONENOOFSUPPLIER: {
			type: DataTypes.TEXT,
		},
		SUPPLIERBANKDETAILS: {
			type: DataTypes.TEXT,
		},
		COO: {
			type: DataTypes.TEXT,
		},
		COS: {
			type: DataTypes.TEXT,
		},
		PODATE: {
			type: DataTypes.DATE,
		},

		RMCONSUMPTIONNAME: {
			type: DataTypes.TEXT,
		},
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		ISPAYMENTDONE: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		tableName: 'PROCUREMENT', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);


// Procurement.sync({ force: true });
// Export the Procurement model
export default Procurement;
