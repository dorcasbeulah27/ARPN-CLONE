import { DataTypes } from 'sequelize';
import Database from '../../..';
import Procurement from './procurement';

const PoItems = Database.getConnection().define(
	'PoItems',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		PFINO: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		ITEMCODE: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		ITEMDESCRIPTION: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		ITEMQUANTITY: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		UOM: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		PONO: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
	},
	{
		timestamps: true,
		tableName: 'POITEMS',
	},
);

PoItems.belongsTo(Procurement, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});
// PoItems.sync({ force: true });

export default PoItems;
