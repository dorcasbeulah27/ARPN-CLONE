import Database from '../../..';
import ProcurementAir from '../procurementAir/procurementAir';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Clearance model
const ClearanceAir = Database.getConnection().define(
	'ClearanceAir',
	{
		ID: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        AGREEDRATE: {
            type: DataTypes.DECIMAL,
        },
        CONSIGNEENAMEONAWB: {
            type: DataTypes.STRING,
        },
        DELIVERYDATE: {
            type: DataTypes.DATE,
        },
        GROSSWEIGHT: {
            type: DataTypes.DECIMAL,
        },
        AGENT: {
            type: DataTypes.STRING,
        },
        ETA: {
            type: DataTypes.DATE,
        },
        DIMENSIONS: {
            type: DataTypes.STRING,
        },
        AWBNO: {
            type: DataTypes.STRING,
        },
        NETWEIGHT: {
            type: DataTypes.DECIMAL,
        },
        SHIPMENTSTATUS: {
            type: DataTypes.STRING,
        },
        INVOICEDATE: {
            type: DataTypes.DATE,
        },
        INVOICENO: {
            type: DataTypes.STRING,
        },
        CUSTOMSDUTY: {
            type: DataTypes.DECIMAL,
        },
        BALANCE: {
            type: DataTypes.DECIMAL,
        },
        TOTALAMOUNT: {
            type: DataTypes.DECIMAL,
        },
        REMARKS: {
            type: DataTypes.STRING,
        },
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		tableName: 'CLEARANCEAIR', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

ClearanceAir.belongsTo(ProcurementAir, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});
// ClearanceAir.sync({ force: true });

// Export the Clearance model
export default ClearanceAir;
