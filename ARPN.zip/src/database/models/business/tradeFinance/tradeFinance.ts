import Database from '../../..';
import Procurement from '../procurement/procurement';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the TRADEFINANCE model
const Tradefinance = Database.getConnection().define(
	'TRADEFINANCE',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: true,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		SONAPPLICABLE: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SONPRODCERTALREDAVAIL: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SONPRODCERTAPPSENTTOCQA: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		APPFROMCQASONCERTAPP: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SONCAPRECEIVEDCQA: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SONCRGSPAIDBYTREASURY: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		INSURANCEVALIDATED: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		INSURANCEAPPLIED: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		INSURANCEDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		// SONNAFDACATTACHMENT: {
		//     type: DataTypes.STRING,
		//     allowNull: true
		// },
		COMPANYRECEIVED: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		INSURANCERATE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		INSURANCEAPPLICATIONNAMEOFBANK: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		INSURANCECERTIFICATENO: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		INSURANCEPREMIUMAMOUNT: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		SUMASSURED: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		COVERAGE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		DEBITNOTEDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		DEBITNOTENO: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		DEBITNOTEPAYMENTCOMPLETEDBY: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		DEBITNOTEPAYMENTCOMPLETEDBYTREASURYDATE: {
			type: DataTypes.DATE,
			allowNull: true
		},
		DEBITNOTEPAYMENTCOMPLETEDBYTREASURY: {
			type: DataTypes.BOOLEAN,
			allowNull: true
		},
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},

		FORMMNAMEOFBANK: DataTypes.TEXT,
		FORMMSUBMITTEDDATE: DataTypes.DATE,
		FORMMVALIDATEDDATE: DataTypes.DATE,
		FORMMREGISTEREDDATE: DataTypes.DATE,
		FORMMNO: DataTypes.TEXT,
		FORMMHSCODE: DataTypes.TEXT,
		PVSNO: DataTypes.TEXT,
		BANKAPPLICATIONNO: DataTypes.TEXT,
	},
	{
		tableName: 'TRADEFINANCE', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

Tradefinance.belongsTo(Procurement, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});

// Tradefinance.sync({ force: true });
// Export the TRADEFINANCE model
export default Tradefinance;
