const { Model, DataTypes } = require('sequelize');
import Database from '../../..';

const MaterialMaster = Database.getConnection().define(
    'MaterialMaster',
{
        ID: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
        },
        METAID: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        METAURI: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        METATYPE: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        MATERIAL: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        MATERIALNAME: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        MATERIALGROUP: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        MATERIALBASEUNIT: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        HSNCODE: {
            type: DataTypes.STRING,
            allowNull: true,

        },
    }, {
    timestamps: true,
    tableName: 'MATERIALMASTER',
},
);


export default MaterialMaster;
