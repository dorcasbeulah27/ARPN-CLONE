import Database from '../../index';

import { DataTypes } from 'sequelize';

const AttachmentsPayment = Database.getConnection().define(
	'AttachmentsPayment',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
			allowNull: false,
		},
		DOCNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FIELDNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
	},
	{
		tableName: 'ATTACHMENTSPAYMENT', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

// AttachmentsPayment.sync({ force: true });

export default AttachmentsPayment;
