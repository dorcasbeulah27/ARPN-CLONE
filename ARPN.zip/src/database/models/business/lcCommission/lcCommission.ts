import { DataTypes } from 'sequelize';
import Database from '../../..';
import Procurement from '../procurement/procurement';

const LcCommissionReports = Database.getConnection().define(
    'LcCommissionReports',
    {
        ID: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
            allowNull: false,
        },
        PROCUREMENTID: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        BANKNAME: {
            type: DataTypes.STRING(500),
            allowNull: true,
        },
        LCDATE: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        LCNUMBER: {
            type: DataTypes.STRING, // Changed to STRING if LCNUMBER is not strictly numerical
            allowNull: true,
        },
        FORMMNO: {
            type: DataTypes.STRING, // Changed to STRING if FORMNO is not strictly numerical
            allowNull: true,
        },
        CURRENCY: {
            type: DataTypes.STRING, // CURRENCY should be a STRING type
            allowNull: true,
        },
        LCVALUE: {
            type: DataTypes.DECIMAL(17, 2), // Changed to DECIMAL for large values
            allowNull: true,
        },
        LCAMTWITHTOLERANCE: {
            type: DataTypes.DECIMAL(17, 2), // Changed to DECIMAL for large values
            allowNull: true,
        },
        LCCOMMISSIONWITHVAT: {
            type: DataTypes.DECIMAL(17, 2),
            allowNull: true,
        },
        LCCOMMISSIONINDOLLAR: {
            type: DataTypes.DECIMAL(17, 2), // Changed to DECIMAL if it can have fractional part
            allowNull: true,
        },
        EXCHANGERATE: {
            type: DataTypes.DECIMAL(17, 2), // Changed to DECIMAL for more precision
            allowNull: true,
        },
        LCCOMMISSIONINNAIRA: {
            type: DataTypes.DECIMAL(17, 2), // Changed to DECIMAL for large values
            allowNull: true,
        },
    },
    {
        timestamps: true,
        tableName: 'LCCOMMISSIONREPORTS',
    },
);


LcCommissionReports.belongsTo(Procurement, {
    foreignKey: 'PROCUREMENTID',
    as: 'PROCUREMENTINFO'
});

// LcCommissionReports.sync({ force: true });

export default LcCommissionReports;
