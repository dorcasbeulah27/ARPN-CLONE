import sequelize from 'sequelize/types/sequelize';
import Database from '../../..';

const { Sequelize, DataTypes, Model } = require('sequelize');

const Contractor = Database.getConnection().define(
	'CONTRACTOR',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		NAME: {
			type: DataTypes.STRING,
			allowNull: false,
		},
		TOTALEMPLOYEES: {
			type: DataTypes.INTEGER,
			allowNull: false,
		},
		AVAILEMPLOYEES: {
			type: DataTypes.INTEGER,
			allowNull: false,
		},
	},
	{
		tableName: 'CONTRACTORS',
		timestamps: false,
	},
);

// Contractor.sync({ force: true });
export default Contractor;
