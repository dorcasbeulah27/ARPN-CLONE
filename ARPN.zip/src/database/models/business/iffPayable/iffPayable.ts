import { DataTypes } from 'sequelize';
import Database from '../../..';
import LCMAIN from '../purchaseOrder/lcMain';

const iffPayable = Database.getConnection().define(
	'iffPayable',
	{
		ID: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		LESSTHAN30DAYS: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		DAYS31TO60: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		DAYS61TO90: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		DAYS91TO120: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		DAYS121TO150: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		DAYS151TO180: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		DAYS181TO210: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		DAYS211TO240: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		DAYS241TO270: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		DAYS271TO300: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		DAYS301TO330: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		DAYS330TO365: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		MORETHAN365DAYS: {
			type: DataTypes.INTEGER,
			allowNull: true,
			defaultValue: 0,
		},
		COMMERCIALINVOICENUMBER: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		COMMERCIALINVOICEDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		COMMERCIALINVOICEAMOUNT: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		FACTORY: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		CURRENCY: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		LCNUMBER: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		FORMMNO: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		ITEMDESCRIPTION: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		CLOSINGBALANCE: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		BANKNAME: {
			type: DataTypes.STRING,
			allowNull: true,
		},
		NIGERIANCONVERSION: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		USDCONVERSION: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		NGNUSD: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		MONTH: {
			type: DataTypes.DATEONLY,
			allowNull: true,
			defaultValue: DataTypes.NOW,
		},
	},
	{
		timestamps: true,
		tableName: 'IFFPAYABLE',
	},
);

// iffPayable.sync({ force: true });

export default iffPayable;
