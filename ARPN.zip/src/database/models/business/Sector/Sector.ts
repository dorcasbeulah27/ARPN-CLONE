import Database from '../../..';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Shipment model
const Sectors = Database.getConnection().define(
	'SECTORS',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
		},
		SECTOR_NAME: {
			type: DataTypes.STRING,
			allowNull: false,
		},
	},
	{
		tableName: 'SECTORS',
		timestamps: false,
	},
);

// Sectors.sync({ force: true });
// Export the Shipment model
export default Sectors;
