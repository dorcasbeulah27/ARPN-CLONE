import Database from '../../..';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');

// Define the Shipment model
const Teachers = Database.getConnection().define(
	'TEACHERS',
	{
		id: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
		},
		TeacherName: {
			type: DataTypes.STRING,
			allowNull: false,
		},
	},
	{
		tableName: 'TEACHERS',
		timestamps: false,
	},
);

// Teachers.sync({ force: true });
// Export the Shipment model
export default Teachers;
