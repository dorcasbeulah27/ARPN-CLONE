import Database from '../../..';
import Procurement from '../procurement/procurement';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');
// const sequelize = /* Your Sequelize instance */;

// Define the TTLC model
const TT = Database.getConnection().define(
	'TT',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		TOSENDMAILTOBANKWITHSCANNEDDOCSANDIPIFAPPLICABLE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		TOSENDMAILTOBANKWITHSCANNEDDOCSANDIPIFAPPLICABLEDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		TTPAYMENTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		TTPAYMENTAMOUNT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},

		TELEXPA: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		TTPAYMENTREQUESTSENT: {
			type: DataTypes.DATE,
			defaultValue: false,
		},
		TTPAYMENTTELEXRECEIVED: {
			type: DataTypes.DATE,
			defaultValue: false,
		},
	},
	{
		tableName: 'TT', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

TT.belongsTo(Procurement, {
	foreignKey: 'PROCUREMENTID',
	as: 'PROCUREMENTINFO',
});

// TT.sync({ force: true });

// Export the TTLC model
export default TT;
