import Database from '../../..';
import Procurement from '../procurement/procurement';

// Import Sequelize library and define function
const { DataTypes } = require('sequelize');
// const sequelize = /* Your Sequelize instance */;

// Define the TTLC model
const LC = Database.getConnection().define(
	'LC',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: true,
		},
		PROCUREMENTID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		// PONUMBER: {
		//     type: DataTypes.TEXT,
		//     allowNull: true
		// },
		SCANNEDDOCSANDIPAPPLICABLE: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SCANNEDDOCSANDIPAPPLICABLEDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		LCAPPLICATIONDATETOTHEBANK: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		REQUESTFORDRAFTLC: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		DRAFTLCRECEIVED: {
			type: DataTypes.STRING, // Assuming COMBO field is a string
			allowNull: true,
		},
		DRAFTLCSHAREDTOSUPPLIER: {
			type: DataTypes.BOOLEAN, // Assuming COMBO field is a string
			allowNull: true,
		},
		DRAFTLCSHAREDTOSUPPLIERDATE: {
			type: DataTypes.DATE, // Assuming COMBO field is a string
			allowNull: true,
		},
		SUPPLIERFEEDBACKONDRAFTLC: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		REQUESTFORREVISEDDRAFTLC: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		REVISEDDRAFTLCRECEIVEDFROMBANK: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		REVISEDDRAFTLCSHAREDWITHSUPPLIER: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SUPPLIERFEEDBACKONREVISEDDRAFTLC: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		REQUESTTOBANKFORFINALLCTELEX: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		FINALLCTELEXRECEIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		FINALLCTELEXSHAREDWITHSUPPLIER: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		LCRECEIVEDBYSUPPLIER: {
			type: DataTypes.STRING, // Assuming COMBO field is a string
			allowNull: true,
		},
		BANK: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		LCDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		LCNUMBER: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		LCAMOUNT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		TOLERANCEPERECENT: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		LCLATESTSHIPMENTDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		DATEOFEXPIRY: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		LCSTATUS: {
			type: DataTypes.STRING, // Assuming COMBO field is a string
			allowNull: true,
		},
		LCAMENDMENTREQUIRED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		LCAMENDMENTCOMPLETED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		DISCRIPANCYOBSERVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		DISCRIPANCYWAIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SCANNEDDOCSRECEIVED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		SCANNEDDOCSSENTTOIMPORTTEAM: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		LCCLOSUREREQUESTREQUIRED: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		LCCLOSUREREQUESTSENTTOBANK: {
			type: DataTypes.BOOLEAN,
			allowNull: true,
		},
		LCAPPLICATIONDATETOTHEBANKDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		REQUESTFORDRAFTLCDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SUPPLIERFEEDBACKONDRAFTLCDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		REQUESTFORREVISEDDRAFTLCDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		REVISEDDRAFTLCRECEIVEDFROMBANKDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		REVISEDDRAFTLCSHAREDWITHSUPPLIERDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		SUPPLIERFEEDBACKONREVISEDDRAFTLCDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		REQUESTTOBANKFORFINALLCTELEXDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		FINALLCTELEXRECEIVEDDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		FINALLCTELEXSHAREDWITHSUPPLIERDATE: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		LCAMOUNTWITHTOLERANCE: {
			type: DataTypes.DECIMAL(17, 2),
			allowNull: true,
		},
		SUBMITTED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		LOCKED: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		tableName: 'LC', // Specify the table name
		timestamps: true, // Disable timestamps (createdAt, updatedAt)
	},
);

LC.belongsTo(Procurement, {
    foreignKey: 'PROCUREMENTID',
    as: 'PROCUREMENTINFO',
});


// LC.sync({ force: true });


// Export the TTLC model
export default LC;
