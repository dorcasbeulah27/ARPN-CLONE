import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../..';
import FormMaster from './formsMaster';
import SectionsMaster from './sectionsMaster';

const GroupsMaster = Database.getConnection().define(
	'Groups',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		FORMID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		SECTIONID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		GROUPNAME: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		GROUPDESC: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		GROUPURL: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		SHOWHEADER: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		GROUPTYPE: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		GROUPSEQUENCE: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		GROUPSPAN: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 1,
		},
		ACTIVE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
	},
	{
		timestamps: true,
		tableName: 'GROUPS',
	},
);

GroupsMaster.belongsTo(SectionsMaster, {
	foreignKey: 'SECTIONID',
	as: 'section',
});

// GroupsMaster.sync({ force: true });

export default GroupsMaster;
