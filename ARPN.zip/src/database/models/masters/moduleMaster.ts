import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../..';

const ModuleMaster = Database.getConnection().define(
	'ModuleMaster',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		MODULENAME: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		MODULEDESC: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		ROUTE: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		ACTIVE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		REVEAL: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		SEQUENCE: {
			type: DataTypes.INTEGER,
			defaultValue: 0,
		},
		PARENT: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
	},
	{
		timestamps: true,
		tableName: 'MODULEMASTER',
	},
);

// ModuleMaster.sync({ force: true });

export default ModuleMaster;
