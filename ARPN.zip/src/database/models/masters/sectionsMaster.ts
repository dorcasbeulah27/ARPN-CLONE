import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../..';
import FormMaster from './formsMaster';

const SectionsMaster = Database.getConnection().define(
	'Sections',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		FORMID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		SECTIONNAME: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		SECTIONDESC: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		SHOWHEADER: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		SECTIONTYPE: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		SECTIONSEQUENCE: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		SECTIONSPAN: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 1,
		},
		ACTIVE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		MULTIPLE: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		timestamps: true,
		tableName: 'SECTIONS',
	},
);

SectionsMaster.belongsTo(FormMaster, {
	foreignKey: 'FORMID',
	as: 'form',
});

// SectionsMaster.sync({ force: true });

export default SectionsMaster;
