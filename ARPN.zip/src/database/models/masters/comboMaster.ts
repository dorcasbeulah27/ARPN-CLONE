import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../..';
import FormFieldsMaster from './formFieldsMaster';
import FormMaster from './formsMaster';
import GroupsMaster from './groupsMaster';
import SectionsMaster from './sectionsMaster';

const comboMaster = Database.getConnection().define(
	'comboMaster',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		FIELDID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		LABEL: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		VALUE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		SEQUENCE: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		ACTIVE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
	},
	{
		timestamps: true,
		tableName: 'COMBOMASTER',
	},
);

comboMaster.belongsTo(FormFieldsMaster, {
	foreignKey: 'FIELDID',
	as: 'field',
});

// comboMaster.sync({ force: true });

export default comboMaster;
