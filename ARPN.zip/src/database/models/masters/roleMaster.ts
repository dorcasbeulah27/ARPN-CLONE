import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../..';

const RoleMaster = Database.getConnection().define(
	'RoleMaster',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		ROLENAME: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		ROLEDESC: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		ACTIVE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
	},
	{
		timestamps: true,
		tableName: 'ROLEMASTER',
	},
);
// RoleMaster.sync({ force: true });

export default RoleMaster;
