import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../..';

const FormMaster = Database.getConnection().define(
	'Forms',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		MODULEID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		FORMNAME: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		FORMDESC: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FORMPOSTENDPOINT: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FORMGETENDPOINT: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		ACTIVE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
	},
	{
		timestamps: true,
		tableName: 'FORMS',
	},
);

// FormMaster.sync({ force: true });

export default FormMaster;
