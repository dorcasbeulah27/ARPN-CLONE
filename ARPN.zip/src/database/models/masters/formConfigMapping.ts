import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../..';

const FormConfigMapping = Database.getConnection().define(
	'FormConfigMapping',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		FORMID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		FACTORY: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		TYPEOFMATERIAL: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		ACTIVE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
	},
	{
		timestamps: true,
		tableName: 'FORMCONFIGMAPPING',
	},
);

// FormConfigMapping.sync({ force: true });

export default FormConfigMapping;
