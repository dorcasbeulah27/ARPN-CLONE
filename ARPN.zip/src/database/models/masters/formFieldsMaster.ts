import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../..';
import FormMaster from './formsMaster';
import GroupsMaster from './groupsMaster';
import SectionsMaster from './sectionsMaster';

const FormFieldsMaster = Database.getConnection().define(
	'Formfields',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		FORMID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		SECTIONID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		FIELDSPANSM: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 12,
		},
		FIELDSPANMD: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 6,
		},
		FIELDSPANLG: {
			type: DataTypes.INTEGER,
			allowNull: false,
			defaultValue: 3,
		},
		FIELDNAME: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		FIELDDESC: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FIELDTYPE: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		FIELDSEQUENCE: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		DEFAULTVALUE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		VALUELISTS: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		SHOWLABEL: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		ROLEID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		CREATE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		READ: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		UPDATE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		DELETE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		ACTIVE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		TABLEGROUP: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		TABLEGROUPSEQUENCE: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		TABLEGROUPTYPE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		FIELDSUBTYPE: {
			type: DataTypes.STRING(500),
			allowNull: true,
		},
		FIELDVARIANT: {
			type: DataTypes.TEXT,
			allowNull: true,
			defaultValue: 'outlined',
		},
		FIELDREQUIRED: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		CONFIGPARENT: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		CONFIGCHILD: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		CONFIGPARENTNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		CONFIGVALUE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		AUTOPOPULATEDATE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		AUTOPOPULATEPARENTNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		HYPERLINK: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		HIDDEN: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
	},
	{
		timestamps: true,
		tableName: 'FORMFIELDS',
	},
);

FormFieldsMaster.belongsTo(FormMaster, {
	foreignKey: 'FORMID',
	as: 'form',
});

FormFieldsMaster.belongsTo(SectionsMaster, {
	foreignKey: 'SECTIONID',
	as: 'section',
});

FormFieldsMaster.belongsTo(GroupsMaster, {
	foreignKey: 'GROUPID',
	as: 'group',
});

// FormFieldsMaster.sync({ force: true });

export default FormFieldsMaster;
