import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../..';

const FormTableMapping = Database.getConnection().define(
	'FormTableMapping',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		FORMID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		TABLENAME: {
			type: DataTypes.STRING(255),
			allowNull: true,
		},
		FIELDS: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		GROUPNAME: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		GROUPTYPE: {
			type: DataTypes.TEXT,
			allowNull: true,
		},
		ACTIVE: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
	},
	{
		timestamps: true,
		tableName: 'FORMTABLEMAPPING',
	},
);

// FormTableMapping.sync({ force: true });

export default FormTableMapping;
