import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../../..';
import ModuleMaster from '../moduleMaster';
import RoleMaster from '../roleMaster';

const RoleModuleConfigurationMaster = Database.getConnection().define(
	'RoleModuleConfigurationMaster',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		ROLEID: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: RoleMaster,
				key: 'ID',
			},
		},
		MODULEID: {
			type: DataTypes.INTEGER,
			allowNull: false,
			unique: false,
			// references: {
			//   model: ModuleMaster,
			//   key: "ID",
			// },
		},
		CREATEPERM: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		READPERM: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		UPDATEPERM: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		DELETEPERM: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
		STATUS: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
	},
	{
		timestamps: true,
		tableName: 'ROLE_MODULE_CONFIGURATION_MASTER',
	},
);

RoleModuleConfigurationMaster.belongsTo(ModuleMaster, {
	foreignKey: 'MODULEID', // The foreign key column in BinSkuConfiguration
	as: 'moduleInfo', // Alias for the joined data (you can choose your own alias)
});

// RoleModuleConfigurationMaster.sync({ force: true });

export default RoleModuleConfigurationMaster;
