import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../../..';
import OuInfo from '../ouMaster';
import RoleMaster from '../roleMaster';
import UserMaster from '../userMaster';

const UserRoleConfigurationMaster = Database.getConnection().define(
	'UserRoleConfigurationMaster',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: true,
		},
		USERID: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: UserMaster,
				key: 'ID',
			},
		},
		ROLEID: {
			type: DataTypes.INTEGER,
			allowNull: false,
			unique: false,
			// references: {
			//   model: RoleMaster,
			//   key: "ID",
			// },
		},
		default: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		STATUS: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
	},
	{
		timestamps: true,
		tableName: 'USER_ROLE_CONFIGURATION_MASTER',
	},
);

UserRoleConfigurationMaster.belongsTo(RoleMaster, {
	foreignKey: 'ROLEID', // The foreign key column in BinSkuConfiguration
	as: 'roleInfo', // Alias for the joined data (you can choose your own alias)
});

// UserRoleConfigurationMaster.sync({ force: true });

export default UserRoleConfigurationMaster;
