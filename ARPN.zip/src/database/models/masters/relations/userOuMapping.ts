import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../../..';
import OuInfo from '../ouMaster';
import UserMaster from '../userMaster';

const UserOuMaster = Database.getConnection().define(
	'UserOuMaster',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		USERID: {
			type: DataTypes.INTEGER,
			allowNull: false,
			references: {
				model: UserMaster,
				key: 'ID',
			},
		},
		OUID: {
			type: DataTypes.INTEGER,
			allowNull: false,
			// references: {
			//   model: BinConfigurationMaster,
			//   key: "ID",
			// },
		},
		default: {
			type: DataTypes.BOOLEAN,
			defaultValue: false,
		},
		STATUS: {
			type: DataTypes.BOOLEAN,
			defaultValue: true,
		},
	},
	{
		timestamps: true,
		tableName: 'USER_OU_MAPPING',
	},
);

UserOuMaster.belongsTo(OuInfo, {
	foreignKey: 'OUID', // The foreign key column in BinSkuConfiguration
	as: 'ouInfo', // Alias for the joined data (you can choose your own alias)
});

// UserOuMaster.sync({ force: true });

export default UserOuMaster;
