import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../..';

const OuInfo = Database.getConnection().define(
	'OU',
	{
		ID: {
			type: DataTypes.INTEGER,
			autoIncrement: true,
			primaryKey: true,
			allowNull: false,
		},
		// OUID: {
		//   type: DataTypes.INTEGER,
		//   allowNull: true,
		// },
		TYPE: {
			type: DataTypes.STRING(255),
			allowNull: false,
		},
		NAME: {
			type: DataTypes.STRING(255),
			allowNull: false,
		},
		DESCRIPTION: {
			type: DataTypes.TEXT,
			allowNull: false,
		},
		ADDRESS: {
			type: DataTypes.TEXT,
			allowNull: true,
			defaultValue: '',
		},
		CITY: {
			type: DataTypes.TEXT,
			allowNull: true,
			defaultValue: '',
		},
		STATE: {
			type: DataTypes.TEXT,
			allowNull: true,
			defaultValue: '',
		},
		COUNTRY: {
			type: DataTypes.TEXT,
			allowNull: true,
			defaultValue: '',
		},
		PINCODE: {
			type: DataTypes.TEXT,
			allowNull: true,
			defaultValue: '',
		},
		ACTIVE: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: true,
		},
	},
	{
		timestamps: true,
		tableName: 'OU',
	},
);

// OuInfo.sync({ force: true });
export default OuInfo;
