import { Sequelize, DataTypes, Dialect } from 'sequelize';
import Database from '../..';

const UserMaster = Database.getConnection().define(
  'UserMaster',
  {
    ID: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    OUID: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    USERID: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    USERNAME: {
      type: DataTypes.STRING(500),
      allowNull: true,
    },
    PHONENO: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    EMAIL: {
      type: DataTypes.STRING(500),
      allowNull: true,
    },
    PASSWORD: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    ACTIVE: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
  },
  {
    timestamps: true,
    tableName: 'USERMASTER',
  }
);

// UserMaster.sync({ force: true });

export default UserMaster;
