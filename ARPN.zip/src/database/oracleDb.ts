import oracledb from 'oracledb';
import Environment from '../environments/environment';

export default class OracleDatabase {
	private static env: Environment | null = null;

	private static establishEnv(): Environment {
		if (!this.env) {
			this.env = new Environment();
		}
		return this.env;
	}

	public static async orionDBConnect(): Promise<oracledb.IConnection> {
		try {
			const env = this.establishEnv();
			const clientOpts = {
				libDir: env.orionLibraryDir, // process.env.ORION_LIB_DIR,
			};
			await oracledb.initOracleClient(clientOpts);
			console.log('Connection to the database initiated...');
			console.log(
				env.orionUser,
				env.orionPassword,
				env.orionConnectionString,
				env.orionLibraryDir,
			);
			const connection = await oracledb.getConnection({
				user: env.orionUser, // process.env.DB_ORION_USER,
				password: env.orionPassword, // process.env.DB_ORION_PASSWORD,
				connectString: env.orionConnectionString, // process.env.ORION_DB_CONNECT_STRING,
				externalAuth: false,
			});
			console.log('Connection successfully established.🚀');
			return connection;
		} catch (error) {
			console.error('An error occurred:', error);
			throw error; // Throw the error for better error handling in the calling function
		}
	}
}
